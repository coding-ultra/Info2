## INSTALLING

* Open SFTp and go inside /var/www/pterodactyl
* Drag and drop the **stark-v1.1.0-leaked-by-vizon-and-pteroxdevelopment.zip**.
apt install unzip
unzip stark-v1.1.0-leaked-by-vizon-and-pteroxdevelopment
cd stark-v1.1.0-leaked-by-vizon-and-pteroxdevelopment
sudo bash install.sh

## UPDATING

* Upload the new **stark-v1.1.0-leaked-by-vizon-and-pteroxdevelopment.zip** into /var/www/pterodactyl (or beside update.sh).
apt install unzip
* unzip stark-v-leaked-by-vizon-and-pteroxdevelopment
* sudo bash update.sh
* Pick the zip from the list.

## Notes

* Do Not Share This Theme

