<?php
 namespace Pterodactyl\Services\Dezerx\Ai; use RuntimeException; class AiUnavailable extends RuntimeException { } 