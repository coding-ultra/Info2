<?php
 namespace Pterodactyl\Services\Dezerx\Ai; use RuntimeException; class Stopped extends RuntimeException { } 