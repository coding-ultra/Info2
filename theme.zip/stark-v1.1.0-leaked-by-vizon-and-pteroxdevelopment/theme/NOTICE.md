# Third-party notices

## Minecraft font

`public/dezerx/fonts/minecraft.woff` / `minecraft.woff2`

Designed by **Pwnage_Block**, built with FontStruct — Copyright Pwnage_Block, 2011.
Licensed under [Creative Commons Attribution-ShareAlike 3.0](http://creativecommons.org/licenses/by-sa/3.0/).
Source: <http://fontstruct.com/fontstructions/show/432966>

This is an independent typeface inspired by Minecraft's lettering. It is not
made or endorsed by Mojang. If you modify or subset it, the modified font must
be shared under the same CC BY-SA 3.0 licence.

## renderchest

`tools/mc-assets/` uses [`aternos/renderchest`](https://github.com/aternosorg/renderchest),
Copyright (c) 2023-2024 Aternos GmbH, MIT licensed. It is downloaded at asset
generation time and is not redistributed with this theme.

## Monaco editor

`public/vendor/monaco/`

The [Monaco editor](https://github.com/microsoft/vscode) 0.52.2, Copyright (c) Microsoft
Corporation, MIT licensed. Microsoft's own minified AMD build is redistributed verbatim so the
admin email editor has a code editor on a page that loads no bundle; the `/*! ... */` banners in
`loader.js` and `editor/editor.main.js` carry the licence and must stay.

## Monaco editor themes

`resources/scripts/dezerx/lib/themes/night-owl.json` / `github-light.json`

Copied from [monaco-themes](https://github.com/brijeshb42/monaco-themes),
Copyright (c) Brijesh Bittu, MIT licensed. Only the two theme definitions the
file editor uses are included; the package itself is not redistributed.

## Pterodactyl Panel

This theme is a front-end for [Pterodactyl Panel](https://pterodactyl.io),
Copyright © Dane Everitt and contributors, MIT licensed.

## Minecraft assets

Item icons, HUD sprites, the default player skins and the pack icon are rendered
on the installing server from a Minecraft client jar downloaded from Mojang. They
are **not** distributed with this theme. Minecraft is a trademark of Mojang AB;
this theme is not affiliated with or endorsed by Mojang or Microsoft.
