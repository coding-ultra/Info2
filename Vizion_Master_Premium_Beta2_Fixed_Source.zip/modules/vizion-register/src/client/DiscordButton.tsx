import { DISCORD_LOGO } from './discordLogo';

export const DISCORD_URL = 'https://discord.gg/eFQZayYSGN';

/**
 * A "Join our Discord" call to action in Discord's blurple. It is a real link, so it can be
 * opened in a new tab, copied or middle-clicked. Styled with this extension's own `vizion:`
 * Tailwind prefix and the Panel's tokens for focus rings.
 */
export default function DiscordButton() {
    return (
        <a
            href={DISCORD_URL}
            target='_blank'
            rel='noopener noreferrer'
            className='vizion:group vizion:flex vizion:w-full vizion:items-center vizion:gap-3 vizion:rounded-lg vizion:bg-[#5865f2] vizion:px-4 vizion:py-3 vizion:text-[#ffffff] vizion:no-underline vizion:shadow-lg vizion:shadow-[#5865f2]/30 vizion:ring-1 vizion:ring-inset vizion:ring-[#ffffff26] vizion:transition vizion:duration-150 vizion:hover:-translate-y-px vizion:hover:bg-[#4752c4] vizion:hover:text-[#ffffff] vizion:hover:shadow-xl vizion:hover:shadow-[#5865f2]/40 vizion:focus-visible:outline-2 vizion:focus-visible:outline-offset-2 vizion:focus-visible:outline-ring'
        >
            <span className='vizion:flex vizion:size-9 vizion:flex-none vizion:items-center vizion:justify-center vizion:rounded-md vizion:bg-[#ffffff26]'>
                <img src={DISCORD_LOGO} alt='' width='22' height='17' className='vizion:block vizion:h-auto vizion:w-[22px]' aria-hidden='true' />
            </span>
            <span className='vizion:flex vizion:min-w-0 vizion:flex-1 vizion:flex-col vizion:text-left'>
                <span className='vizion:text-sm vizion:font-semibold vizion:leading-tight'>Join our Discord</span>
                <span className='vizion:text-xs vizion:leading-tight vizion:text-[#ffffffbf]'>
                    Get help and chat with the community
                </span>
            </span>
            <svg
                viewBox='0 0 24 24'
                width='18'
                height='18'
                fill='none'
                stroke='currentColor'
                strokeWidth='2'
                strokeLinecap='round'
                strokeLinejoin='round'
                className='vizion:flex-none vizion:opacity-80 vizion:transition-transform vizion:duration-150 vizion:group-hover:translate-x-0.5'
                aria-hidden='true'
            >
                <path d='M5 12h14M13 6l6 6-6 6' />
            </svg>
        </a>
    );
}

/** Rendered on the admin overview (slot panel.overview.after). */
export function AdminDiscord() {
    return (
        <div className='vizion:mt-4 vizion:max-w-sm'>
            <DiscordButton />
        </div>
    );
}
