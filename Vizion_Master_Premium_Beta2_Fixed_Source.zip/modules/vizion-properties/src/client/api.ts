import { http } from '@pterodactyl/sdk';
import type { CategoryNav } from './config';

/** What the Properties admin page edits. Mirrors DisplaySettings in the backend. */
export interface DisplaySettings {
    enabled: boolean;
    properties_file: string;
    show_descriptions: boolean;
    show_custom: boolean;
    minimal_cards: boolean;
    category_nav: CategoryNav;
}

export const BUILT_IN: DisplaySettings = {
    enabled: true,
    properties_file: '/server.properties',
    show_descriptions: true,
    show_custom: true,
    minimal_cards: false,
    category_nav: 'off',
};

/** Query key for the admin settings. */
export const displayKey = ['vizion-properties', 'admin', 'display'] as const;

/** Admin routes of this extension (routes/admin.php); root administrators only. */
const adminBase = '/api/admin/extensions/vizion-properties';

export async function getDisplaySettings(): Promise<DisplaySettings> {
    return (await http.get<{ data: DisplaySettings }>(`${adminBase}/display`)).data.data;
}

export async function saveDisplaySettings(values: DisplaySettings): Promise<DisplaySettings> {
    return (await http.put<{ data: DisplaySettings }>(`${adminBase}/display`, values)).data.data;
}
