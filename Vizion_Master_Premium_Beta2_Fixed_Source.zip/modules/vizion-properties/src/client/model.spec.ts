import { describe, expect, it } from 'vitest';
import { buildRows, changesOf, filterRows, groupRows, isValidCustomKey, missingKeys } from './model';
import { parseProperties } from './properties';

const parsed = parseProperties('pvp=true\nview-distance=10\nmy-plugin-flag=false\nmy-plugin-name=Bob\n');

describe('buildRows', () => {
    it('knows built-in properties and marks the rest as custom', () => {
        const rows = buildRows(parsed, {}, [], true);
        expect(rows.map((row) => [row.def.key, row.def.type, row.def.category])).toEqual([
            ['pvp', 'boolean', 'Gameplay'],
            ['view-distance', 'number', 'Performance'],
            ['my-plugin-flag', 'boolean', 'Others'],
            ['my-plugin-name', 'text', 'Others'],
        ]);
    });

    it('hides custom properties when asked', () => {
        const keys = buildRows(parsed, {}, [], false).map((row) => row.def.key);
        expect(keys).toEqual(expect.arrayContaining(['pvp', 'view-distance']));
        expect(keys).not.toContain('my-plugin-flag');
    });

    it('tracks edits and added keys', () => {
        const rows = buildRows(parsed, { pvp: 'false' }, ['hardcore'], true);
        expect(rows.find((row) => row.def.key === 'pvp')).toMatchObject({ value: 'false', original: 'true', edited: true });
        expect(rows.find((row) => row.def.key === 'view-distance')?.edited).toBe(false);
        expect(rows.find((row) => row.def.key === 'hardcore')).toMatchObject({ original: undefined, value: 'false', edited: true });
        expect(changesOf(rows)).toEqual({ pvp: 'false', hardcore: 'false' });
    });

    it('an edit that goes back to the original is not a change', () => {
        expect(changesOf(buildRows(parsed, { pvp: 'true' }, [], true))).toEqual({});
    });
});

describe('filterRows', () => {
    const rows = buildRows(parsed, { pvp: 'false' }, [], true);

    it('searches the key, name, description and value', () => {
        expect(filterRows(rows, 'pvp', false).map((row) => row.def.key)).toEqual(['pvp']);
        expect(filterRows(rows, 'chunks are sent', false).map((row) => row.def.key)).toEqual(['view-distance']);
        expect(filterRows(rows, 'bob', false).map((row) => row.def.key)).toEqual(['my-plugin-name']);
        expect(filterRows(rows, 'zzzz', false)).toEqual([]);
    });

    it('can show only edited rows', () => {
        expect(filterRows(rows, '', true).map((row) => row.def.key)).toEqual(['pvp']);
    });

    it('never matches the value of a secret', () => {
        const secret = buildRows(parseProperties('rcon.password=hunter2\n'), {}, [], true);
        expect(filterRows(secret, 'hunter2', false)).toEqual([]);
    });
});

describe('groups and helpers', () => {
    it('groups rows in display order', () => {
        expect(groupRows(buildRows(parsed, {}, [], true)).map((group) => group.category)).toEqual(['Gameplay', 'Performance', 'Others']);
    });

    it('offers only known keys that are not in the file yet', () => {
        const keys = missingKeys(parsed, ['hardcore']).map((def) => def.key);
        expect(keys).toContain('motd');
        expect(keys).not.toContain('pvp');
        expect(keys).not.toContain('hardcore');
    });

    it('validates custom keys', () => {
        expect(isValidCustomKey('my.plugin-key_1')).toBe(true);
        expect(isValidCustomKey('bad key')).toBe(false);
        expect(isValidCustomKey('a=b')).toBe(false);
    });
});
