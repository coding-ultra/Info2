import { Input, Switch } from '@pterodactyl/sdk';
import type { PropDef } from '../catalog';
import Dropdown from './Dropdown';

/** Returns a message if `value` is not allowed for this property, otherwise undefined. */
export function validateValue(def: PropDef, value: string): string | undefined {
    if (def.type !== 'number') return undefined;
    if (!/^-?\d+$/.test(value.trim())) return 'Enter a whole number.';
    const number = Number(value);
    if (def.min !== undefined && number < def.min) return `Must be at least ${def.min}.`;
    if (def.max !== undefined && number > def.max) return `Must be at most ${def.max}.`;
    return undefined;
}

interface Props {
    def: PropDef;
    value: string;
    edited: boolean;
    disabled: boolean;
    showDescription: boolean;
    /** Draw the property as a small card instead of a list row. */
    minimal?: boolean;
    onChange: (value: string) => void;
}

/** One property. Normal: name and explanation on the left, the control on the right. Minimal: a small card with the control underneath. Booleans are On/Off switches. */
export default function PropertyRow({ def, value, edited, disabled, showDescription, minimal = false, onChange }: Props) {
    const error = edited ? validateValue(def, value) : undefined;

    let control;
    if (def.type === 'boolean') {
        const on = value === 'true';
        control = <Switch checked={on} onChange={(checked) => onChange(checked ? 'true' : 'false')} disabled={disabled} label={on ? 'On' : 'Off'} aria-label={def.label} />;
    } else if (def.type === 'enum') {
        const options = def.options ?? [];
        const list = options.includes(value) ? options : [...options, value];
        control = <Dropdown value={value} onChange={onChange} disabled={disabled} aria-label={def.label} options={list.map((option) => ({ value: option, label: option === '' ? '(empty)' : option }))} />;
    } else {
        control = (
            <Input
                type={def.type === 'secret' ? 'password' : def.type === 'number' ? 'number' : 'text'}
                autoComplete={'off'}
                value={value}
                min={def.min}
                max={def.max}
                placeholder={def.default}
                disabled={disabled}
                aria-label={def.label}
                $hasError={!!error}
                onChange={(event) => onChange(event.target.value)}
            />
        );
    }

    const details = (
        <div className={'dprop:min-w-0 dprop:flex-1'}>
            <div className={'dprop:flex dprop:flex-wrap dprop:items-center dprop:gap-2'}>
                <span className={'dprop:font-medium dprop:text-foreground'}>{def.label}</span>
                {edited && <span className={'dprop:rounded dprop:bg-primary dprop:px-1.5 dprop:py-0.5 dprop:text-[10px] dprop:font-semibold dprop:uppercase dprop:text-primary-foreground'}>Edited</span>}
            </div>
            <code className={minimal ? 'dprop:break-all dprop:text-xs dprop:text-muted-foreground' : 'dprop:text-xs dprop:text-muted-foreground'}>{def.key}</code>
            {showDescription && <p className={'dprop:mt-0.5 dprop:text-xs dprop:text-muted-foreground'}>{def.description}</p>}
            {error && <p className={'dprop:mt-0.5 dprop:text-xs'} style={{ color: 'var(--destructive, #ef4444)' }}>{error}</p>}
        </div>
    );

    if (minimal) {
        return (
            <div data-card={def.key} className={`dprop:flex dprop:min-w-0 dprop:flex-col dprop:gap-2 dprop:rounded-md dprop:border dprop:p-3 ${edited ? 'dprop:border-primary' : 'dprop:border-border'}`}>
                {details}
                <div className={'dprop:w-full'}>{control}</div>
            </div>
        );
    }

    return (
        <div className={'dprop:flex dprop:flex-col dprop:gap-2 dprop:py-3 dprop:sm:flex-row dprop:sm:items-center dprop:sm:justify-between dprop:sm:gap-6'}>
            {details}
            <div className={'dprop:w-full dprop:sm:w-64 dprop:shrink-0'}>{control}</div>
        </div>
    );
}
