import { VIZION_ICON } from '../brand';
import DiscordButton from './DiscordButton';

/** The page heading with the Vizion icon and the Discord button. */
export default function Header({ title, subtitle }: { title: string; subtitle: string }) {
    return (
        <div className={'dprop:flex dprop:flex-wrap dprop:items-center dprop:justify-between dprop:gap-3'}>
            <div className={'dprop:flex dprop:items-center dprop:gap-3'}>
                <img src={VIZION_ICON} alt={''} width={40} height={40} className={'dprop:rounded-md'} />
                <div>
                    <h2 className={'dprop:font-semibold dprop:text-foreground'}>{title}</h2>
                    <p className={'dprop:text-xs dprop:text-muted-foreground'}>{subtitle}</p>
                </div>
            </div>
            <DiscordButton />
        </div>
    );
}
