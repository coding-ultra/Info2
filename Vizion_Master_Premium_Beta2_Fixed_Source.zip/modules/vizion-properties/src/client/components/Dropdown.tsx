import { useEffect, useId, useMemo, useRef, useState, type CSSProperties, type KeyboardEvent } from 'react';

export interface DropdownOption {
    value: string;
    label: string;
    /** Text the search box matches against. Defaults to the label. */
    textLabel?: string;
}

interface Props {
    /** The selected value, or null when nothing is selected (an "add" picker). */
    value: string | null;
    options: DropdownOption[];
    onChange: (value: string) => void;
    disabled?: boolean;
    placeholder?: string;
    /** Show a search box at the top of the list. */
    searchPlaceholder?: string;
    'aria-label'?: string;
}

interface Position {
    /** Distance from the top of the screen (list opens downwards) or from the bottom (list opens upwards). */
    top?: number;
    bottom?: number;
    left: number;
    width: number;
    maxHeight: number;
}

const GAP = 4;

type Rgba = [number, number, number, number];

/** Parses rgb()/rgba() computed colours (comma or space syntax). Anything else returns null. */
function parseColor(color: string | undefined): Rgba | null {
    if (!color) return null;
    if (color === 'transparent') return [0, 0, 0, 0];
    const match = color.match(/^rgba?\(([^)]+)\)$/);
    if (!match) return null;
    const parts = match[1]!.split(/[,\s/]+/).filter(Boolean).map(Number);
    if (parts.length < 3 || parts.some((part) => Number.isNaN(part))) return null;
    return [parts[0]!, parts[1]!, parts[2]!, parts[3] ?? 1];
}

/** True when a computed colour is missing or fully see-through. */
const isClear = (color: string | undefined): boolean => {
    const parsed = parseColor(color);
    return parsed ? parsed[3] < 0.01 : !color;
};

/**
 * The solid colour a user actually sees behind `element`: its own background, or, when that is see-through, the backgrounds
 * of the boxes around it blended on top of each other, up to the first solid one.
 */
function visibleBackground(element: HTMLElement | null): string | undefined {
    const layers: Rgba[] = [];
    for (let node = element; node; node = node.parentElement) {
        const color = getComputedStyle(node).backgroundColor;
        if (isClear(color)) continue;
        const parsed = parseColor(color);
        // A colour in a format that cannot be blended (for example oklch) is used as it is when it is the top-most fill.
        if (!parsed) return layers.length === 0 ? color : undefined;
        layers.push(parsed);
        if (parsed[3] >= 0.99) break;
    }
    if (layers.length === 0) return undefined;
    let [r, g, b] = layers[layers.length - 1]!;
    for (let i = layers.length - 2; i >= 0; i--) {
        const [lr, lg, lb, la] = layers[i]!;
        r = lr * la + r * (1 - la);
        g = lg * la + g * (1 - la);
        b = lb * la + b * (1 - la);
    }
    return `rgb(${Math.round(r)}, ${Math.round(g)}, ${Math.round(b)})`;
}

/**
 * A drop-down drawn in the same style as the property cards: the button and the list share the card's border, corners and
 * text, and the list opens on the Panel's own background instead of a separate-looking popup. The list is positioned on the
 * screen (not inside the card), so a card or box around it can never clip it.
 */
export default function Dropdown({ value, options, onChange, disabled = false, placeholder = 'Select…', searchPlaceholder, 'aria-label': ariaLabel }: Props) {
    const id = useId();
    const trigger = useRef<HTMLButtonElement>(null);
    const panel = useRef<HTMLDivElement>(null);
    const searchBox = useRef<HTMLInputElement>(null);
    const [open, setOpen] = useState(false);
    const [query, setQuery] = useState('');
    const [active, setActive] = useState(0);
    // The highlighted row only shows while the keyboard is used. There is no hover effect.
    const [keyboard, setKeyboard] = useState(false);
    const [position, setPosition] = useState<Position | null>(null);
    const [look, setLook] = useState<CSSProperties>({});

    // Read the real look of the Panel's text boxes (the boxes where you type) and use it for both the button and the list, so the
    // drop-down is the same colour as they are. The text box nearest to the button is used; its fill is blended with the boxes
    // behind it, so the list is solid even when the Panel's field colour is slightly see-through.
    const readLook = () => {
        const next: Record<string, string> = {};
        const selector = 'input:not([type="checkbox"]):not([type="radio"]):not(.dprop-dd-search)';

        let field: HTMLInputElement | null = null;
        for (let node: HTMLElement | null = trigger.current?.parentElement ?? null; node && !field; node = node.parentElement) {
            field = node.querySelector<HTMLInputElement>(selector);
        }
        field ??= document.querySelector<HTMLInputElement>(selector);

        if (field) {
            const style = getComputedStyle(field);
            const fill = visibleBackground(field);
            if (fill) next['--dd-bg'] = fill;
            if (!isClear(style.borderTopColor)) next['--dd-border'] = style.borderTopColor;
            if (style.borderTopLeftRadius) next['--dd-radius'] = style.borderTopLeftRadius;
            if (style.color) next['--dd-color'] = style.color;
            if (style.height.endsWith('px') && parseFloat(style.height) > 0) next['--dd-height'] = style.height;
        } else {
            // No text box on the page: fall back to the box the button sits in.
            const box = trigger.current?.parentElement ?? null;
            const fill = visibleBackground(box);
            if (fill) next['--dd-bg'] = fill;
            if (box) next['--dd-color'] = getComputedStyle(box).color;
        }

        setLook(next as CSSProperties);
    };

    useEffect(readLook, []);

    const shown = useMemo(() => {
        const needle = query.trim().toLowerCase();
        return needle === '' ? options : options.filter((option) => (option.textLabel ?? option.label).toLowerCase().includes(needle));
    }, [options, query]);

    const selected = options.find((option) => option.value === value);

    const close = (refocus = false) => {
        setOpen(false);
        setQuery('');
        if (refocus) trigger.current?.focus();
    };

    const openList = () => {
        if (disabled) return;
        readLook();
        const rect = trigger.current?.getBoundingClientRect();
        if (!rect) return;
        const below = window.innerHeight - rect.bottom - GAP - 8;
        const above = rect.top - GAP - 8;
        // Open upwards only when there is clearly more room above than below.
        const up = below < 180 && above > below;
        const maxHeight = Math.max(120, Math.min(288, up ? above : below));
        setPosition({ ...(up ? { bottom: window.innerHeight - rect.top + GAP } : { top: rect.bottom + GAP }), left: rect.left, width: rect.width, maxHeight });
        setActive(Math.max(0, options.findIndex((option) => option.value === value)));
        setKeyboard(false);
        setOpen(true);
    };

    // Close when the page is clicked elsewhere, scrolled or resized, so the list never floats away from its button.
    useEffect(() => {
        if (!open) return;
        const outside = (event: MouseEvent) => {
            const target = event.target as Node;
            if (!panel.current?.contains(target) && !trigger.current?.contains(target)) close();
        };
        const away = (event: Event) => {
            if (event.target instanceof Node && panel.current?.contains(event.target)) return;
            close();
        };
        document.addEventListener('mousedown', outside);
        window.addEventListener('scroll', away, true);
        window.addEventListener('resize', away);
        return () => {
            document.removeEventListener('mousedown', outside);
            window.removeEventListener('scroll', away, true);
            window.removeEventListener('resize', away);
        };
    }, [open]);

    useEffect(() => {
        if (open && searchPlaceholder) searchBox.current?.focus();
    }, [open, searchPlaceholder]);

    // Keep the highlighted option in view while using the arrow keys.
    useEffect(() => {
        if (!open) return;
        panel.current?.querySelector<HTMLElement>(`[data-index="${active}"]`)?.scrollIntoView?.({ block: 'nearest' });
    }, [open, active]);

    const choose = (option: DropdownOption | undefined) => {
        if (!option) return;
        onChange(option.value);
        close(true);
    };

    const onKeyDown = (event: KeyboardEvent) => {
        if (!open) {
            if (event.key === 'ArrowDown' || event.key === 'ArrowUp' || event.key === 'Enter' || event.key === ' ') {
                event.preventDefault();
                openList();
            }
            return;
        }
        if (event.key === 'Escape') {
            event.preventDefault();
            close(true);
        } else if (event.key === 'ArrowDown') {
            event.preventDefault();
            setKeyboard(true);
            setActive((current) => Math.min(current + 1, shown.length - 1));
        } else if (event.key === 'ArrowUp') {
            event.preventDefault();
            setKeyboard(true);
            setActive((current) => Math.max(current - 1, 0));
        } else if (event.key === 'Enter') {
            event.preventDefault();
            choose(shown[active]);
        } else if (event.key === 'Tab') {
            close();
        }
    };

    return (
        <div className={'dprop-dd'} style={look} onKeyDown={onKeyDown}>
            <button
                ref={trigger}
                type={'button'}
                className={'dprop-dd-trigger'}
                aria-haspopup={'listbox'}
                aria-expanded={open}
                aria-controls={open ? id : undefined}
                aria-label={ariaLabel}
                disabled={disabled}
                data-open={open}
                onClick={() => (open ? close() : openList())}
            >
                <span className={selected ? 'dprop-dd-value' : 'dprop-dd-value dprop-dd-placeholder'}>{selected ? selected.label : placeholder}</span>
                <svg className={'dprop-dd-chevron'} width={14} height={14} viewBox={'0 0 24 24'} fill={'none'} stroke={'currentColor'} strokeWidth={2} strokeLinecap={'round'} strokeLinejoin={'round'} aria-hidden={true}>
                    <path d={'m6 9 6 6 6-6'} />
                </svg>
            </button>

            {open && position && (
                <div
                    ref={panel}
                    id={id}
                    className={'dprop-dd-panel'}
                    style={position}
                >
                    {searchPlaceholder && (
                        <input
                            ref={searchBox}
                            className={'dprop-dd-search'}
                            value={query}
                            placeholder={searchPlaceholder}
                            aria-label={searchPlaceholder}
                            autoComplete={'off'}
                            onChange={(event) => {
                                setQuery(event.target.value);
                                setActive(0);
                            }}
                        />
                    )}
                    <div role={'listbox'} aria-label={ariaLabel} className={'dprop-dd-list'}>
                        {shown.length === 0 && <p className={'dprop-dd-empty'}>Nothing found.</p>}
                        {shown.map((option, index) => (
                            <div
                                key={option.value}
                                role={'option'}
                                aria-selected={option.value === value}
                                data-index={index}
                                data-active={keyboard && index === active}
                                className={'dprop-dd-option'}
                                onMouseDown={(event) => event.preventDefault()}
                                onClick={() => choose(option)}
                            >
                                <span className={'dprop-dd-option-label'}>{option.label}</span>
                                {option.value === value && (
                                    <svg width={14} height={14} viewBox={'0 0 24 24'} fill={'none'} stroke={'currentColor'} strokeWidth={2.5} strokeLinecap={'round'} strokeLinejoin={'round'} aria-hidden={true}>
                                        <path d={'M20 6 9 17l-5-5'} />
                                    </svg>
                                )}
                            </div>
                        ))}
                    </div>
                </div>
            )}
        </div>
    );
}
