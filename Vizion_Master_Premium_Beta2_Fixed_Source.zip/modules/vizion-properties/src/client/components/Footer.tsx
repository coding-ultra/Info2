import { DISCORD_URL } from '../brand';

/** Credit line shown at the bottom of both pages. */
export default function Footer() {
    return (
        <p className={'dprop:text-center dprop:text-xs dprop:text-muted-foreground'}>
            Made by{' '}
            <a href={DISCORD_URL} target={'_blank'} rel={'noopener noreferrer'} className={'dprop:font-semibold dprop:text-foreground'}>
                Vizion Development
            </a>
            . Questions or ideas? Join our Discord.
        </p>
    );
}
