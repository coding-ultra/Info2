import { DISCORD_LOGO, DISCORD_URL } from '../brand';

/** "Join our Discord" call to action, a real link in Discord blurple. */
export default function DiscordButton() {
    return (
        <a
            href={DISCORD_URL}
            target={'_blank'}
            rel={'noopener noreferrer'}
            className={'dprop:flex dprop:items-center dprop:gap-2 dprop:rounded-md dprop:px-3 dprop:py-2 dprop:text-sm dprop:font-semibold dprop:no-underline'}
            style={{ background: '#5865f2', color: '#fff' }}
        >
            <img src={DISCORD_LOGO} alt={''} width={20} height={15} aria-hidden={true} />
            Join our Discord
        </a>
    );
}
