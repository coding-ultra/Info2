import { useCallback, useMemo, useState } from 'react';
import { Alert, Button, Input, Spinner, Switch, TitledGreyBox, httpErrorToHuman, toast, useExtensionAction, useServerFileContent, useServerPermission, useWriteServerFile } from '@pterodactyl/sdk';
import type { PropertiesSettings } from '../config';
import { buildRows, changesOf, filterRows, groupRows, isValidCustomKey, missingKeys } from '../model';
import { parseProperties, serializeProperties } from '../properties';
import Dropdown from './Dropdown';
import PropertyRow, { validateValue } from './PropertyRow';

/** True when a computed colour has no (or almost no) fill. */
const isClear = (color: string): boolean => color === 'transparent' || /^rgba\(.*,\s*0(\.0+)?\)$/.test(color) || /\/\s*0(\.0+)?\s*\)$/.test(color);

/**
 * Copies the look of the Panel's own default box (the one every TitledGreyBox has) onto the page as --dp-card-* variables, so
 * the small cards, the search bar, the category buttons and the drop-down lists all use exactly the same colour as that box.
 * A hidden box is rendered inside the page for this, because computed colours can be read even when it is not displayed.
 */
function sampleCard(root: HTMLElement | null): void {
    const probe = root?.querySelector('[data-gb]');
    if (!root || !probe) return;
    const queue: Element[] = [...probe.children];
    for (let depth = 0; queue.length > 0 && depth < 40; depth++) {
        const element = queue.shift()!;
        const style = getComputedStyle(element);
        if (!isClear(style.backgroundColor)) {
            root.style.setProperty('--dp-card-bg', style.backgroundColor);
            if (parseFloat(style.borderTopWidth) > 0 && !isClear(style.borderTopColor)) root.style.setProperty('--dp-card-border', style.borderTopColor);
            if (style.borderTopLeftRadius) root.style.setProperty('--dp-card-radius', style.borderTopLeftRadius);
            return;
        }
        queue.push(...element.children);
    }
}

/** Reads server.properties through the Panel's file API, lets the user search and edit it, and writes it back. */
export default function PropertiesEditor({ serverUuid, settings }: { serverUuid: string; settings: PropertiesSettings }) {
    const canEdit = useServerPermission('file.update');
    const file = useServerFileContent(serverUuid, settings.file);
    const write = useWriteServerFile(serverUuid);

    const [search, setSearch] = useState('');
    const [editedOnly, setEditedOnly] = useState(false);
    const [vizion, setVizion] = useState<Record<string, string>>({});
    const [added, setAdded] = useState<string[]>([]);
    const [customKey, setCustomKey] = useState('');
    const [category, setCategory] = useState('all');
    const rootRef = useCallback((node: HTMLDivElement | null) => sampleCard(node), []);

    const parsed = useMemo(() => parseProperties(file.data ?? ''), [file.data]);
    const rows = useMemo(() => buildRows(parsed, vizion, added, settings.showCustom), [parsed, vizion, added, settings.showCustom]);
    const visible = useMemo(() => filterRows(rows, search, editedOnly), [rows, search, editedOnly]);
    const groups = useMemo(() => groupRows(visible), [visible]);
    const allGroups = useMemo(() => groupRows(rows), [rows]);
    const missing = useMemo(() => missingKeys(parsed, added), [parsed, added]);

    const editedCount = rows.filter((row) => row.edited).length;
    const hasError = rows.some((row) => row.edited && validateValue(row.def, row.value) !== undefined);
    // A category that no longer exists (for example a custom key that was discarded) falls back to "All".
    const activeCategory = allGroups.some((group) => group.category === category) ? category : 'all';
    const shownGroups = activeCategory === 'all' ? groups : groups.filter((group) => group.category === activeCategory);
    const shownCount = shownGroups.reduce((total, group) => total + group.rows.length, 0);
    const customKeyTaken = customKey !== '' && (rows.some((row) => row.def.key === customKey) || parsed.lines.some((line) => line.key === customKey));

    const discard = () => {
        setVizion({});
        setAdded([]);
    };

    const addKey = (key: string) => {
        setAdded((current) => (current.includes(key) ? current : [...current, key]));
        setSearch('');
        setEditedOnly(false);
        setCategory('all');
    };

    const save = useExtensionAction('save properties', async () => {
        try {
            // Re-read the file first, so edits made elsewhere (the file editor, a plugin) to other keys are not overwritten.
            const fresh = await file.refetch();
            const latest = typeof fresh.data === 'string' ? fresh.data : (file.data ?? '');
            const content = serializeProperties(parseProperties(latest), changesOf(rows));

            await write.mutateAsync({ file: settings.file, content });
            await file.refetch();
            discard();
            toast.success('Saved. Restart the server for the changes to apply.');
        } catch (error) {
            toast.error(httpErrorToHuman(error));
        }
    });

    // The same Save / Discard / Reload bar is shown above and below the list, so saving never needs a scroll.
    const actions = canEdit && (
        <div className={'dprop:flex dprop:flex-wrap dprop:items-center dprop:gap-2'}>
            <Button isLoading={write.isPending} disabled={write.isPending || editedCount === 0 || hasError} onClick={save}>
                Save changes
            </Button>
            <Button isSecondary={true} disabled={write.isPending || editedCount === 0} onClick={discard}>
                Discard changes
            </Button>
            <Button isSecondary={true} disabled={write.isPending || file.isFetching} onClick={() => void file.refetch()}>
                Reload file
            </Button>
            <span className={'dprop:text-xs dprop:text-muted-foreground'}>{editedCount === 0 ? 'No unsaved changes.' : `${editedCount} unsaved change${editedCount === 1 ? '' : 's'}.`}</span>
        </div>
    );

    // The category switcher: "All" plus one button per category, each with the number of properties it shows right now.
    const nav = settings.categoryNav;
    const isSidebar = nav === 'sidebar' || nav === 'sidebar-left';
    const tabs = [{ category: 'all', count: visible.length }, ...allGroups.map((group) => ({ category: group.category, count: visible.filter((row) => row.def.category === group.category).length }))];
    const switcher = nav !== 'off' && allGroups.length > 0 && (
        <nav aria-label={'Categories'} data-nav={nav} className={nav === 'sidebar' ? 'dprop:grid dprop:gap-2 dprop:order-first dprop:lg:order-none dprop:lg:self-start' : nav === 'sidebar-left' ? 'dprop:grid dprop:gap-2 dprop:lg:self-start' : 'dprop:flex dprop:flex-wrap dprop:gap-2'}>
            {isSidebar && <p className={'dprop:text-xs dprop:font-semibold dprop:uppercase dprop:text-muted-foreground'}>Categories</p>}
            {tabs.map((item) => (
                <button
                    key={item.category}
                    type={'button'}
                    aria-pressed={activeCategory === item.category}
                    onClick={() => setCategory(item.category)}
                    className={`dprop:flex dprop:cursor-pointer dprop:items-center dprop:justify-between dprop:gap-2 dprop:rounded-md dprop:border dprop:px-3 dprop:text-sm ${isSidebar ? 'dprop:py-2' : 'dprop:py-1'} ${activeCategory === item.category ? 'dprop:border-primary dprop:bg-primary dprop:text-primary-foreground' : 'dprop-tab dprop:border-border dprop:text-foreground'}`}
                >
                    <span>{item.category === 'all' ? 'All' : item.category}</span>
                    <span className={'dprop:text-xs'}>{item.count}</span>
                </button>
            ))}
        </nav>
    );

    if (file.isLoading) return <Spinner centered />;

    if (file.isError) {
        return (
            <Alert type={'danger'}>
                Could not read <code>{settings.file}</code>: {httpErrorToHuman(file.error)}. If the server has never been started, the file may not exist yet. An administrator can change the file location on the Properties admin page.
            </Alert>
        );
    }

    const minimal = settings.minimalCards;

    const searchBox = minimal ? (
        <div data-search={'minimal'} className={'dprop:flex dprop:flex-wrap dprop:items-center dprop:gap-3 dprop:rounded-md dprop:border dprop:border-border dprop:p-3'}>
            <div className={'dprop:w-full dprop:sm:w-auto dprop:sm:flex-1'}>
                <Input value={search} onChange={(event) => setSearch(event.target.value)} placeholder={'Search properties…'} aria-label={'Search properties'} />
            </div>
            <Switch checked={editedOnly} onChange={setEditedOnly} label={'Edited only'} />
            <span className={'dprop:text-xs dprop:text-muted-foreground'}>
                {shownCount} of {rows.length}
            </span>
        </div>
    ) : (
        <TitledGreyBox title={'Search'}>
            <div className={'dprop:grid dprop:gap-3 dprop:sm:grid-cols-[1fr_auto] dprop:sm:items-center'}>
                <Input value={search} onChange={(event) => setSearch(event.target.value)} placeholder={'Search properties, e.g. view-distance, pvp, port…'} aria-label={'Search properties'} />
                <Switch checked={editedOnly} onChange={setEditedOnly} label={'Edited only'} />
            </div>
            <p className={'dprop:mt-2 dprop:text-xs dprop:text-muted-foreground'}>
                Showing {shownCount} of {rows.length} properties.
            </p>
        </TitledGreyBox>
    );

    // Everything under the top bar. With the sidebar it is the left column; otherwise it is simply the rest of the page.
    const body = (
        <>
            {searchBox}

            {canEdit && (
                <TitledGreyBox title={'Add a property'}>
                    <div className={'dprop:grid dprop:gap-3 dprop:sm:grid-cols-2'}>
                        <Dropdown
                            value={null}
                            placeholder={missing.length > 0 ? 'Add a known property…' : 'All known properties are in the file'}
                            searchPlaceholder={'Search…'}
                            aria-label={'Add a known property'}
                            disabled={missing.length === 0}
                            onChange={addKey}
                            options={missing.map((def) => ({ value: def.key, label: def.key, textLabel: `${def.key} ${def.label}` }))}
                        />
                        {settings.showCustom && (
                            <div className={'dprop:flex dprop:gap-2'}>
                                <Input value={customKey} onChange={(event) => setCustomKey(event.target.value.trim())} placeholder={'Or another key'} aria-label={'Other property key'} />
                                <Button
                                    isSecondary={true}
                                    disabled={customKey === '' || !isValidCustomKey(customKey) || customKeyTaken}
                                    onClick={() => {
                                        addKey(customKey);
                                        setCustomKey('');
                                    }}
                                >
                                    Add
                                </Button>
                            </div>
                        )}
                    </div>
                </TitledGreyBox>
            )}

            {shownGroups.length === 0 && (
                <Alert type={'info'}>
                    {rows.length === 0 ? 'This file has no properties yet. Add one above.' : groups.length > 0 ? 'No properties in this category match your search.' : 'No properties match your search.'}
                </Alert>
            )}

            {shownGroups.map((group) => {
                const cards = group.rows.map((row) => (
                    <PropertyRow
                        key={row.def.key}
                        def={row.def}
                        value={row.value}
                        edited={row.edited}
                        disabled={!canEdit || write.isPending}
                        showDescription={settings.showDescriptions}
                        minimal={minimal}
                        onChange={(value) => setVizion((current) => ({ ...current, [row.def.key]: value }))}
                    />
                ));

                // Minimal: a small heading and two cards per row. Normal: one titled box with a row per property.
                return minimal ? (
                    <section key={group.category} className={'dprop:grid dprop:gap-3'}>
                        <h3 className={'dprop:text-sm dprop:font-semibold dprop:text-foreground'}>{group.category}</h3>
                        <div data-layout={'minimal'} className={'dprop:grid dprop:gap-3 dprop:sm:grid-cols-2'}>
                            {cards}
                        </div>
                    </section>
                ) : (
                    <TitledGreyBox key={group.category} title={group.category}>
                        <div className={'dprop:divide-y dprop:divide-border'}>{cards}</div>
                    </TitledGreyBox>
                );
            })}

            {actions}
        </>
    );

    return (
        <div ref={rootRef} className={'dprop:grid dprop:gap-4'}>
            <div data-gb={''} aria-hidden={true} style={{ display: 'none' }}>
                <TitledGreyBox title={'Vizion'}>
                    <span />
                </TitledGreyBox>
            </div>
            <Alert type={'info'}>Changes are written to <code>{settings.file}</code> and take effect after the server restarts.</Alert>
            {!canEdit && <Alert type={'warning'}>You can look at these properties, but you do not have permission to change them.</Alert>}

            {actions}

            {nav === 'navbar' && switcher}

            {nav === 'sidebar' && switcher ? (
                <div className={'dprop:grid dprop:gap-4 dprop:lg:grid-cols-[1fr_14rem]'}>
                    <div className={'dprop:grid dprop:min-w-0 dprop:gap-4'}>{body}</div>
                    {switcher}
                </div>
            ) : nav === 'sidebar-left' && switcher ? (
                // The switcher comes first, which puts it on the left on wide screens and above the list on small ones.
                <div className={'dprop:grid dprop:gap-4 dprop:lg:grid-cols-[14rem_1fr]'}>
                    {switcher}
                    <div className={'dprop:grid dprop:min-w-0 dprop:gap-4'}>{body}</div>
                </div>
            ) : (
                body
            )}
        </div>
    );
}
