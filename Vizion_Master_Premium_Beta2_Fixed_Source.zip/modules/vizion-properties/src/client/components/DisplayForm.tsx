import { useState } from 'react';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { Button, Input, Label, Switch, TitledGreyBox, httpErrorToHuman, toast } from '@pterodactyl/sdk';
import { BUILT_IN, displayKey, saveDisplaySettings, type DisplaySettings } from '../api';
import { isValidFile, type CategoryNav } from '../config';
import Dropdown from './Dropdown';

const clean = (value: string) => value.trim();

/** The settings form of the admin page. Saved values apply to every server. */
export default function DisplayForm({ data }: { data: DisplaySettings }) {
    const queryClient = useQueryClient();
    const [vizion, setVizion] = useState<DisplaySettings>(data);
    const set = <K extends keyof DisplaySettings>(key: K, value: DisplaySettings[K]) => setVizion((current) => ({ ...current, [key]: value }));

    const fileValid = isValidFile(clean(vizion.properties_file));
    const candidate: DisplaySettings = { ...vizion, properties_file: fileValid ? clean(vizion.properties_file) : data.properties_file };
    const dirty = (Object.keys(data) as (keyof DisplaySettings)[]).some((key) => candidate[key] !== data[key]);

    const save = useMutation({
        mutationFn: () => saveDisplaySettings(candidate),
        onSuccess: (saved) => {
            queryClient.setQueryData(displayKey, saved);
            toast.success('Settings saved.');
        },
        onError: (error) => toast.error(httpErrorToHuman(error)),
    });

    return (
        <div className={'dprop:grid dprop:gap-4'}>
            <TitledGreyBox title={'Extension'}>
                <Switch
                    label={vizion.enabled ? 'Properties is on' : 'Properties is off'}
                    description={'Off hides the Properties page for every server. Nothing else is changed, and your settings are kept.'}
                    checked={vizion.enabled}
                    onChange={(value: boolean) => set('enabled', value)}
                />
            </TitledGreyBox>

            <TitledGreyBox title={'File location'}>
                <Label>server.properties path</Label>
                <Input value={vizion.properties_file} onChange={(event) => set('properties_file', event.target.value)} placeholder={'/server.properties'} $hasError={!fileValid} />
                <p className={'dprop:mt-1 dprop:text-xs dprop:text-muted-foreground'}>
                    {fileValid
                        ? 'Where the file is, relative to the server root. The default is /server.properties.'
                        : 'Start with / and use only letters, numbers, dots, dashes, underscores and slashes, ending in a file name. ".." is not allowed.'}
                </p>
            </TitledGreyBox>

            <TitledGreyBox title={'What users see'}>
                <div className={'dprop:grid dprop:gap-4'}>
                    <Switch label={'Show descriptions'} description={'A short explanation under each known property.'} checked={vizion.show_descriptions} onChange={(value: boolean) => set('show_descriptions', value)} />
                    <Switch
                        label={'Show other properties'}
                        description={'List properties that are in the file but not in the built-in list (under Others), and let users add their own keys.'}
                        checked={vizion.show_custom}
                        onChange={(value: boolean) => set('show_custom', value)}
                    />
                </div>
            </TitledGreyBox>

            <TitledGreyBox title={'Appearance'}>
                <Switch
                    label={vizion.minimal_cards ? 'Minimal cards are on' : 'Minimal cards are off'}
                    description={'On shows each property as a small card, two per row. Off shows the normal list, one property per line.'}
                    checked={vizion.minimal_cards}
                    onChange={(value: boolean) => set('minimal_cards', value)}
                />
            </TitledGreyBox>

            <TitledGreyBox title={'Category switcher'}>
                <Label>Where to show it</Label>
                <Dropdown
                    value={vizion.category_nav}
                    aria-label={'Where to show the category switcher'}
                    onChange={(next) => set('category_nav', next as CategoryNav)}
                    options={[
                        { value: 'off', label: 'Off' },
                        { value: 'navbar', label: 'Navbar (a row of tabs above the list)' },
                        { value: 'sidebar-left', label: 'Left sidebar (a list on the left)' },
                        { value: 'sidebar', label: 'Right sidebar (a list on the right)' },
                    ]}
                />
                <p className={'dprop:mt-1 dprop:text-xs dprop:text-muted-foreground'}>Lets users show one category at a time (General, Gameplay, World, ..., Others) instead of the whole file. Off keeps everything on one page.</p>
            </TitledGreyBox>

            <div className={'dprop:flex dprop:flex-wrap dprop:items-center dprop:gap-2'}>
                <Button isLoading={save.isPending} disabled={save.isPending || !fileValid || !dirty} onClick={() => save.mutate()}>
                    Save settings
                </Button>
                <Button isSecondary={true} disabled={save.isPending} onClick={() => setVizion(BUILT_IN)}>
                    Restore built-in defaults
                </Button>
                <span className={'dprop:text-xs dprop:text-muted-foreground'}>Restoring only fills in the form. Nothing changes until you save.</span>
            </div>
        </div>
    );
}
