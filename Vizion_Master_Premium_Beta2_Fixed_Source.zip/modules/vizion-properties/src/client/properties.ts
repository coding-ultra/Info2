/**
 * A small, lossless reader/writer for Java `.properties` files such as server.properties.
 * Lines that are not changed are written back exactly as they were (comments, order, spacing),
 * so saving only touches the values the user edited.
 */

export interface PropLine {
    /** The line exactly as it appears in the file. */
    raw: string;
    /** Set for `key=value` lines; undefined for comments and blank lines. */
    key?: string;
    /** The key as written in the file (it may contain escapes). */
    rawKey?: string;
    /** The unescaped value. */
    value?: string;
}

export interface ParsedProperties {
    lines: PropLine[];
    eol: '\n' | '\r\n';
    /** Whether the file ended with a line break. */
    trailingNewline: boolean;
}

const SIMPLE_ESCAPES: Record<string, string> = { n: '\n', t: '\t', r: '\r', f: '\f' };

export function unescapeProperty(text: string): string {
    let out = '';
    for (let i = 0; i < text.length; i++) {
        const ch = text[i];
        if (ch !== '\\') {
            out += ch;
            continue;
        }
        const next = text[i + 1];
        if (next === undefined) break;
        if (next === 'u' && /^[0-9a-fA-F]{4}$/.test(text.slice(i + 2, i + 6))) {
            out += String.fromCharCode(parseInt(text.slice(i + 2, i + 6), 16));
            i += 5;
        } else {
            out += SIMPLE_ESCAPES[next] ?? next;
            i += 1;
        }
    }
    return out;
}

export function escapeValue(value: string): string {
    let out = '';
    for (let i = 0; i < value.length; i++) {
        const ch = value[i];
        const code = value.charCodeAt(i);
        if (ch === '\\') out += '\\\\';
        else if (ch === '\n') out += '\\n';
        else if (ch === '\r') out += '\\r';
        else if (ch === '\t') out += '\\t';
        else if (ch === '\f') out += '\\f';
        else if (ch === ':' || ch === '=' || ch === '#' || ch === '!') out += `\\${ch}`;
        else if (ch === ' ' && i === 0) out += '\\ ';
        else if (code < 0x20 || code > 0x7e) out += `\\u${code.toString(16).padStart(4, '0')}`;
        else out += ch;
    }
    return out;
}

function escapeKey(key: string): string {
    return escapeValue(key).replace(/ /g, '\\ ');
}

/** Splits `key=value`, `key:value` or `key value` at the first unescaped separator. */
function splitLine(line: string): { rawKey: string; rawValue: string } {
    let i = 0;
    while (i < line.length) {
        const ch = line[i];
        if (ch === '\\') {
            i += 2;
            continue;
        }
        if (ch === '=' || ch === ':' || ch === ' ' || ch === '\t' || ch === '\f') break;
        i++;
    }
    const rawKey = line.slice(0, i);
    let j = i;
    while (j < line.length && (line[j] === ' ' || line[j] === '\t' || line[j] === '\f')) j++;
    if (line[j] === '=' || line[j] === ':') {
        j++;
        while (j < line.length && (line[j] === ' ' || line[j] === '\t' || line[j] === '\f')) j++;
    }
    return { rawKey, rawValue: line.slice(j) };
}

export function parseProperties(text: string): ParsedProperties {
    const eol = text.includes('\r\n') ? '\r\n' : '\n';
    const trailingNewline = /\r?\n$/.test(text);
    const body = trailingNewline ? text.replace(/\r?\n$/, '') : text;
    const rawLines = text === '' ? [] : body.split(/\r?\n/);

    const lines = rawLines.map<PropLine>((raw) => {
        const trimmed = raw.replace(/^[ \t\f]+/, '');
        if (trimmed === '' || trimmed.startsWith('#') || trimmed.startsWith('!')) return { raw };
        const { rawKey, rawValue } = splitLine(trimmed);
        return { raw, rawKey, key: unescapeProperty(rawKey), value: unescapeProperty(rawValue) };
    });

    return { lines, eol, trailingNewline };
}

/** The current value of every key; if a key appears twice, the last one wins, as in Java. */
export function valuesOf(parsed: ParsedProperties): Map<string, string> {
    const map = new Map<string, string>();
    for (const line of parsed.lines) {
        if (line.key !== undefined) map.set(line.key, line.value ?? '');
    }
    return map;
}

/**
 * Writes the file back with `changes` applied (key -> new value). Existing keys are edited in place,
 * keys that are not in the file yet are appended at the end. Untouched lines stay byte for byte.
 */
export function serializeProperties(parsed: ParsedProperties, changes: Record<string, string>): string {
    // If a key appears twice, the last one is the live one, so that is the line to edit.
    const lastIndex = new Map<string, number>();
    parsed.lines.forEach((line, index) => {
        if (line.key !== undefined) lastIndex.set(line.key, index);
    });

    const pending = new Map(Object.entries(changes));
    const out = parsed.lines.map((line, index) => {
        if (line.key === undefined || !pending.has(line.key) || lastIndex.get(line.key) !== index) return line.raw;
        const next = pending.get(line.key) as string;
        pending.delete(line.key);
        return next === line.value ? line.raw : `${line.rawKey}=${escapeValue(next)}`;
    });
    for (const [key, value] of pending) out.push(`${escapeKey(key)}=${escapeValue(value)}`);

    const text = out.join(parsed.eol);
    return out.length > 0 && (parsed.trailingNewline || parsed.lines.length === 0) ? text + parsed.eol : text;
}
