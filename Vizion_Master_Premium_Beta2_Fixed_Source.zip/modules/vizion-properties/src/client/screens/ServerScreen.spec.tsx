import { afterEach, expect, test, vi } from 'vitest';
import { cleanup, fireEvent, render, screen, waitFor } from '@testing-library/react';
import { createExtensionTestHost, createTestServer } from '@pterodactyl/sdk/testing';
import PropertiesEditor from '../components/PropertiesEditor';
import { parseSettings } from '../config';

const FILE = '#header\npvp=true\nview-distance=10\nmotd=Hello\n';

// The editor reads and writes server.properties through the SDK's file hooks, so those are replaced here.
const sdk = vi.hoisted(() => ({
    content: '' as string,
    refetch: vi.fn(),
    write: vi.fn(),
}));

vi.mock('@pterodactyl/sdk', async (importOriginal) => ({
    ...(await importOriginal<typeof import('@pterodactyl/sdk')>()),
    useServerFileContent: () => ({ data: sdk.content, isLoading: false, isError: false, isFetching: false, error: null, refetch: sdk.refetch }),
    useWriteServerFile: () => ({ isPending: false, error: null, data: undefined, reset: () => undefined, mutateAsync: sdk.write }),
}));

let host: ReturnType<typeof createExtensionTestHost> | undefined;

function mount(permissions: string[], overrides: Record<string, unknown> = {}, content = FILE) {
    sdk.content = content;
    sdk.refetch.mockImplementation(async () => ({ data: sdk.content }));
    sdk.write.mockResolvedValue(undefined);
    host = createExtensionTestHost({ extensionId: 'vizion-properties', prefix: 'dprop', server: createTestServer({ owner: false, permissions }) });

    return render(<PropertiesEditor serverUuid={'test-uuid'} settings={parseSettings(overrides)} />, { wrapper: host.Wrapper });
}

afterEach(() => {
    cleanup();
    host?.dispose();
    host = undefined;
    vi.clearAllMocks();
});

test('lists the file as properties, with booleans as On/Off', async () => {
    mount(['file.read-content', 'file.update']);

    expect(await screen.findByText('PvP')).toBeTruthy();
    expect(screen.getByText('View distance')).toBeTruthy();
    expect(screen.getByText('Server message (MOTD)')).toBeTruthy();
    // pvp=true shows as "On", never as the word "true".
    expect(screen.getByText('On')).toBeTruthy();
    expect(screen.queryByText('true')).toBeNull();
});

test('searching narrows the list', async () => {
    mount(['file.read-content', 'file.update']);
    const search = await screen.findByLabelText('Search properties');

    fireEvent.change(search, { target: { value: 'distance' } });
    expect(await screen.findByText('View distance')).toBeTruthy();
    expect(screen.queryByText('PvP')).toBeNull();

    fireEvent.change(search, { target: { value: 'no-such-thing' } });
    expect(await screen.findByText('No properties match your search.')).toBeTruthy();
});

test('toggling a switch and saving writes true/false back to the file, changing only that line', async () => {
    mount(['file.read-content', 'file.update']);

    fireEvent.click(await screen.findByLabelText('PvP'));
    expect(await screen.findByText('Off')).toBeTruthy();
    expect(screen.getAllByText('1 unsaved change.')).toHaveLength(2);

    fireEvent.click(screen.getAllByText('Save changes')[0]!);
    await waitFor(() => expect(sdk.write).toHaveBeenCalledTimes(1));
    expect(sdk.write).toHaveBeenCalledWith({ file: '/server.properties', content: '#header\npvp=false\nview-distance=10\nmotd=Hello\n' });
});

test('a user without file.update can read but not change anything', async () => {
    mount(['file.read-content']);

    expect(await screen.findByText('PvP')).toBeTruthy();
    expect(screen.getByText(/do not have permission to change/)).toBeTruthy();
    expect(screen.queryByText('Save changes')).toBeNull();
    expect(screen.queryByText('Add a property')).toBeNull();
});

test('the Save bar is shown above and below the list, and both buttons save', async () => {
    mount(['file.read-content', 'file.update']);

    await screen.findByText('PvP');
    // Save changes, Discard changes and Reload file each appear twice: once on top, once at the bottom.
    expect(screen.getAllByText('Save changes')).toHaveLength(2);
    expect(screen.getAllByText('Discard changes')).toHaveLength(2);
    expect(screen.getAllByText('Reload file')).toHaveLength(2);

    fireEvent.click(screen.getByLabelText('PvP'));
    const saves = screen.getAllByText('Save changes');
    fireEvent.click(saves[saves.length - 1]!);
    await waitFor(() => expect(sdk.write).toHaveBeenCalledTimes(1));
    expect(sdk.write).toHaveBeenCalledWith({ file: '/server.properties', content: '#header\npvp=false\nview-distance=10\nmotd=Hello\n' });
});

test('normal layout is a list, minimal cards are small cards two per row', async () => {
    const { container, unmount } = mount(['file.read-content', 'file.update']);
    await screen.findByText('PvP');
    expect(container.querySelector('[data-layout="minimal"]')).toBeNull();
    expect(container.querySelectorAll('[data-card]')).toHaveLength(0);
    unmount();

    const minimal = mount(['file.read-content', 'file.update'], { minimal_cards: true });
    await screen.findByText('PvP');
    // pvp, view-distance and motd each get a card, laid out in a two-column grid.
    expect(minimal.container.querySelectorAll('[data-card]')).toHaveLength(3);
    const grid = minimal.container.querySelector('[data-layout="minimal"]');
    expect(grid?.className).toContain('sm:grid-cols-2');
});

test('minimal cards still edit and save the same way', async () => {
    mount(['file.read-content', 'file.update'], { minimal_cards: true });

    fireEvent.click(await screen.findByLabelText('PvP'));
    expect(await screen.findByText('Off')).toBeTruthy();
    fireEvent.click(screen.getAllByText('Save changes')[0]!);
    await waitFor(() => expect(sdk.write).toHaveBeenCalledTimes(1));
    expect(sdk.write).toHaveBeenCalledWith({ file: '/server.properties', content: '#header\npvp=false\nview-distance=10\nmotd=Hello\n' });
});

test('no category switcher unless an administrator turns it on', async () => {
    const { container } = mount(['file.read-content', 'file.update']);
    await screen.findByText('PvP');
    expect(container.querySelector('nav')).toBeNull();
});

test('navbar: category buttons show one category at a time, All shows everything', async () => {
    const { container } = mount(['file.read-content', 'file.update'], { category_nav: 'navbar' });
    await screen.findByText('PvP');
    expect(container.querySelector('nav[data-nav="navbar"]')).toBeTruthy();
    expect(container.querySelector('[class*="lg:grid-cols"]')).toBeNull();

    // pvp is Gameplay, view-distance is Performance, motd is General.
    fireEvent.click(screen.getByRole('button', { name: /^Gameplay/ }));
    expect(screen.getByText('PvP')).toBeTruthy();
    expect(screen.queryByText('View distance')).toBeNull();
    expect(screen.queryByText('Server message (MOTD)')).toBeNull();
    expect(screen.getByRole('button', { name: /^Gameplay/ }).getAttribute('aria-pressed')).toBe('true');

    fireEvent.click(screen.getByRole('button', { name: /^All/ }));
    expect(screen.getByText('PvP')).toBeTruthy();
    expect(screen.getByText('View distance')).toBeTruthy();
    expect(screen.getByText('Server message (MOTD)')).toBeTruthy();
});

test('sidebar: the switcher sits in a right-hand column and filters the same way', async () => {
    const { container } = mount(['file.read-content', 'file.update'], { category_nav: 'sidebar' });
    await screen.findByText('PvP');
    expect(container.querySelector('nav[data-nav="sidebar"]')).toBeTruthy();
    // The switcher comes after the content in the layout, which puts it on the right on wide screens.
    const wrapper = container.querySelector('[class*="lg:grid-cols"]');
    expect(wrapper?.lastElementChild?.tagName).toBe('NAV');

    fireEvent.click(screen.getByRole('button', { name: /^Performance/ }));
    expect(screen.getByText('View distance')).toBeTruthy();
    expect(screen.queryByText('PvP')).toBeNull();
});

test('left sidebar: the switcher sits in a left-hand column and filters the same way', async () => {
    const { container } = mount(['file.read-content', 'file.update'], { category_nav: 'sidebar-left' });
    await screen.findByText('PvP');
    expect(container.querySelector('nav[data-nav="sidebar-left"]')).toBeTruthy();
    // The switcher comes before the content in the layout, which puts it on the left on wide screens.
    const wrapper = container.querySelector('[class*="lg:grid-cols"]');
    expect(wrapper?.firstElementChild?.tagName).toBe('NAV');

    fireEvent.click(screen.getByRole('button', { name: /^Gameplay/ }));
    expect(screen.getByText('PvP')).toBeTruthy();
    expect(screen.queryByText('View distance')).toBeNull();
});

test('keys the built-in list does not know are grouped under Others, not Custom', async () => {
    mount(['file.read-content', 'file.update'], { category_nav: 'navbar' }, 'pvp=true\nmy-plugin-flag=true\n');
    await screen.findByText('PvP');
    expect(screen.getByRole('button', { name: /^Others/ })).toBeTruthy();
    expect(screen.queryByRole('button', { name: /^Custom/ })).toBeNull();
});

test('the category buttons count what the search leaves', async () => {
    mount(['file.read-content', 'file.update'], { category_nav: 'navbar' });
    fireEvent.change(await screen.findByLabelText('Search properties'), { target: { value: 'distance' } });
    expect((await screen.findByRole('button', { name: /^Performance/ })).textContent).toBe('Performance1');
    expect(screen.getByRole('button', { name: /^Gameplay/ }).textContent).toBe('Gameplay0');
});

test('minimal cards use a slim search bar instead of the Search box', async () => {
    const normal = mount(['file.read-content', 'file.update']);
    await screen.findByText('PvP');
    expect(normal.container.querySelector('[data-search="minimal"]')).toBeNull();
    expect(screen.getByText('Search')).toBeTruthy();
    normal.unmount();

    const minimal = mount(['file.read-content', 'file.update'], { minimal_cards: true });
    await screen.findByText('PvP');
    expect(minimal.container.querySelector('[data-search="minimal"]')).toBeTruthy();
    expect(screen.queryByText('Search')).toBeNull();
    fireEvent.change(screen.getByLabelText('Search properties'), { target: { value: 'distance' } });
    expect(await screen.findByText('1 of 3')).toBeTruthy();
});

test('a drop-down opens in the card style, picks an option and marks it edited', async () => {
    mount(['file.read-content', 'file.update'], { minimal_cards: true }, 'difficulty=easy\n');
    const trigger = await screen.findByLabelText('Difficulty');
    fireEvent.click(trigger);

    const list = await screen.findByRole('listbox');
    expect(list.closest('.dprop-dd-panel')).toBeTruthy();
    fireEvent.click(screen.getByRole('option', { name: 'hard' }));

    expect(screen.queryByRole('listbox')).toBeNull();
    expect(screen.getAllByText('1 unsaved change.').length).toBeGreaterThan(0);
    fireEvent.click(screen.getAllByText('Save changes')[0]!);
    await waitFor(() => expect(sdk.write).toHaveBeenCalledWith({ file: '/server.properties', content: 'difficulty=hard\n' }));
});
