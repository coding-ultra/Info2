import { Alert, ServerContentBlock, useCurrentServerRequired } from '@pterodactyl/sdk';
import { getSettings } from '../config';
import Footer from '../components/Footer';
import Header from '../components/Header';
import PropertiesEditor from '../components/PropertiesEditor';

/** The Properties page of a server: search, edit and save server.properties. Settings come from /panel/vizion-properties. */
export default function ServerScreen() {
    const server = useCurrentServerRequired();
    const settings = getSettings();

    return (
        <ServerContentBlock title={'Properties'}>
            <div className={'dprop:grid dprop:gap-4'}>
                <Header title={'Properties'} subtitle={'Search and edit server.properties'} />
                {settings.enabled ? <PropertiesEditor serverUuid={server.attributes.uuid} settings={settings} /> : <Alert type={'info'}>Properties is turned off by an administrator.</Alert>}
                <Footer />
            </div>
        </ServerContentBlock>
    );
}
