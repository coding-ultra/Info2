import './styles.css';
import { definePterodactylExtension } from '@pterodactyl/sdk';
import { setConfig } from './config';

export default definePterodactylExtension({
    setup({ config, screens }) {
        setConfig(config);

        // Both ids are declared in extension.json under ui.screens.
        // "main" is the server page. It declares when.runtime, so the "Enable Properties" setting
        // can hide it (nav item and URL) for everyone. "admin" is /panel/vizion-properties.
        screens.register('main', () => import('./screens/ServerScreen'), {
            visible: ({ config: current }) => current.enabled !== false,
        });
        screens.register('admin', () => import('./screens/AdminScreen'));
    },
});
