import { describe, expect, it } from 'vitest';
import { escapeValue, parseProperties, serializeProperties, unescapeProperty, valuesOf } from './properties';

const FILE = ['#Minecraft server properties', '#Mon Jan 01 00:00:00 UTC 2026', 'allow-flight=false', 'level-type=minecraft\\:normal', 'motd=A Minecraft Server', 'pvp=true', ''].join('\n');

describe('parseProperties', () => {
    it('reads keys and unescapes values', () => {
        const values = valuesOf(parseProperties(FILE));
        expect(values.get('level-type')).toBe('minecraft:normal');
        expect(values.get('pvp')).toBe('true');
        expect(values.size).toBe(4);
    });

    it('handles : and space separators, blank values and comments', () => {
        const values = valuesOf(parseProperties('a: 1\nb 2\nc=\n! note\n\n'));
        expect([...values]).toEqual([['a', '1'], ['b', '2'], ['c', '']]);
    });

    it('uses the last value when a key is repeated', () => {
        expect(valuesOf(parseProperties('x=1\nx=2\n')).get('x')).toBe('2');
    });
});

describe('serializeProperties', () => {
    it('returns the file unchanged when there are no changes', () => {
        expect(serializeProperties(parseProperties(FILE), {})).toBe(FILE);
    });

    it('edits only the changed line and keeps comments and order', () => {
        const out = serializeProperties(parseProperties(FILE), { pvp: 'false' });
        expect(out).toBe(FILE.replace('pvp=true', 'pvp=false'));
    });

    it('does not rewrite a line whose value did not change', () => {
        const out = serializeProperties(parseProperties(FILE), { 'level-type': 'minecraft:normal' });
        expect(out).toBe(FILE);
    });

    it('escapes colons the way Minecraft does', () => {
        const out = serializeProperties(parseProperties(FILE), { 'level-type': 'minecraft:flat' });
        expect(out).toContain('level-type=minecraft\\:flat');
    });

    it('appends new keys and keeps the final newline', () => {
        const out = serializeProperties(parseProperties(FILE), { 'view-distance': '12' });
        expect(out).toBe(`${FILE}view-distance=12\n`);
    });

    it('edits the live (last) copy of a repeated key', () => {
        expect(serializeProperties(parseProperties('x=1\nx=2\n'), { x: '3' })).toBe('x=1\nx=3\n');
    });

    it('keeps Windows line endings', () => {
        expect(serializeProperties(parseProperties('a=1\r\nb=2\r\n'), { b: '3' })).toBe('a=1\r\nb=3\r\n');
    });

    it('writes a new file from nothing', () => {
        expect(serializeProperties(parseProperties(''), { motd: 'Hi' })).toBe('motd=Hi\n');
    });
});

describe('escaping', () => {
    it('round-trips awkward values', () => {
        for (const value of ['a=b:c#d!e', ' leading', 'back\\slash', 'tab\there', 'héllo §6']) {
            expect(unescapeProperty(escapeValue(value))).toBe(value);
        }
    });

    it('writes non-ASCII as \\u escapes', () => {
        expect(escapeValue('é')).toBe('\\u00e9');
    });
});
