import { describe, expect, it } from 'vitest';
import { DEFAULT_FILE, isValidFile, parseSettings } from './config';

describe('parseSettings', () => {
    it('uses defaults when config is empty (pages before sign-in)', () => {
        expect(parseSettings({})).toEqual({ enabled: true, file: DEFAULT_FILE, showDescriptions: true, showCustom: true, minimalCards: false, categoryNav: 'off' });
    });

    it('reads the frontend settings', () => {
        expect(parseSettings({ enabled: false, properties_file: '/config/server.properties', show_descriptions: false, show_custom: false, minimal_cards: true, category_nav: 'sidebar' })).toEqual({
            enabled: false,
            file: '/config/server.properties',
            showDescriptions: false,
            showCustom: false,
            minimalCards: true,
            categoryNav: 'sidebar',
        });
    });

    it('accepts the left-hand sidebar', () => {
        expect(parseSettings({ category_nav: 'sidebar-left' }).categoryNav).toBe('sidebar-left');
    });

    it('ignores values of the wrong type or a path that climbs out', () => {
        const settings = parseSettings({ enabled: 'no', properties_file: '/a/../etc/passwd', show_custom: 1, minimal_cards: 'yes', category_nav: 'left' });
        expect(settings).toEqual({ enabled: true, file: DEFAULT_FILE, showDescriptions: true, showCustom: true, minimalCards: false, categoryNav: 'off' });
    });
});

describe('isValidFile', () => {
    it('accepts file paths and refuses the rest', () => {
        expect(isValidFile('/server.properties')).toBe(true);
        expect(isValidFile('/world/server.properties')).toBe(true);
        expect(isValidFile('server.properties')).toBe(false);
        expect(isValidFile('/mods/')).toBe(false);
        expect(isValidFile('/a/../b')).toBe(false);
        expect(isValidFile('/a b')).toBe(false);
    });
});
