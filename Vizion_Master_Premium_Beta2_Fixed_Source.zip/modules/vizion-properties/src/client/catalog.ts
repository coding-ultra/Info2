export type PropType = 'boolean' | 'number' | 'text' | 'enum' | 'secret';

export interface PropDef {
    key: string;
    label: string;
    description: string;
    category: string;
    type: PropType;
    /** The value Minecraft uses when the key is missing. */
    default?: string;
    options?: string[];
    min?: number;
    max?: number;
}

export const CUSTOM_CATEGORY = 'Others';

/** Display order of the groups. */
export const CATEGORIES = ['General', 'Gameplay', 'World', 'Network', 'Performance', 'Access', 'Resource pack', 'Remote access', CUSTOM_CATEGORY];

const b = (key: string, label: string, category: string, def: 'true' | 'false', description: string): PropDef => ({ key, label, category, type: 'boolean', default: def, description });
const n = (key: string, label: string, category: string, def: string, description: string, min?: number, max?: number): PropDef => ({ key, label, category, type: 'number', default: def, description, min, max });
const t = (key: string, label: string, category: string, def: string, description: string): PropDef => ({ key, label, category, type: 'text', default: def, description });
const e = (key: string, label: string, category: string, def: string, options: string[], description: string): PropDef => ({ key, label, category, type: 'enum', default: def, options, description });

/**
 * The properties Minecraft (and so Paper) reads from server.properties. Anything else in the file is
 * still shown under Others. Keys that a given Minecraft version does not use are harmless.
 */
export const CATALOG: PropDef[] = [
    // General
    t('motd', 'Server message (MOTD)', 'General', 'A Minecraft Server', 'The message shown under the server name in the multiplayer list.'),
    n('max-players', 'Max players', 'General', '20', 'How many players can be online at once.', 0),
    b('white-list', 'Whitelist', 'General', 'false', 'Only players on the whitelist can join.'),
    b('enforce-whitelist', 'Enforce whitelist', 'General', 'false', 'Kick online players who are not on the whitelist when it is reloaded.'),
    b('hide-online-players', 'Hide online players', 'General', 'false', 'Do not show the list of online players in the server list.'),
    b('enable-status', 'Enable status', 'General', 'true', 'Let the server appear as online in the multiplayer list.'),
    b('log-ips', 'Log IP addresses', 'General', 'true', 'Write player IP addresses to the server log.'),
    t('bug-report-link', 'Bug report link', 'General', '', 'A link shown to players on crash screens.'),

    // Gameplay
    e('gamemode', 'Default game mode', 'Gameplay', 'survival', ['survival', 'creative', 'adventure', 'spectator'], 'The game mode new players start in.'),
    b('force-gamemode', 'Force game mode', 'Gameplay', 'false', 'Put players back in the default game mode every time they join.'),
    e('difficulty', 'Difficulty', 'Gameplay', 'easy', ['peaceful', 'easy', 'normal', 'hard'], 'How hard the world is.'),
    b('hardcore', 'Hardcore', 'Gameplay', 'false', 'Players are banned from the server when they die.'),
    b('pvp', 'PvP', 'Gameplay', 'true', 'Players can hurt each other.'),
    b('allow-flight', 'Allow flight', 'Gameplay', 'false', 'Let players fly in survival with mods or plugins without being kicked.'),
    b('allow-nether', 'Allow the Nether', 'Gameplay', 'true', 'Let players travel to the Nether.'),
    b('enable-command-block', 'Command blocks', 'Gameplay', 'false', 'Allow command blocks to run.'),
    n('spawn-protection', 'Spawn protection radius', 'Gameplay', '16', 'Blocks around the world spawn that only operators can change. 0 turns it off.', 0),
    n('op-permission-level', 'Operator permission level', 'Gameplay', '4', 'The permission level new operators get (0 to 4).', 0, 4),
    n('function-permission-level', 'Function permission level', 'Gameplay', '2', 'The permission level data pack functions run with (1 to 4).', 1, 4),
    n('player-idle-timeout', 'Idle kick (minutes)', 'Gameplay', '0', 'Kick players who do nothing for this long. 0 turns it off.', 0),
    b('spawn-animals', 'Spawn animals', 'Gameplay', 'true', 'Animals can spawn (older versions).'),
    b('spawn-monsters', 'Spawn monsters', 'Gameplay', 'true', 'Monsters can spawn (older versions).'),
    b('spawn-npcs', 'Spawn villagers', 'Gameplay', 'true', 'Villagers can spawn (older versions).'),

    // World
    t('level-name', 'World name', 'World', 'world', 'The name of the world folder.'),
    t('level-seed', 'World seed', 'World', '', 'The seed used when the world is first created. Leave empty for a random one.'),
    e('level-type', 'World type', 'World', 'minecraft:normal', ['minecraft:normal', 'minecraft:flat', 'minecraft:large_biomes', 'minecraft:amplified'], 'The kind of world that is generated.'),
    t('generator-settings', 'Generator settings', 'World', '{}', 'Settings for flat or custom worlds, as JSON.'),
    b('generate-structures', 'Generate structures', 'World', 'true', 'Villages, strongholds and other structures are generated.'),
    n('max-world-size', 'Max world size', 'World', '29999984', 'The maximum radius of the world border, in blocks.', 1, 29999984),
    t('initial-enabled-packs', 'Enabled data packs', 'World', 'vanilla', 'Data packs that are on when the world is created.'),
    t('initial-disabled-packs', 'Disabled data packs', 'World', '', 'Data packs that are off when the world is created.'),

    // Network
    t('server-ip', 'Server IP', 'Network', '', 'The address the server listens on. Leave empty on a hosted server.'),
    n('server-port', 'Server port', 'Network', '25565', 'The port players connect to. It must match the port allocated to the server.', 1, 65535),
    b('online-mode', 'Online mode', 'Network', 'true', 'Check player accounts with Mojang. Turn off only behind a proxy that does this.'),
    b('prevent-proxy-connections', 'Block proxy connections', 'Network', 'false', 'Kick players who connect through a VPN or proxy.'),
    b('use-native-transport', 'Native transport', 'Network', 'true', 'Use the optimised Linux network code.'),
    n('network-compression-threshold', 'Compression threshold', 'Network', '256', 'Packets larger than this many bytes are compressed. -1 turns it off.', -1),
    n('rate-limit', 'Packet rate limit', 'Network', '0', 'Kick players who send more packets per second than this. 0 turns it off.', 0),
    b('accepts-transfers', 'Accept transfers', 'Network', 'false', 'Accept players who are sent over from another server.'),

    // Performance
    n('view-distance', 'View distance', 'Performance', '10', 'How many chunks are sent to each player.', 3, 32),
    n('simulation-distance', 'Simulation distance', 'Performance', '10', 'How many chunks around players are kept active.', 3, 32),
    n('entity-broadcast-range-percentage', 'Entity range (%)', 'Performance', '100', 'How far away entities are sent to players, as a percentage.', 10, 1000),
    n('max-tick-time', 'Watchdog time (ms)', 'Performance', '60000', 'The server is stopped if a tick takes this long. -1 turns it off.', -1),
    n('max-chained-neighbor-updates', 'Max chained updates', 'Performance', '1000000', 'Limit on chained block updates. -1 turns it off.', -1),
    b('sync-chunk-writes', 'Sync chunk writes', 'Performance', 'true', 'Write chunks to disk immediately. Safer, a little slower.'),
    e('region-file-compression', 'Region compression', 'Performance', 'deflate', ['deflate', 'lz4', 'none'], 'How world files are compressed on disk.'),
    n('pause-when-empty-seconds', 'Pause when empty (s)', 'Performance', '60', 'Pause the server after this long with no players. -1 turns it off.', -1),

    // Access
    b('enforce-secure-profile', 'Enforce secure profiles', 'Access', 'true', 'Only players with a signed Mojang profile can chat.'),
    b('broadcast-console-to-ops', 'Show console to operators', 'Access', 'true', 'Send console command output to online operators.'),
    b('previews-chat', 'Chat previews', 'Access', 'false', 'Show a preview of chat messages (older versions).'),
    t('text-filtering-config', 'Text filtering config', 'Access', '', 'Path to a chat filtering configuration.'),

    // Resource pack
    t('resource-pack', 'Resource pack URL', 'Resource pack', '', 'A link to a resource pack players are asked to download.'),
    t('resource-pack-id', 'Resource pack ID', 'Resource pack', '', 'A UUID that identifies the resource pack.'),
    t('resource-pack-sha1', 'Resource pack SHA-1', 'Resource pack', '', 'The SHA-1 checksum of the resource pack.'),
    t('resource-pack-prompt', 'Resource pack message', 'Resource pack', '', 'A message shown when players are asked to accept the pack.'),
    b('require-resource-pack', 'Require resource pack', 'Resource pack', 'false', 'Players who decline the pack are disconnected.'),

    // Remote access
    b('enable-rcon', 'Enable RCON', 'Remote access', 'false', 'Allow remote console connections.'),
    n('rcon.port', 'RCON port', 'Remote access', '25575', 'The port RCON listens on.', 1, 65535),
    { key: 'rcon.password', label: 'RCON password', category: 'Remote access', type: 'secret', default: '', description: 'The password for RCON. Choose a strong one.' },
    b('broadcast-rcon-to-ops', 'Show RCON to operators', 'Remote access', 'true', 'Send RCON command output to online operators.'),
    b('enable-query', 'Enable query', 'Remote access', 'false', 'Allow GameSpy4 query requests.'),
    n('query.port', 'Query port', 'Remote access', '25565', 'The port query listens on.', 1, 65535),
    b('enable-jmx-monitoring', 'Enable JMX monitoring', 'Remote access', 'false', 'Expose server data over JMX.'),
];

const BY_KEY = new Map(CATALOG.map((def) => [def.key, def]));

export const knownDefinition = (key: string): PropDef | undefined => BY_KEY.get(key);

/** What the file has for a key the catalog does not know: on/off if it is true/false, otherwise text. */
export function customDefinition(key: string, value: string): PropDef {
    const type: PropType = value === 'true' || value === 'false' ? 'boolean' : 'text';
    return { key, label: key, category: CUSTOM_CATEGORY, type, description: 'Not in the built-in list. Edited as-is.' };
}
