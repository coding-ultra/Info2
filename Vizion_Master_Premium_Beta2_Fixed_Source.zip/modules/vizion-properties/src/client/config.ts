import type { ExtensionConfig } from '@pterodactyl/sdk';

export const DEFAULT_FILE = '/server.properties';

/** Where the category switcher is drawn: not at all, as a row of tabs above the list, or as a list on the left or the right. */
export type CategoryNav = 'off' | 'navbar' | 'sidebar' | 'sidebar-left';

export const CATEGORY_NAVS: CategoryNav[] = ['off', 'navbar', 'sidebar', 'sidebar-left'];

/** Everything the screens read from the extension's frontend settings. */
export interface PropertiesSettings {
    enabled: boolean;
    file: string;
    showDescriptions: boolean;
    showCustom: boolean;
    /** Show each property as a small card (two per row) instead of one row per property. */
    minimalCards: boolean;
    categoryNav: CategoryNav;
}

/** A path inside the server: starts with /, ends with a file name, no "..". Mirrors the backend rule. */
export const isValidFile = (value: string): boolean => /^\/[A-Za-z0-9._/-]*[A-Za-z0-9._-]$/.test(value) && !/(^|\/)\.\.(\/|$)/.test(value);

const flag = (value: unknown, fallback: boolean): boolean => (typeof value === 'boolean' ? value : fallback);

/** Turns raw settings into safe values. Every value falls back to a default, as `config` is empty before sign-in. */
export function parseSettings(raw: object): PropertiesSettings {
    const config = raw as Record<string, unknown>;
    const file = config.properties_file;

    return {
        enabled: flag(config.enabled, true),
        file: typeof file === 'string' && isValidFile(file) ? file : DEFAULT_FILE,
        showDescriptions: flag(config.show_descriptions, true),
        showCustom: flag(config.show_custom, true),
        minimalCards: flag(config.minimal_cards, false),
        categoryNav: CATEGORY_NAVS.find((nav) => nav === config.category_nav) ?? 'off',
    };
}

let current: PropertiesSettings = parseSettings({});

/** Screens never receive `config`, so setup() stores it here. */
export function setConfig(config: ExtensionConfig): void {
    current = parseSettings(config);
}

export function getSettings(): PropertiesSettings {
    return current;
}
