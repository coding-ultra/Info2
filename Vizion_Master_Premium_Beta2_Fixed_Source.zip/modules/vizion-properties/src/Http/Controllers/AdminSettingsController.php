<?php

namespace VizionProperties\Http\Controllers;

use VizionProperties\Settings\DisplaySettings;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Knuckles\Scribe\Attributes\Endpoint;

/**
 * Backs the Properties admin page (/panel/vizion-properties). Routes in routes/admin.php are root-administrator only.
 * (/api/admin/extensions/{id}/settings is reserved by the Panel, hence "display".)
 */
class AdminSettingsController
{
    public function __construct(private readonly DisplaySettings $settings) {}

    #[Endpoint('Show Properties settings', 'The settings every server uses.')]
    public function show(): JsonResponse
    {
        return new JsonResponse(['data' => $this->settings->all()]);
    }

    #[Endpoint('Update Properties settings', 'Saves the settings every server uses.')]
    public function update(Request $request): JsonResponse
    {
        $data = $request->validate([
            'enabled' => ['required', 'boolean'],
            'properties_file' => ['required', 'string', 'max:255', 'regex:#^/[A-Za-z0-9._/-]*[A-Za-z0-9._-]$#', 'not_regex:#(^|/)\.\.(/|$)#'],
            'show_descriptions' => ['required', 'boolean'],
            'show_custom' => ['required', 'boolean'],
            'minimal_cards' => ['sometimes', 'boolean'],
            'category_nav' => ['sometimes', 'string', 'in:off,navbar,sidebar,sidebar-left'],
        ]);

        return new JsonResponse(['data' => $this->settings->save($data)]);
    }
}
