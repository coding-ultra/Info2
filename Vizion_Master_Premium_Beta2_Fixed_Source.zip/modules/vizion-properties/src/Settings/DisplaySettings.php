<?php

namespace VizionProperties\Settings;

use Pterodactyl\Services\Extensions\ExtensionSettings;

/**
 * The administrator settings behind the Properties page (/panel/vizion-properties), stored in the
 * extension's global key-value store under the same keys as the definitions in VizionPropertiesProvider,
 * so Admin -> Extensions and this page always show the same values.
 */
final class DisplaySettings
{
    /** Where the category switcher can be shown. */
    public const CATEGORY_NAV = ['off', 'navbar', 'sidebar', 'sidebar-left'];

    /** The built-in defaults. Mirrors the definitions in VizionPropertiesProvider. */
    public const FALLBACK = [
        'enabled' => true,
        'properties_file' => '/server.properties',
        'show_descriptions' => true,
        'show_custom' => true,
        'minimal_cards' => false,
        'category_nav' => 'off',
    ];

    public function __construct(private readonly ExtensionSettings $store) {}

    /** @return array{enabled: bool, properties_file: string, show_descriptions: bool, show_custom: bool, minimal_cards: bool, category_nav: string} */
    public function all(): array
    {
        $raw = [];
        foreach (self::FALLBACK as $key => $default) {
            $raw[$key] = $this->store->get($key, $default);
        }

        return self::normalize($raw);
    }

    /**
     * @param array<string, mixed> $values
     * @return array{enabled: bool, properties_file: string, show_descriptions: bool, show_custom: bool, minimal_cards: bool, category_nav: string}
     */
    public function save(array $values): array
    {
        $clean = self::normalize($values, $this->all());
        $this->store->setMany($clean);

        return $clean;
    }

    /**
     * Coerces raw values to the types the UI expects; anything unusable falls back to $base.
     *
     * @param array<string, mixed> $raw
     * @param array<string, mixed> $base
     * @return array{enabled: bool, properties_file: string, show_descriptions: bool, show_custom: bool, minimal_cards: bool, category_nav: string}
     */
    public static function normalize(array $raw, array $base = self::FALLBACK): array
    {
        $bool = static fn (string $key): bool => array_key_exists($key, $raw)
            ? filter_var($raw[$key], FILTER_VALIDATE_BOOLEAN)
            : (bool) $base[$key];

        $file = $raw['properties_file'] ?? null;
        $valid = is_string($file)
            && strlen($file) <= 255
            && preg_match('#^/[A-Za-z0-9._/-]*[A-Za-z0-9._-]$#', $file) === 1
            && preg_match('#(^|/)\.\.(/|$)#', $file) !== 1;

        $nav = $raw['category_nav'] ?? $base['category_nav'] ?? 'off';
        if (! is_string($nav) || ! in_array($nav, self::CATEGORY_NAV, true)) {
            $nav = in_array($base['category_nav'] ?? null, self::CATEGORY_NAV, true) ? $base['category_nav'] : 'off';
        }

        return [
            'enabled' => $bool('enabled'),
            'properties_file' => $valid ? $file : (string) $base['properties_file'],
            'show_descriptions' => $bool('show_descriptions'),
            'show_custom' => $bool('show_custom'),
            'minimal_cards' => $bool('minimal_cards'),
            'category_nav' => $nav,
        ];
    }
}
