# Vizion Master — corrected source package

This archive contains the Vizion Premium Compact master extension and the original PHP,
route, migration, manifest and TS/TSX source for all 24 bundled modules. It deliberately
contains no `node_modules/` or `dist/` directories. The root `dist/client.js` must be built
from the corrected source before the Extension Manager can install it.

Target: Pterodactyl Panel V2.0.0-beta.2 with the supplied Extension SDK requirement
`>=2.0.0-beta.6 <3.0`.

Place this folder at `<panel-root>/extensions/vizion`, ensure the matching SDK exists at
`<panel-root>/packages/sdk`, then run:

```bash
./build-vizion.sh
```

Read `INTEGRATION_STATUS.md` and the accompanying DOCX report. The master configuration
page now uses the original admin React screens and the original providers' registered SDK
settings schemas. It does not generate arbitrary placeholder settings.
