const path = require('node:path');
const webpack = require('webpack');
const { WebpackAssetsManifest } = require('webpack-assets-manifest');
const TerserPlugin = require('terser-webpack-plugin');
const MonacoWebpackPlugin = require('monaco-editor-webpack-plugin');

const isProduction = process.env.NODE_ENV === 'production';

module.exports = {
    cache: true,
    target: 'web',
    mode: isProduction ? 'production' : 'development',
    devtool: process.env.DEVTOOL || (isProduction ? false : 'eval-source-map'),
    performance: {
        hints: false,
    },
    entry: ['react-hot-loader/patch', './resources/scripts/index.tsx'],
    output: {
        path: path.join(__dirname, '/public/assets'),
        filename: isProduction ? 'bundle.[chunkhash:8].js' : 'bundle.[fullhash:8].js',
        chunkFilename: isProduction ? '[name].[chunkhash:8].js' : '[name].[fullhash:8].js',
        publicPath: process.env.WEBPACK_PUBLIC_PATH || '/assets/',
        crossOriginLoading: 'anonymous',
    },
    module: {
        rules: [
            {
                test: /\.tsx?$/,
                exclude: /node_modules|\.spec\.tsx?$/,
                loader: 'babel-loader',
            },
            {
                test: /\.mjs$/,
                include: /node_modules/,
                type: 'javascript/auto',
            },
            {
                test: /\.css$/,
                use: [
                    { loader: 'style-loader' },
                    {
                        loader: 'css-loader',
                        options: {
                            modules: {
                                auto: true,
                                
                                namedExport: false,
                                exportLocalsConvention: 'as-is',
                                localIdentName: isProduction ? '[name]_[hash:base64:8]' : '[path][name]__[local]',
                                localIdentContext: path.join(__dirname, 'resources/scripts/components'),
                            },

                            url: { filter: (url) => !url.startsWith('/') },
                            sourceMap: !isProduction,
                            importLoaders: 1,
                        },
                    },
                    {
                        loader: 'postcss-loader',
                        options: { sourceMap: !isProduction },
                    },
                ],
            },
            {
                test: /\.(png|jp(e?)g|gif)$/,
                loader: 'file-loader',
                options: {
                    name: 'images/[name].[hash:8].[ext]',
                },
            },
            {
                test: /\.(woff|woff2)$/i,
                type: 'asset/resource',
            },
            {
                test: /\.svg$/,
                loader: 'svg-url-loader',
            },
            {
                test: /\.js$/,
                enforce: 'pre',
                loader: 'source-map-loader',
            },
        ],
    },
    ignoreWarnings: [{ module: /node_modules[\\/]monaco-editor/ }],
    stats: {

        warningsFilter: [/Failed to parse source map/],
    },
    resolve: {
        extensions: ['.ts', '.tsx', '.js', '.json'],
        alias: {
            
            'lucide-react$': path.join(__dirname, '/resources/scripts/dezerx/icons/index.tsx'),
            '@': path.join(__dirname, '/resources/scripts'),
            '@definitions': path.join(__dirname, '/resources/scripts/api/definitions'),
            '@feature': path.join(__dirname, '/resources/scripts/components/server/features'),
        },
        symlinks: false,
    },
    externals: {

        moment: 'moment',
    },
    plugins: [
        new webpack.EnvironmentPlugin({
            NODE_ENV: process.env.NODE_ENV || 'development',
            DEBUG: process.env.NODE_ENV !== 'production',
            WEBPACK_BUILD_HASH: Date.now().toString(16),
        }),
        new MonacoWebpackPlugin({
            filename: isProduction ? '[name].worker.[contenthash:8].js' : '[name].worker.js',
            languages: [
                'bat', 'coffee', 'cpp', 'csharp', 'css', 'dockerfile', 'go', 'graphql',
                'handlebars', 'html', 'ini', 'java', 'javascript', 'json', 'less', 'lua',
                'markdown', 'mysql', 'perl', 'php', 'powershell', 'pug', 'python', 'r', 'ruby',
                'rust', 'scss', 'shell', 'sql', 'typescript', 'xml', 'yaml',
            ],
        }),
        new WebpackAssetsManifest({
            output: 'manifest.json',
            writeToDisk: true,
            publicPath: true,
            integrity: true,
            integrityHashes: ['sha384'],
        }),
    ],
    optimization: {
        usedExports: true,
        sideEffects: false,
        runtimeChunk: false,
        removeEmptyChunks: true,
        minimize: isProduction,
        minimizer: [
            new TerserPlugin({
                parallel: true,
                extractComments: false,
                terserOptions: {
                    mangle: true,
                    output: {
                        comments: false,
                    },
                },
            }),
        ],
    },
    watchOptions: {
        poll: 1000,
        ignored: /node_modules/,
    },
    devServer: {
        compress: true,
        port: 5173,
        server: {
            type: 'https',
            options: process.env.USE_LOCAL_CERTS
                ? {
                      ca: path.join(__dirname, '../../docker/certificates/root_ca.pem'),
                      cert: path.join(__dirname, '../../docker/certificates/pterodactyl.test.pem'),
                      key: path.join(__dirname, '../../docker/certificates/pterodactyl.test-key.pem'),
                  }
                : undefined,
        },
        static: {
            directory: path.join(__dirname, '/public'),
            publicPath: process.env.WEBPACK_PUBLIC_PATH || '/assets/',
        },
        allowedHosts: ['.pterodactyl.test'],
        headers: {
            'Access-Control-Allow-Origin': '*',
        },
    },
};
