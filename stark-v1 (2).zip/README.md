## HOW TO GET YOU'RE LICENSE
- Join our Discord: https://discord.gg/UhnQFuxzDX
- Create a ticket under Stark Pterodactyl Theme category
- Wait, ping us if needed. License will be given in a matter of minutes sometimes hours!

## INSTALLING
- Open SFTp and go inside /var/www/pterodactyl
- Drag and drop the **stark-vX.zip**.
- unzip stark-v1.zip -d stark-installer
- cd stark-installer
- sudo bash install.sh

## UPDATING
- Upload the new **stark-vX.zip** into /var/www/pterodactyl (or beside update.sh).
- unzip stark-vX.zip -d stark-installer
- cd stark-installer
- sudo bash update.sh
- Pick the zip from the list.

## Notes
- The license is bound to the panel's **domain**. In order to change please reopen ticket!
- Do not share this with any developer unless super trusted. 97% of the time it doesn't end good. It may cause you everything. If you want us to install it for you. Just create a ticket.
- No refunds
- No leaking or redistributing the code or part of the code.
- Join our Discord for support: https://discord.gg/UhnQFuxzDX
