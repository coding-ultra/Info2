<?php

namespace DriftMod\Http\Controllers;

use DriftMod\Services\EggVisibility;
use DriftMod\Services\ModrinthClient;
use DriftMod\Services\ModrinthUnavailableException;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Knuckles\Scribe\Attributes\Endpoint;
use Pterodactyl\Models\Server;
use Pterodactyl\Services\Extensions\ExtensionSettingsRegistry;

class BrowseController
{
    public function __construct(private readonly ExtensionSettingsRegistry $settings, private readonly EggVisibility $eggs) {}

    #[Endpoint('Is Drift Mod available', 'Whether Drift Mod is shown for this server\'s egg.')]
    public function availability(Server $server): JsonResponse
    {
        return new JsonResponse(['data' => $this->eggs->forServer($server)]);
    }

    #[Endpoint('Get filter options', 'Mod loaders, release game versions and mod categories available on Modrinth.')]
    public function meta(Request $request, Server $server): JsonResponse
    {
        $this->authorize($request, $server);

        return $this->respond(fn () => $this->client()->meta());
    }

    #[Endpoint('Search mods', 'Searches Modrinth for Minecraft mods.')]
    public function search(Request $request, Server $server): JsonResponse
    {
        $this->authorize($request, $server);

        $data = $request->validate([
            'query' => ['nullable', 'string', 'max:100'],
            'loader' => ['nullable', 'string', 'in:'.implode(',', ModrinthClient::MOD_LOADERS)],
            'game_version' => ['nullable', 'string', 'regex:/^[A-Za-z0-9._+-]{1,32}$/'],
            'category' => ['nullable', 'string', 'regex:/^[a-z0-9_-]{1,48}$/'],
            'sort' => ['nullable', 'in:relevance,downloads,follows,newest,updated'],
            'page' => ['nullable', 'integer', 'min:1', 'max:100'],
            'server_only' => ['nullable', 'boolean'],
        ]);

        return $this->respond(fn () => $this->client()->search(
            $data['query'] ?? null,
            $data['loader'] ?? null,
            $data['game_version'] ?? null,
            $data['category'] ?? null,
            $data['sort'] ?? 'relevance',
            (int) ($data['page'] ?? 1),
            (bool) ($data['server_only'] ?? true),
        ));
    }

    #[Endpoint('Get mod details', 'Description, gallery, links and stats of one Modrinth project.')]
    public function details(Request $request, Server $server, string $project): JsonResponse
    {
        $this->authorize($request, $server);
        $this->validateId($project);

        return $this->respond(fn () => $this->client()->project($project));
    }

    #[Endpoint('List mod versions', 'Installable versions of one Modrinth project.')]
    public function versions(Request $request, Server $server, string $project): JsonResponse
    {
        $this->authorize($request, $server);
        $this->validateId($project);

        $data = $request->validate([
            'loader' => ['nullable', 'string', 'in:'.implode(',', ModrinthClient::MOD_LOADERS)],
            'game_version' => ['nullable', 'string', 'regex:/^[A-Za-z0-9._+-]{1,32}$/'],
        ]);

        return $this->respond(fn () => ['data' => $this->client()->versions(
            $project,
            $data['loader'] ?? null,
            $data['game_version'] ?? null,
        )]);
    }

    #[Endpoint('Get one mod version', 'A single Modrinth version, used to resolve a dependency that pins an exact version.')]
    public function version(Request $request, Server $server, string $version): JsonResponse
    {
        $this->authorize($request, $server);
        $this->validateId($version, 'version');

        return $this->respond(fn () => ['data' => $this->client()->version($version)]);
    }

    /** Installing needs the same permissions as the Panel's own remote file download. */
    private function authorize(Request $request, Server $server): void
    {
        $this->eggs->abortUnlessAllowed($server);

        $user = $request->user();

        abort_unless($user->can('file.create', $server) && $user->can('file.update', $server), 403, 'You do not have permission to install mods on this server.');
    }

    private function validateId(string $id, string $field = 'project'): void
    {
        validator([$field => $id], [$field => ['required', 'regex:/^[A-Za-z0-9_.-]{2,64}$/']])->validate();
    }

    private function client(): ModrinthClient
    {
        $contact = '';
        $minutes = 10;

        // Never let a settings hiccup take the whole browser down: fall back to the defaults.
        try {
            $settings = \Vizion\Support\ModuleSettings::of($this->settings, 'drift-mod');
            $contact = (string) $settings->get('contact');
            $minutes = (int) $settings->get('cache_minutes');
        } catch (\Throwable $e) {
            report($e);
        }

        // Header values must stay on one line.
        $contact = trim(preg_replace('/[\r\n]+/', ' ', $contact) ?? '');

        return new ModrinthClient($contact, $minutes > 0 ? $minutes : 10);
    }

    private function respond(callable $callback): JsonResponse
    {
        try {
            return new JsonResponse($callback());
        } catch (ModrinthUnavailableException $e) {
            return new JsonResponse(['errors' => [['code' => 'ModrinthUnavailable', 'status' => '502', 'detail' => $e->getMessage()]]], 502);
        } catch (\Throwable $e) {
            // Logged in storage/logs, and described to the user instead of a blank 500.
            report($e);

            return new JsonResponse(['errors' => [['code' => 'DriftModError', 'status' => '500', 'detail' => 'Drift Mod failed: '.class_basename($e).': '.$e->getMessage()]]], 500);
        }
    }
}
