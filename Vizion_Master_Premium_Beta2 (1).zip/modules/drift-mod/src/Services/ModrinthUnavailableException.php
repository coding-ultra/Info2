<?php

namespace DriftMod\Services;

use RuntimeException;

class ModrinthUnavailableException extends RuntimeException {}
