<?php

namespace DriftMod\Services;

use Illuminate\Http\Client\ConnectionException;
use Illuminate\Http\Client\RequestException;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Http;

/**
 * Thin, cached wrapper around the public Modrinth v2 API, limited to server-side Minecraft mods.
 */
class ModrinthClient
{
    public const BASE_URL = 'https://api.modrinth.com/v2';

    public const DOWNLOAD_HOST = 'cdn.modrinth.com';

    public const PROJECT_TYPE = 'mod';

    /** Loaders that run server mods; used as the default filter and to trim Modrinth's loader list. */
    public const MOD_LOADERS = ['fabric', 'forge', 'neoforge', 'quilt'];

    public const PER_PAGE = 12;

    public const MAX_DEPENDENCIES = 10;

    public function __construct(private readonly string $contact, private readonly int $cacheMinutes) {}

    /**
     * @return array{hits: list<array<string, mixed>>, total: int, page: int, per_page: int, total_pages: int}
     */
    public function search(?string $query, ?string $loader, ?string $gameVersion, ?string $category, string $sort, int $page, bool $serverOnly = true): array
    {
        $loaders = $loader ? [$loader] : self::MOD_LOADERS;

        $facets = [
            ['project_type:'.self::PROJECT_TYPE],
            array_map(fn (string $l) => "categories:$l", $loaders),
        ];
        if ($gameVersion) {
            $facets[] = ["versions:$gameVersion"];
        }
        if ($category) {
            $facets[] = ["categories:$category"];
        }
        if ($serverOnly) {
            // Hide client-only mods (minimaps, shaders, HUDs…): they do nothing on a dedicated server.
            $facets[] = ['server_side:required', 'server_side:optional'];
        }

        $params = [
            'query' => $query ?? '',
            'facets' => json_encode($facets),
            'index' => $sort,
            'limit' => self::PER_PAGE,
            'offset' => ($page - 1) * self::PER_PAGE,
        ];

        $body = $this->get('/search', $params);

        $total = (int) ($body['total_hits'] ?? 0);

        return [
            'hits' => array_values(array_map(fn (array $hit) => [
                'project_id' => (string) ($hit['project_id'] ?? ''),
                'slug' => (string) ($hit['slug'] ?? $hit['project_id'] ?? ''),
                'title' => (string) ($hit['title'] ?? ''),
                'description' => (string) ($hit['description'] ?? ''),
                'icon_url' => is_string($hit['icon_url'] ?? null) ? $hit['icon_url'] : null,
                'banner_url' => $this->bannerUrl($hit),
                'author' => (string) ($hit['author'] ?? ''),
                'downloads' => (int) ($hit['downloads'] ?? 0),
                'follows' => (int) ($hit['follows'] ?? 0),
                'categories' => array_values(array_filter((array) ($hit['display_categories'] ?? $hit['categories'] ?? []), 'is_string')),
                'server_side' => $this->side($hit['server_side'] ?? null),
                'client_side' => $this->side($hit['client_side'] ?? null),
                'date_modified' => is_string($hit['date_modified'] ?? null) ? $hit['date_modified'] : null,
            ], array_filter((array) ($body['hits'] ?? []), 'is_array'))),
            'total' => $total,
            'page' => $page,
            'per_page' => self::PER_PAGE,
            'total_pages' => max(1, (int) ceil($total / self::PER_PAGE)),
        ];
    }

    /**
     * Everything the "details" popup shows about one project.
     *
     * @return array<string, mixed>
     */
    public function project(string $project): array
    {
        $p = $this->get('/project/'.rawurlencode($project), []);

        $https = fn ($url) => is_string($url) && str_starts_with($url, 'https://') ? $url : null;
        $strings = fn ($list) => array_values(array_filter((array) $list, 'is_string'));

        $gallery = [];
        foreach ((array) ($p['gallery'] ?? []) as $image) {
            $url = is_array($image) ? ($image['url'] ?? null) : null;
            if (is_string($url) && str_starts_with($url, 'https://'.self::DOWNLOAD_HOST.'/')) {
                $gallery[] = ['url' => $url, 'title' => (string) ($image['title'] ?? ''), 'description' => (string) ($image['description'] ?? '')];
            }
            if (count($gallery) >= 12) {
                break;
            }
        }

        return [
            'project_id' => (string) ($p['id'] ?? $project),
            'slug' => (string) ($p['slug'] ?? $project),
            'title' => (string) ($p['title'] ?? ''),
            'description' => (string) ($p['description'] ?? ''),
            'body' => mb_substr((string) ($p['body'] ?? ''), 0, 20000),
            'icon_url' => $https($p['icon_url'] ?? null),
            'gallery' => $gallery,
            'categories' => $strings($p['categories'] ?? []),
            'loaders' => $strings($p['loaders'] ?? []),
            'game_versions' => array_slice($strings($p['game_versions'] ?? []), -12),
            'server_side' => $this->side($p['server_side'] ?? null),
            'client_side' => $this->side($p['client_side'] ?? null),
            'downloads' => (int) ($p['downloads'] ?? 0),
            'followers' => (int) ($p['followers'] ?? 0),
            'license' => is_array($p['license'] ?? null) ? (string) ($p['license']['name'] ?? $p['license']['id'] ?? '') : '',
            'published' => is_string($p['published'] ?? null) ? $p['published'] : null,
            'updated' => is_string($p['updated'] ?? null) ? $p['updated'] : null,
            'links' => array_filter([
                'source' => $https($p['source_url'] ?? null),
                'issues' => $https($p['issues_url'] ?? null),
                'wiki' => $https($p['wiki_url'] ?? null),
                'discord' => $https($p['discord_url'] ?? null),
            ]),
        ];
    }

    /**
     * Versions of a project that carry an installable jar hosted on Modrinth's CDN.
     *
     * @return list<array<string, mixed>>
     */
    public function versions(string $project, ?string $loader, ?string $gameVersion): array
    {
        $params = [];
        $params['loaders'] = json_encode($loader ? [$loader] : self::MOD_LOADERS);
        if ($gameVersion) {
            $params['game_versions'] = json_encode([$gameVersion]);
        }

        $out = [];
        foreach ($this->get('/project/'.rawurlencode($project).'/version', $params) as $version) {
            $mapped = is_array($version) ? $this->mapVersion($version) : null;
            if ($mapped !== null) {
                $out[] = $mapped;
            }
        }

        return $out;
    }

    /**
     * One specific version (used to resolve a dependency that pins an exact version).
     *
     * @return array<string, mixed>|null null when it has no installable jar
     */
    public function version(string $version): ?array
    {
        return $this->mapVersion($this->get('/version/'.rawurlencode($version), []));
    }

    /**
     * Filter options for the browse UI.
     *
     * @return array{loaders: list<array{id: string, name: string}>, game_versions: list<string>, categories: list<string>}
     */
    public function meta(): array
    {
        $names = ['fabric' => 'Fabric', 'forge' => 'Forge', 'neoforge' => 'NeoForge', 'quilt' => 'Quilt'];

        $loaders = [];
        foreach ($this->get('/tag/loader', [], 60) as $loader) {
            if (in_array($loader['name'] ?? null, self::MOD_LOADERS, true)) {
                $loaders[] = ['id' => $loader['name'], 'name' => $names[$loader['name']] ?? ucfirst($loader['name'])];
            }
        }

        $versions = [];
        foreach ($this->get('/tag/game_version', [], 60) as $version) {
            if (($version['version_type'] ?? '') === 'release') {
                $versions[] = $version['version'];
            }
        }

        $categories = [];
        foreach ($this->get('/tag/category', [], 60) as $category) {
            if (($category['project_type'] ?? '') === self::PROJECT_TYPE) {
                $categories[] = $category['name'];
            }
        }

        return [
            'loaders' => $loaders,
            'game_versions' => array_slice($versions, 0, 120),
            'categories' => $categories,
        ];
    }

    /**
     * @param  array<string, mixed>  $version
     * @return array<string, mixed>|null
     */
    private function mapVersion(array $version): ?array
    {
        if (! isset($version['id'])) {
            return null;
        }

        $file = null;
        foreach ((array) ($version['files'] ?? []) as $candidate) {
            if (! is_array($candidate) || ! $this->isDownloadable((string) ($candidate['url'] ?? ''), (string) ($candidate['filename'] ?? ''))) {
                continue;
            }
            if ($file === null || ($candidate['primary'] ?? false)) {
                $file = $candidate;
            }
        }
        if ($file === null) {
            return null;
        }

        return [
            'id' => (string) $version['id'],
            'project_id' => (string) ($version['project_id'] ?? ''),
            'name' => (string) ($version['name'] ?? $version['version_number'] ?? ''),
            'version_number' => (string) ($version['version_number'] ?? ''),
            'version_type' => (string) ($version['version_type'] ?? 'release'),
            'game_versions' => array_values((array) ($version['game_versions'] ?? [])),
            'loaders' => array_values((array) ($version['loaders'] ?? [])),
            'date_published' => $version['date_published'] ?? null,
            'downloads' => (int) ($version['downloads'] ?? 0),
            'dependencies' => $this->requiredDependencies((array) ($version['dependencies'] ?? [])),
            'file' => [
                'url' => $file['url'],
                'filename' => $file['filename'],
                'size' => (int) ($file['size'] ?? 0),
                'sha512' => $file['hashes']['sha512'] ?? null,
            ],
        ];
    }

    /**
     * Only hard ("required") dependencies that point at another Modrinth project.
     *
     * @param  array<mixed>  $dependencies
     * @return list<array{project_id: string, version_id: string|null}>
     */
    private function requiredDependencies(array $dependencies): array
    {
        $out = [];
        foreach ($dependencies as $dependency) {
            if (! is_array($dependency) || ($dependency['dependency_type'] ?? '') !== 'required') {
                continue;
            }
            $project = $dependency['project_id'] ?? null;
            if (! is_string($project) || ! preg_match('/^[A-Za-z0-9_.-]{2,64}$/', $project) || isset($out[$project])) {
                continue;
            }
            $versionId = $dependency['version_id'] ?? null;
            $out[$project] = [
                'project_id' => $project,
                'version_id' => is_string($versionId) && preg_match('/^[A-Za-z0-9_.-]{2,64}$/', $versionId) ? $versionId : null,
            ];
            if (count($out) >= self::MAX_DEPENDENCIES) {
                break;
            }
        }

        return array_values($out);
    }

    private function side(mixed $value): string
    {
        return in_array($value, ['required', 'optional', 'unsupported'], true) ? $value : 'unknown';
    }

    /** Only jar files served from Modrinth's own CDN are ever handed to the browser for installation. */
    private function isDownloadable(string $url, string $filename): bool
    {
        return parse_url($url, PHP_URL_SCHEME) === 'https'
            && parse_url($url, PHP_URL_HOST) === self::DOWNLOAD_HOST
            && str_ends_with(strtolower($filename), '.jar');
    }

    /**
     * @param  array<string, scalar>  $params
     * @return array<mixed>
     *
     * @throws ModrinthUnavailableException
     */
    private function get(string $path, array $params, ?int $minutes = null): array
    {
        $key = 'ext.vizion.drift-mod-'.md5($path.json_encode($params));

        // Remembers what Modrinth answered, so a broken cache store can never cause a second request.
        $fetched = false;
        $result = [];

        $fetch = function () use ($path, $params, &$fetched, &$result) {
            try {
                $agent = 'DriftMod/1.0.0'.($this->contact !== '' ? " ({$this->contact})" : '');

                $result = Http::withUserAgent($agent)
                    ->acceptJson()
                    ->timeout(10)
                    ->get(self::BASE_URL.$path, $params)
                    ->throw()
                    ->json() ?? [];
                $fetched = true;

                return $result;
            } catch (ConnectionException|RequestException $e) {
                throw new ModrinthUnavailableException('Modrinth could not be reached. Try again shortly.', 0, $e);
            }
        };

        try {
            return Cache::remember($key, now()->addMinutes($minutes ?? $this->cacheMinutes), $fetch);
        } catch (ModrinthUnavailableException $e) {
            throw $e;
        } catch (\Throwable $e) {
            // The Panel's cache store is unwritable (e.g. storage/framework/cache has the wrong
            // owner). Caching is only an optimisation, so answer without it instead of failing.
            report($e);

            // Modrinth may already have answered before the cache failed: reuse that answer.
            return $fetched ? $result : $fetch();
        }
    }

    /** Featured gallery image (or the first gallery image) of a hit, only if it is served from Modrinth's CDN. */
    private function bannerUrl(array $hit): ?string
    {
        $gallery = is_array($hit['gallery'] ?? null) ? ($hit['gallery'][0] ?? null) : null;
        $url = $hit['featured_gallery'] ?? $gallery;

        return is_string($url) && str_starts_with($url, 'https://'.self::DOWNLOAD_HOST.'/') ? $url : null;
    }
}
