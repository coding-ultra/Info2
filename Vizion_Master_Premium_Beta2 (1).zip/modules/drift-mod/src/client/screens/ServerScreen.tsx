import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Alert, ServerContentBlock, Spinner, httpErrorToHuman, useCurrentServerRequired } from '@pterodactyl/sdk';
import { getAvailability } from '../api';
import { getInstallDirectory, getLayout } from '../config';
import BrowsePage from '../components/BrowsePage';
import Header, { type View } from '../components/Header';
import ManagerPage from '../components/ManagerPage';

const PAGES: Record<View, { title: string; subtitle: string }> = {
    browse: { title: 'Drift Mod', subtitle: 'Install Modrinth mods' },
    manager: { title: 'Mod Manager', subtitle: 'Manage installed mods' },
};

/**
 * The Drift Mod screen for a server. Browse and Mod manager are pages inside it, switched from the header,
 * so neither depends on router navigation to be reachable. Display settings come from the administrator
 * page at /panel/drift-mods.
 */
export default function ServerScreen() {
    const server = useCurrentServerRequired();
    const uuid = server.attributes.uuid;
    const [view, setView] = useState<View>('browse');
    const settings = { directory: getInstallDirectory(), layout: getLayout() };
    const page = PAGES[view];

    // Drift Mod only applies to eggs the administrator allows (Minecraft category by default, plus per-egg overrides).
    const availability = useQuery({ queryKey: ['drift-mod', 'availability', uuid], queryFn: () => getAvailability(uuid), staleTime: 60 * 1000 });

    if (availability.isLoading) {
        return (
            <ServerContentBlock title={'Drift Mod'}>
                <Spinner centered />
            </ServerContentBlock>
        );
    }

    if (availability.isError) {
        return (
            <ServerContentBlock title={'Drift Mod'}>
                <Alert type={'danger'}>{httpErrorToHuman(availability.error)}</Alert>
            </ServerContentBlock>
        );
    }

    if (!availability.data?.enabled) {
        return (
            <ServerContentBlock title={'Drift Mod'}>
                <Alert type={'warning'}>{"Drift Mod isn't available for this server's egg."}</Alert>
            </ServerContentBlock>
        );
    }

    return (
        <ServerContentBlock title={page.title}>
            <div className={'vz:grid vz:gap-4'}>
                <Header subtitle={page.subtitle} view={view} onNavigate={setView} />

                {/* Stays mounted while the manager is open, so the search and filters are still there when you come back. */}
                <div style={view === 'browse' ? undefined : { display: 'none' }}>
                    <BrowsePage settings={settings} />
                </div>
                {view === 'manager' && <ManagerPage serverUuid={uuid} directory={settings.directory} />}
            </div>
        </ServerContentBlock>
    );
}
