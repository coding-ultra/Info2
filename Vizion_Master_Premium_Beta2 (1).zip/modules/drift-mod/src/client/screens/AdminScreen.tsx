import { useQuery } from '@tanstack/react-query';
import { Alert, PageContentBlock, Spinner, httpErrorToHuman } from '@pterodactyl/sdk';
import { displayKey, getDisplaySettings } from '../api';
import { DRIFT_ICON } from '../brand';
import DisplayForm from '../components/DisplayForm';

/** Drift Mods settings page for root administrators, at /panel/drift-mods. */
export default function AdminScreen() {
    const query = useQuery({ queryKey: displayKey, queryFn: getDisplaySettings });

    return (
        <PageContentBlock title={'Drift Mods'}>
            <div className={'vz:grid vz:gap-4'}>
                <div className={'vz:flex vz:items-center vz:gap-3'}>
                    <img src={DRIFT_ICON} alt={''} width={40} height={40} className={'vz:rounded-md'} />
                    <div>
                        <h2 className={'vz:font-semibold vz:text-foreground'}>Drift Mods</h2>
                        <p className={'vz:text-xs vz:text-muted-foreground'}>Settings every server uses for the mod browser. Changes show up for users the next time they load the Panel.</p>
                    </div>
                </div>

                {query.isLoading && <Spinner centered />}
                {query.isError && <Alert type={'danger'}>{httpErrorToHuman(query.error)}</Alert>}
                {query.data && <DisplayForm key={JSON.stringify(query.data)} data={query.data} />}
            </div>
        </PageContentBlock>
    );
}
