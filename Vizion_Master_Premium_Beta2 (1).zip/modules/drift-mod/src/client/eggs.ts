import type { EggChoice, EggInfo } from './api';

/** True when any tag is (or contains) "minecraft". Mirrors EggVisibility::isMinecraft in the backend. */
export function isMinecraftTags(tags: readonly string[] | null | undefined): boolean {
    return (tags ?? []).some((tag) => tag.toLowerCase().includes('minecraft'));
}

/**
 * Whether Drift Mod is shown on an egg. Mirrors EggVisibility::decide in the backend:
 * an explicit choice wins, then the Minecraft-category rule, otherwise every egg is shown.
 */
export function eggEnabled(egg: Pick<EggInfo, 'id' | 'minecraft'>, requireMinecraft: boolean, overrides: Record<string, EggChoice>): boolean {
    const choice = overrides[String(egg.id)];
    if (choice === 'show') return true;
    if (choice === 'hide') return false;
    return requireMinecraft ? egg.minecraft : true;
}
