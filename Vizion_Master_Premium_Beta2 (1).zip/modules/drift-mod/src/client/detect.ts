/** neoforge must come before forge, because "neoforge" contains "forge". */
const LOADERS = ['neoforge', 'fabric', 'quilt', 'forge'];

/** Picks a Modrinth mod loader from the egg's tags, e.g. ["minecraft", "fabric"]. */
export function detectLoader(eggTags: readonly string[] | null | undefined): string {
    const tags = (eggTags ?? []).map((t) => t.toLowerCase());
    return LOADERS.find((loader) => tags.some((tag) => tag === loader || tag.includes(loader))) ?? '';
}

/** Falls back to startup variable names such as FABRIC_VERSION or NEOFORGE_VERSION. */
export function detectLoaderFromVariables(variables: readonly { env_variable: string }[] | undefined): string {
    const names = (variables ?? []).map((v) => v.env_variable.toUpperCase());
    return LOADERS.find((loader) => names.some((name) => name.includes(loader.toUpperCase()))) ?? '';
}

/** Reads a concrete Minecraft version (e.g. "1.21.4") from the startup variables, ignoring "latest". */
export function detectGameVersion(variables: readonly { env_variable: string; server_value: string | null; default_value: string }[] | undefined): string {
    const keys = ['MINECRAFT_VERSION', 'MC_VERSION', 'GAME_VERSION', 'SERVER_VERSION', 'VERSION'];
    for (const key of keys) {
        const variable = variables?.find((v) => v.env_variable === key);
        const value = (variable?.server_value || variable?.default_value || '').trim();
        if (/^\d+\.\d+(\.\d+)?$/.test(value)) return value;
    }
    return '';
}

export function formatCount(n: number): string {
    return new Intl.NumberFormat('en', { notation: 'compact', maximumFractionDigits: 1 }).format(n);
}

export function formatBytes(bytes: number): string {
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(0)} KB`;
    return `${(bytes / 1024 / 1024).toFixed(1)} MB`;
}
