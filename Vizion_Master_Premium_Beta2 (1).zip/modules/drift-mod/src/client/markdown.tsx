import type { ReactNode } from 'react';

/**
 * A small, safe Markdown renderer for Modrinth descriptions. It builds React elements (never HTML
 * strings), only links to https URLs, and only loads images that Modrinth itself hosts.
 */
const IMAGE_HOST = 'https://cdn.modrinth.com/';
const isLink = (url: string) => url.startsWith('https://');
const isImage = (url: string) => url.startsWith(IMAGE_HOST);

const INLINE =
    /(\[(?:!\[[^\]]*\]\([^)]*\)|[^\]])+\]\([^)\s]+(?:\s+"[^"]*")?\))|(!\[[^\]]*\]\([^)\s]+(?:\s+"[^"]*")?\))|(`[^`\n]+`)|(\*\*[^*\n]+\*\*|__[^_\n]+__)|(\*[^*\s][^*\n]*\*|(?<![A-Za-z0-9])_[^_\s][^_\n]*_(?![A-Za-z0-9]))|(https:\/\/[^\s<>)]+)/g;

function inline(text: string, keyPrefix: string): ReactNode[] {
    const out: ReactNode[] = [];
    let last = 0;
    let n = 0;
    for (const m of text.matchAll(INLINE)) {
        const index = m.index ?? 0;
        if (index > last) out.push(text.slice(last, index));
        const key = `${keyPrefix}-${n++}`;
        const [whole] = m;

        if (m[1]) {
            const parts = /^\[((?:.|\n)*)\]\(([^)\s]+)/.exec(whole);
            const label = parts?.[1] ?? '';
            const url = parts?.[2] ?? '';
            // Badge links ([![alt](img)](url)) keep their image only if it is hosted by Modrinth.
            out.push(
                isLink(url) ? (
                    <a key={key} href={url} target={'_blank'} rel={'noreferrer noopener nofollow'} style={{ textDecoration: 'underline', color: 'var(--foreground)' }}>
                        {inline(label, key)}
                    </a>
                ) : (
                    <span key={key}>{inline(label, key)}</span>
                )
            );
        } else if (m[2]) {
            const parts = /^!\[([^\]]*)\]\(([^)\s]+)/.exec(whole);
            const url = parts?.[2] ?? '';
            if (isImage(url)) {
                out.push(<img key={key} src={url} alt={parts?.[1] ?? ''} loading={'lazy'} style={{ maxWidth: '100%', height: 'auto', borderRadius: '0.375rem', verticalAlign: 'middle' }} />);
            }
        } else if (m[3]) {
            out.push(
                <code key={key} style={{ background: 'color-mix(in srgb, var(--foreground) 10%, transparent)', borderRadius: '0.25rem', padding: '0.05rem 0.3rem', fontSize: '0.85em' }}>
                    {whole.slice(1, -1)}
                </code>
            );
        } else if (m[4]) {
            out.push(<strong key={key}>{inline(whole.slice(2, -2), key)}</strong>);
        } else if (m[5]) {
            out.push(<em key={key}>{inline(whole.slice(1, -1), key)}</em>);
        } else if (m[6]) {
            out.push(
                <a key={key} href={whole} target={'_blank'} rel={'noreferrer noopener nofollow'} style={{ textDecoration: 'underline', color: 'var(--foreground)' }}>
                    {whole}
                </a>
            );
        }
        last = index + whole.length;
    }
    if (last < text.length) out.push(text.slice(last));
    return out;
}

/** Modrinth descriptions mix Markdown with HTML: turn the common tags into Markdown, drop the rest. */
function normalise(source: string): string {
    return source
        .replace(/\r\n?/g, '\n')
        .replace(/<img[^>]*?src=["']([^"']+)["'][^>]*?>/gi, '![]($1)')
        .replace(/<a[^>]*?href=["']([^"']+)["'][^>]*>([\s\S]*?)<\/a>/gi, '[$2]($1)')
        .replace(/<br\s*\/?>/gi, '\n')
        .replace(/<\/(p|div|h[1-6]|li|center)>/gi, '\n\n')
        .replace(/<h([1-6])[^>]*>/gi, (_, level: string) => `${'#'.repeat(Number(level))} `)
        .replace(/<(strong|b)>([\s\S]*?)<\/\1>/gi, '**$2**')
        .replace(/<(em|i)>([\s\S]*?)<\/\1>/gi, '*$2*')
        .replace(/<!--[\s\S]*?-->/g, '')
        .replace(/<\/?[a-zA-Z][^>]*>/g, '');
}

const cell = { border: '1px solid var(--border)', padding: '0.25rem 0.5rem', textAlign: 'left' } as const;

export default function Markdown({ source }: { source: string }) {
    const lines = normalise(source).split('\n');
    const blocks: ReactNode[] = [];
    let i = 0;
    let k = 0;

    while (i < lines.length) {
        const line = lines[i];
        const key = `b${k++}`;

        if (line.trim() === '') {
            i++;
        } else if (line.trim().startsWith('```')) {
            const code: string[] = [];
            i++;
            while (i < lines.length && !lines[i].trim().startsWith('```')) code.push(lines[i++]);
            i++;
            blocks.push(
                <pre key={key} style={{ overflowX: 'auto', background: 'color-mix(in srgb, var(--foreground) 8%, transparent)', borderRadius: '0.375rem', padding: '0.75rem', fontSize: '0.8rem' }}>
                    <code>{code.join('\n')}</code>
                </pre>
            );
        } else if (/^#{1,6}\s/.test(line)) {
            const level = line.match(/^#+/)![0].length;
            const sizes = ['1.25rem', '1.125rem', '1rem', '0.95rem', '0.9rem', '0.85rem'];
            blocks.push(
                <div key={key} role={'heading'} aria-level={level} style={{ fontWeight: 600, fontSize: sizes[level - 1], marginTop: '0.5rem', color: 'var(--foreground)' }}>
                    {inline(line.replace(/^#{1,6}\s+/, '').replace(/\s*#+\s*$/, ''), key)}
                </div>
            );
            i++;
        } else if (/^\s*([-*_])\s*(\1\s*){2,}$/.test(line)) {
            blocks.push(<hr key={key} style={{ border: 0, borderTop: '1px solid var(--border)' }} />);
            i++;
        } else if (/^>\s?/.test(line)) {
            const quote: string[] = [];
            while (i < lines.length && /^>\s?/.test(lines[i])) quote.push(lines[i++].replace(/^>\s?/, ''));
            blocks.push(
                <blockquote key={key} style={{ margin: 0, paddingLeft: '0.75rem', borderLeft: '3px solid var(--border)', color: 'var(--muted-foreground)' }}>
                    {inline(quote.join(' '), key)}
                </blockquote>
            );
        } else if (/^\s*([-*+]|\d+\.)\s+/.test(line)) {
            const ordered = /^\s*\d+\./.test(line);
            const items: string[] = [];
            while (i < lines.length && /^\s*([-*+]|\d+\.)\s+/.test(lines[i])) items.push(lines[i++].replace(/^\s*([-*+]|\d+\.)\s+/, ''));
            const List = ordered ? 'ol' : 'ul';
            blocks.push(
                <List key={key} style={{ margin: 0, paddingLeft: '1.25rem', listStyle: ordered ? 'decimal' : 'disc', display: 'grid', gap: '0.25rem' }}>
                    {items.map((item, n) => (
                        <li key={n}>{inline(item, `${key}-${n}`)}</li>
                    ))}
                </List>
            );
        } else if (line.trim().startsWith('|') && /^\s*\|?[\s:|-]+\|[\s:|-]*$/.test(lines[i + 1] ?? '')) {
            const split = (row: string) => row.trim().replace(/^\||\|$/g, '').split('|').map((c) => c.trim());
            const head = split(line);
            i += 2;
            const rows: string[][] = [];
            while (i < lines.length && lines[i].trim().startsWith('|')) rows.push(split(lines[i++]));
            blocks.push(
                <div key={key} style={{ overflowX: 'auto' }}>
                    <table style={{ borderCollapse: 'collapse', fontSize: '0.85rem' }}>
                        <thead>
                            <tr>
                                {head.map((h, n) => (
                                    <th key={n} style={cell}>
                                        {inline(h, `${key}h${n}`)}
                                    </th>
                                ))}
                            </tr>
                        </thead>
                        <tbody>
                            {rows.map((r, n) => (
                                <tr key={n}>
                                    {r.map((c, m) => (
                                        <td key={m} style={cell}>
                                            {inline(c, `${key}r${n}c${m}`)}
                                        </td>
                                    ))}
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            );
        } else {
            const paragraph: string[] = [];
            while (
                i < lines.length &&
                lines[i].trim() !== '' &&
                !/^(#{1,6}\s|>\s?|\s*([-*+]|\d+\.)\s+|```)/.test(lines[i]) &&
                !lines[i].trim().startsWith('|')
            ) {
                paragraph.push(lines[i++]);
            }
            if (paragraph.length === 0) {
                paragraph.push(lines[i++]);
            }
            blocks.push(<p key={key}>{inline(paragraph.join('\n'), key)}</p>);
        }
    }

    return <div style={{ display: 'grid', gap: '0.75rem', fontSize: '0.875rem', lineHeight: 1.6, color: 'var(--foreground)', overflowWrap: 'anywhere' }}>{blocks}</div>;
}
