import { definePterodactylExtension } from '@pterodactyl/sdk';
import { setConfig } from './config';

export default definePterodactylExtension({
    setup({ config, screens }) {
        setConfig(config);

        // Both ids are declared in extension.json under ui.screens.
        // "main" is the server page (Browse mods and Mod manager); "admin" is /panel/drift-mods.
        screens.register('main', () => import('./screens/ServerScreen'));
        screens.register('admin', () => import('./screens/AdminScreen'));
    },
});
