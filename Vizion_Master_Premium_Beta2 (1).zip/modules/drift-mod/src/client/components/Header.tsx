import { Button } from '@pterodactyl/sdk';
import { DRIFT_ICON } from '../brand';
import DiscordButton from './DiscordButton';

export type View = 'browse' | 'manager';

const VIEWS: { id: View; label: string }[] = [
    { id: 'browse', label: 'Browse mods' },
    { id: 'manager', label: 'Mod manager' },
];

interface Props {
    subtitle: string;
    view: View;
    /**
     * Switches the page shown inside this screen. This is plain React state, so it never depends on
     * the Panel's router: the buttons work the same wherever the screen is opened from.
     */
    onNavigate: (view: View) => void;
}

export default function Header({ subtitle, view, onNavigate }: Props) {
    return (
        <div className={'vz:flex vz:flex-wrap vz:items-center vz:justify-between vz:gap-3'}>
            <div className={'vz:flex vz:items-center vz:gap-3'}>
                <img src={DRIFT_ICON} alt={''} width={40} height={40} className={'vz:rounded-md'} />
                <div>
                    <h2 className={'vz:font-semibold vz:text-foreground'}>Drift Mod</h2>
                    <p className={'vz:text-xs vz:text-muted-foreground'}>{subtitle}</p>
                </div>
            </div>
            <div className={'vz:flex vz:flex-wrap vz:items-center vz:gap-2'}>
                {VIEWS.map((item) => (
                    <Button key={item.id} isSecondary={item.id !== view} onClick={() => onNavigate(item.id)}>
                        {item.label}
                    </Button>
                ))}
                <DiscordButton />
            </div>
        </div>
    );
}
