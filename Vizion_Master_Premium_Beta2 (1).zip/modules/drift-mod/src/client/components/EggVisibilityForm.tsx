import { useQuery } from '@tanstack/react-query';
import { Alert, Label, Select, Spinner, Switch, TitledGreyBox, httpErrorToHuman } from '@pterodactyl/sdk';
import { eggsKey, getEggs, type EggChoice } from '../api';
import { eggEnabled } from '../eggs';

type Choice = EggChoice | 'auto';

interface Props {
    requireMinecraft: boolean;
    overrides: Record<string, EggChoice>;
    onRequireMinecraft: (value: boolean) => void;
    onOverrides: (value: Record<string, EggChoice>) => void;
}

/** Admin box: which eggs get Drift Mod. The Minecraft-category rule, plus a show / hide choice per egg. */
export default function EggVisibilityForm({ requireMinecraft, overrides, onRequireMinecraft, onOverrides }: Props) {
    const eggs = useQuery({ queryKey: eggsKey, queryFn: getEggs, staleTime: 60 * 1000 });

    const choose = (id: number, choice: Choice) => {
        const next = { ...overrides };
        if (choice === 'auto') delete next[String(id)];
        else next[String(id)] = choice;
        onOverrides(next);
    };

    return (
        <TitledGreyBox title={'Egg availability'}>
            <div className={'vz:grid vz:gap-3'}>
                <Switch
                    label={'Only Minecraft eggs'}
                    description={'Drift Mod is hidden on servers whose egg is not in the Minecraft category (tagged \"minecraft\" or named Paper, Purpur, Forge, Fabric and so on). Turn this off to show it on every egg.'}
                    checked={requireMinecraft}
                    onChange={(value: boolean) => onRequireMinecraft(value)}
                />

                <div>
                    <Label>Per-egg choice</Label>
                    <p className={'vz:text-xs vz:text-muted-foreground'}>Automatic follows the switch above. Always show or Always hide overrides it for that egg.</p>
                </div>

                {eggs.isLoading && <Spinner centered />}
                {eggs.isError && <Alert type={'danger'}>{httpErrorToHuman(eggs.error)}</Alert>}
                {eggs.data && eggs.data.length === 0 && <p className={'vz:text-xs vz:text-muted-foreground'}>No eggs found.</p>}

                {eggs.data && eggs.data.length > 0 && (
                    <ul className={'vz:grid vz:gap-2'}>
                        {eggs.data.map((egg) => {
                            const choice: Choice = overrides[String(egg.id)] ?? 'auto';
                            const shown = eggEnabled(egg, requireMinecraft, overrides);
                            return (
                                <li key={egg.id} className={'vz:flex vz:flex-wrap vz:items-center vz:justify-between vz:gap-3'}>
                                    <div>
                                        <div className={'vz:text-sm vz:font-medium vz:text-foreground'}>{egg.name}</div>
                                        <div className={'vz:text-xs vz:text-muted-foreground'}>
                                            {shown ? 'Shown' : 'Hidden'}
                                            {' \u00b7 '}
                                            {egg.minecraft ? (egg.group ?? 'Minecraft category') : 'Not in the Minecraft category'}
                                        </div>
                                    </div>
                                    <div style={{ minWidth: '11rem' }}>
                                        <Select
                                            value={choice}
                                            onChange={(v) => choose(egg.id, v === 'show' || v === 'hide' ? v : 'auto')}
                                            options={[
                                                { value: 'auto', label: 'Automatic' },
                                                { value: 'show', label: 'Always show' },
                                                { value: 'hide', label: 'Always hide' },
                                            ]}
                                        />
                                    </div>
                                </li>
                            );
                        })}
                    </ul>
                )}
            </div>
        </TitledGreyBox>
    );
}
