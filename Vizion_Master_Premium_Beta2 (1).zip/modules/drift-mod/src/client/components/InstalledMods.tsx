import { useState } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import {
    Alert,
    Button,
    Dialog,
    Table,
    TitledGreyBox,
    httpErrorToHuman,
    invalidateServerData,
    toast,
    useDeleteServerFiles,
    useServerFiles,
    useServerPermission,
    type SdkFile,
} from '@pterodactyl/sdk';
import { forgetInstalled, getInstalled, installFile } from '../api';
import { formatBytes } from '../detect';

type Action = 'delete' | 'reinstall' | null;

export default function InstalledMods({ serverUuid, directory }: { serverUuid: string; directory: string }) {
    const queryClient = useQueryClient();
    const files = useServerFiles(serverUuid, directory, (data) => data.data.filter((f) => f.attributes.is_file && f.attributes.name.toLowerCase().endsWith('.jar')));
    const deleteFiles = useDeleteServerFiles(serverUuid);
    const canDelete = useServerPermission(['file.delete'], false);
    const canInstall = useServerPermission(['file.create', 'file.update'], false);

    const installed = useQuery({ queryKey: ['drift-mod', 'installed', serverUuid], queryFn: () => getInstalled(serverUuid) });
    const registry = installed.data ?? {};

    const [selected, setSelected] = useState<string[]>([]);
    const [action, setAction] = useState<Action>(null);

    const rows = files.data ?? [];
    const names = rows.map((f) => f.attributes.name);
    const chosen = selected.filter((n) => names.includes(n));
    const reinstallable = chosen.filter((n) => registry[n]);
    const skipped = chosen.length - reinstallable.length;

    const toggle = (name: string) => setSelected((cur) => (cur.includes(name) ? cur.filter((n) => n !== name) : [...cur, name]));
    const allChecked = names.length > 0 && chosen.length === names.length;

    const run = useMutation({
        mutationFn: async (kind: 'delete' | 'reinstall') => {
            if (kind === 'delete') {
                await deleteFiles.mutateAsync({ directory, files: chosen });
                // Deleting is done; failing to tidy the record must not report the delete as failed.
                await forgetInstalled(serverUuid, chosen).catch(() => undefined);
            } else {
                // Remove the old jar first so the fresh download never collides with it.
                await deleteFiles.mutateAsync({ directory, files: reinstallable });
                for (const name of reinstallable) {
                    await installFile(serverUuid, registry[name].url, directory, name);
                }
            }
            await invalidateServerData(serverUuid, ['files']);
            await queryClient.invalidateQueries({ queryKey: ['drift-mod', 'installed', serverUuid] });
            return kind;
        },
        onSuccess: (kind) => {
            toast.success(kind === 'delete' ? 'Mods deleted. Restart the server to unload them.' : 'Mods reinstalled. Restart the server to load them.');
            setSelected([]);
            setAction(null);
        },
        onError: (error) => {
            toast.error(httpErrorToHuman(error));
            void invalidateServerData(serverUuid, ['files']);
            setAction(null);
        },
    });

    return (
        <TitledGreyBox title={`Mod manager · ${directory}`}>
            <div className={'vz:mb-3 vz:flex vz:flex-wrap vz:items-center vz:gap-2'}>
                <Button size={'small'} disabled={!canInstall || reinstallable.length === 0} onClick={() => setAction('reinstall')}>
                    Reinstall selected
                </Button>
                <Button size={'small'} disabled={!canDelete || chosen.length === 0} onClick={() => setAction('delete')}>
                    Delete selected
                </Button>
                <span className={'vz:text-xs vz:text-muted-foreground'}>{chosen.length > 0 ? `${chosen.length} selected` : 'Tick mods below to manage them'}</span>
            </div>

            <Table<SdkFile>
                rows={rows}
                keyOf={(file) => file.attributes.name}
                isFetching={files.isFetching}
                emptyState={files.isError ? `Nothing found in ${directory} yet.` : 'No mod jars installed yet.'}
                columns={[
                    {
                        id: 'select',
                        label: <input type={'checkbox'} aria-label={'Select all'} checked={allChecked} onChange={() => setSelected(allChecked ? [] : names)} />,
                        cell: (file) => (
                            <input
                                type={'checkbox'}
                                aria-label={`Select ${file.attributes.name}`}
                                checked={chosen.includes(file.attributes.name)}
                                onChange={() => toggle(file.attributes.name)}
                            />
                        ),
                    },
                    { id: 'name', label: 'File', cell: (file) => file.attributes.name },
                    {
                        id: 'mod',
                        label: 'Mod',
                        cell: (file) => {
                            const record = registry[file.attributes.name];
                            return record ? `${record.title}${record.version_number ? ` ${record.version_number}` : ''}` : '—';
                        },
                    },
                    { id: 'size', label: 'Size', cell: (file) => formatBytes(file.attributes.size ?? 0) },
                    { id: 'modified', label: 'Modified', cell: (file) => new Date(file.attributes.modified_at).toLocaleString() },
                ]}
            />

            <Dialog open={action !== null} onClose={() => !run.isPending && setAction(null)} title={action === 'delete' ? 'Delete mods' : 'Reinstall mods'}>
                <div className={'vz:grid vz:gap-3'}>
                    {action === 'delete' ? (
                        <p className={'vz:text-sm'}>
                            Permanently delete {chosen.length} mod file{chosen.length === 1 ? '' : 's'} from {directory}? This cannot be undone. Other mods may need the ones you delete.
                        </p>
                    ) : (
                        <>
                            <p className={'vz:text-sm'}>
                                Re-download {reinstallable.length} mod{reinstallable.length === 1 ? '' : 's'} from Modrinth, replacing the current file.
                            </p>
                            {skipped > 0 && (
                                <Alert type={'warning'}>
                                    {skipped} selected jar{skipped === 1 ? ' was' : 's were'} not installed through Drift Mod and will be left untouched.
                                </Alert>
                            )}
                        </>
                    )}
                    <ul className={'vz:max-h-40 vz:overflow-auto vz:text-xs vz:text-muted-foreground'}>
                        {(action === 'delete' ? chosen : reinstallable).map((n) => (
                            <li key={n}>{n}</li>
                        ))}
                    </ul>
                    <div className={'vz:flex vz:justify-end vz:gap-2'}>
                        <Button.Text onClick={() => setAction(null)} disabled={run.isPending}>
                            Cancel
                        </Button.Text>
                        <Button isLoading={run.isPending} onClick={() => action && run.mutate(action)}>
                            {action === 'delete' ? 'Delete' : 'Reinstall'}
                        </Button>
                    </div>
                </div>
            </Dialog>
        </TitledGreyBox>
    );
}
