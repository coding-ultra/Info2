import { useEffect, useState } from 'react';
import { useMutation, useQuery } from '@tanstack/react-query';
import { Alert, Button, Dialog, Label, Select, Spinner, Switch, httpErrorToHuman, invalidateServerData, toast, useServerFiles } from '@pterodactyl/sdk';
import { getVersions, installFile, recordInstalled, resolveDependencies, type Mod, type ModVersion } from '../api';
import { formatBytes } from '../detect';

interface Props {
    mod: Mod | null;
    serverUuid: string;
    loader: string;
    gameVersion: string;
    /** Folder the jars are downloaded into (the server's effective setting). */
    directory: string;
    onClose: () => void;
}

export default function InstallDialog({ mod, serverUuid, loader, gameVersion, directory, onClose }: Props) {
    return (
        <Dialog open={mod !== null} onClose={onClose} title={mod ? `Install ${mod.title}` : ''}>
            {/* Mounted only while a mod is chosen, so nothing is fetched for a closed dialog. */}
            {mod && <InstallBody mod={mod} serverUuid={serverUuid} loader={loader} gameVersion={gameVersion} directory={directory} onClose={onClose} />}
        </Dialog>
    );
}

function InstallBody({ mod, serverUuid, loader, gameVersion, directory, onClose }: Props & { mod: Mod }) {
    const [versionId, setVersionId] = useState<string>('');
    const [withDependencies, setWithDependencies] = useState(true);

    const versions = useQuery({
        queryKey: ['drift-mod', 'versions', serverUuid, mod.project_id, loader, gameVersion],
        queryFn: () => getVersions(serverUuid, mod.project_id, loader, gameVersion),
    });

    // Newest compatible version is preselected whenever the list changes.
    useEffect(() => {
        setVersionId(versions.data?.[0]?.id ?? '');
    }, [versions.data]);

    const selected: ModVersion | undefined = versions.data?.find((v) => v.id === versionId);

    // Dependencies are resolved for the loader and game version of the file that is about to be installed.
    const depLoader = loader || (selected?.loaders.length === 1 ? selected.loaders[0] : '');
    const depGameVersion = gameVersion || selected?.game_versions.at(-1) || '';
    const requirements = selected?.dependencies ?? [];

    const dependencies = useQuery({
        queryKey: ['drift-mod', 'dependencies', serverUuid, selected?.id, depLoader, depGameVersion],
        queryFn: () => resolveDependencies(serverUuid, requirements, depLoader, depGameVersion),
        enabled: selected !== undefined && requirements.length > 0,
        staleTime: 10 * 60 * 1000,
    });

    // Files already in the install directory are never downloaded again as dependencies.
    const existing = useServerFiles(serverUuid, directory, (data) => data.data.map((f) => f.attributes.name));
    const existingNames = new Set(existing.data ?? []);

    const toInstall = (withDependencies ? (dependencies.data ?? []) : []).filter((d) => d.version !== null && !existingNames.has(d.version.file.filename));
    const unresolved = (dependencies.data ?? []).filter((d) => d.version === null);

    const install = useMutation({
        mutationFn: async () => {
            if (!selected) throw new Error('Pick a version first.');

            const queue = [
                ...toInstall.map((d) => ({ title: d.title, project_id: d.project_id, version: d.version as ModVersion })),
                { title: mod.title, project_id: mod.project_id, version: selected },
            ];

            // Dependencies first, so the server never has a mod on disk without what it needs.
            for (const item of queue) {
                await installFile(serverUuid, item.version.file.url, directory, item.version.file.filename);
                try {
                    await recordInstalled(serverUuid, item.version.file.filename, {
                        url: item.version.file.url,
                        title: item.title,
                        project_id: item.project_id,
                        version_id: item.version.id,
                        version_number: item.version.version_number,
                    });
                } catch {
                    /* The jar is installed; only the "reinstall later" record is missing. */
                }
            }

            await invalidateServerData(serverUuid, ['files']);
            return queue.length;
        },
        onSuccess: (count) => {
            toast.success(`${mod.title}${count > 1 ? ` and ${count - 1} dependenc${count === 2 ? 'y' : 'ies'}` : ''} installed to ${directory}. Restart the server to load ${count > 1 ? 'them' : 'it'}.`);
            onClose();
        },
        onError: (error) => {
            toast.error(httpErrorToHuman(error));
            void invalidateServerData(serverUuid, ['files']);
        },
    });

    return (
        <>
            {versions.isLoading && <Spinner centered />}

            {versions.isError && <Alert type={'danger'}>{httpErrorToHuman(versions.error)}</Alert>}

            {versions.data && versions.data.length === 0 && (
                <Alert type={'warning'}>
                    No version of this mod matches the selected loader{loader ? ` (${loader})` : ''}
                    {gameVersion ? ` and Minecraft ${gameVersion}` : ''}. Change the filters and try again.
                </Alert>
            )}

            {versions.data && versions.data.length > 0 && (
                <div className={'vz:grid vz:gap-3'}>
                    {!loader && (
                        <Alert type={'info'}>No mod loader is selected, so files for every loader are listed. Pick your server&apos;s loader in the filters to avoid installing the wrong one.</Alert>
                    )}

                    <div>
                        <Label>Version</Label>
                        <Select
                            value={versionId}
                            onChange={(value) => setVersionId(String(value))}
                            options={versions.data.map((v) => ({
                                value: v.id,
                                label: `${v.version_number} (${v.version_type}) · ${v.loaders.join('/')} · ${v.game_versions.slice(-3).join(', ')}`,
                                textLabel: `${v.version_number} ${v.loaders.join(' ')} ${v.game_versions.join(' ')}`,
                            }))}
                            searchPlaceholder={'Search versions…'}
                        />
                    </div>

                    {selected && (
                        <p className={'vz:text-sm vz:text-muted-foreground'}>
                            {selected.file.filename} · {formatBytes(selected.file.size)} → {directory}/
                        </p>
                    )}

                    {requirements.length > 0 && (
                        <div className={'vz:grid vz:gap-2 vz:rounded-md vz:border vz:border-border vz:p-3'}>
                            <Switch
                                label={'Install required dependencies'}
                                description={'This mod needs other mods to run. They are downloaded first.'}
                                checked={withDependencies}
                                onChange={setWithDependencies}
                            />
                            {dependencies.isLoading && <Spinner centered />}
                            {dependencies.isError && <Alert type={'warning'}>Could not look up the dependencies ({httpErrorToHuman(dependencies.error)}).</Alert>}
                            {dependencies.data && (
                                <ul className={'vz:text-xs vz:text-muted-foreground'}>
                                    {dependencies.data.map((d) => (
                                        <li key={d.project_id}>
                                            {d.title}
                                            {d.version === null
                                                ? ' — no compatible version found, install it manually'
                                                : existingNames.has(d.version.file.filename)
                                                  ? ' — already installed'
                                                  : ` — ${d.version.file.filename}`}
                                        </li>
                                    ))}
                                </ul>
                            )}
                            {withDependencies && unresolved.length > 0 && <Alert type={'warning'}>{unresolved.length} required mod{unresolved.length === 1 ? '' : 's'} could not be resolved; {mod.title} may not start without {unresolved.length === 1 ? 'it' : 'them'}.</Alert>}
                        </div>
                    )}

                    <div className={'vz:flex vz:justify-end vz:gap-2'}>
                        <Button.Text onClick={onClose}>Cancel</Button.Text>
                        <Button isLoading={install.isPending} disabled={!selected || (requirements.length > 0 && dependencies.isLoading)} onClick={() => install.mutate()}>
                            Install{toInstall.length > 0 ? ` (+${toInstall.length})` : ''}
                        </Button>
                    </div>
                </div>
            )}
        </>
    );
}
