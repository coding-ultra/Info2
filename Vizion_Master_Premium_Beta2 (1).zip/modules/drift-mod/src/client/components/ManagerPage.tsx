import { Alert, useServerPermission } from '@pterodactyl/sdk';
import InstalledMods from './InstalledMods';

export default function ManagerPage({ serverUuid, directory }: { serverUuid: string; directory: string }) {
    const canRead = useServerPermission(['file.read'], false);

    return (
        <div className={'vz:grid vz:gap-4'}>
            {!canRead && <Alert type={'warning'}>You need the file read permission to manage mods on this server.</Alert>}
            {canRead && <InstalledMods serverUuid={serverUuid} directory={directory} />}
        </div>
    );
}
