import type { ExtensionConfig } from '@pterodactyl/sdk';
import { DEFAULT_LAYOUT, type LayoutSettings } from './layout';

export const DEFAULT_DIRECTORY = '/mods';

/** Everything the screens read from settings: where mods go, and how the list looks. */
export interface ModSettings {
    directory: string;
    layout: LayoutSettings;
}

const int = (value: unknown, min: number, max: number, fallback: number): number => {
    const n = typeof value === 'number' ? value : typeof value === 'string' ? Number(value) : Number.NaN;
    return Number.isFinite(n) ? Math.min(max, Math.max(min, Math.round(n))) : fallback;
};

/** Turns raw settings (administrator config or a server's effective settings) into safe, clamped values. */
export function parseSettings(raw: object): ModSettings {
    const config = raw as Record<string, unknown>;
    const dir = config.install_directory;
    const directory = typeof dir === 'string' && /^\/[A-Za-z0-9._/-]*$/.test(dir) && !/(^|\/)\.\.(\/|$)/.test(dir) ? dir.replace(/\/+$/, '') || '/' : DEFAULT_DIRECTORY;

    const overlay = int(config.overlay_opacity, 0, 100, DEFAULT_LAYOUT.overlay_opacity);
    const blur = int(config.blur_amount, 0, 40, DEFAULT_LAYOUT.blur_amount);

    return {
        directory,
        layout: {
            layout: config.layout === 'row' ? 'row' : 'card',
            columns: int(config.columns, 2, 4, DEFAULT_LAYOUT.columns),
            show_background: typeof config.show_background === 'boolean' ? config.show_background : DEFAULT_LAYOUT.show_background,
            show_overlay: overlay > 0,
            overlay_opacity: overlay,
            blur_enabled: blur > 0,
            blur_amount: blur,
        },
    };
}

let current: ModSettings = parseSettings({});

/**
 * Screens never receive `config`, so setup() stores the administrator settings here. They are the
 * starting point until a server's own settings load. `config` is empty on pages shown before
 * sign-in, so every value falls back to a default.
 */
export function setConfig(config: ExtensionConfig): void {
    current = parseSettings(config);
}

export function getInstallDirectory(): string {
    return current.directory;
}

export function getLayout(): LayoutSettings {
    return current.layout;
}
