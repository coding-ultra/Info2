<?php

namespace DriftPlugins;

use DriftPlugins\Settings\PluginSettings;
use Vizion\Support\ModuleProvider;
use Pterodactyl\Services\Extensions\ExtensionSettingDefinition;
use Pterodactyl\Services\Extensions\ExtensionSettingsDefinition;

class DriftPluginsProvider extends ModuleProvider
{
    public function register(): void
    {
        // No container bindings needed.
    }

    public function boot(): void
    {
        // Controllers read and write the same store through this wrapper, so the
        // /panel/drift-plugins page and Admin -> Extensions always agree.
        $this->app->instance(PluginSettings::class, new PluginSettings($this->settings()));

        // routes/server.php -> /api/client/servers/{server}/extensions/vizion/drift-plugins
        // routes/admin.php  -> /api/admin/extensions/vizion/drift-plugins
        $this->registerApiRoutes();

        $this->registerSettings(new ExtensionSettingsDefinition($this->settings(), [
            \Vizion\Support\ScopedDefinition::make('drift-plugins', 'contact', 'contact', '', ['nullable', 'string', 'max:120'])
                ->label('Modrinth contact')
                ->help('Sent in the User-Agent of every Modrinth request (a URL or email), as Modrinth asks API consumers to identify themselves.')
                ->field('text'),

            \Vizion\Support\ScopedDefinition::make('drift-plugins', 'cache_minutes', 'cache_minutes', 10, ['required', 'integer', 'min:1', 'max:1440'])
                ->label('Search cache (minutes)')
                ->help('How long Modrinth search and version responses are cached on the Panel.')
                ->field('number'),

            \Vizion\Support\ScopedDefinition::make('drift-plugins', 'install_directory', 'install_directory', '/plugins', ['required', 'string', 'max:255', 'regex:#^/[A-Za-z0-9._/-]*$#'])
                ->label('Install directory')
                ->help('Folder, relative to the server root, that plugins are downloaded into.')
                ->field('text')
                ->frontend()
                ->frontendType('string'),

            \Vizion\Support\ScopedDefinition::make('drift-plugins', 'layout', 'layout', 'card', ['required', 'in:card,row'])
                ->label('Plugin list layout')
                ->help('Show search results as cards or as compact rows.')
                ->field('select', [['value' => 'card', 'label' => 'Cards'], ['value' => 'row', 'label' => 'Rows']]),

            \Vizion\Support\ScopedDefinition::make('drift-plugins', 'columns', 'columns', 2, ['required', 'integer', 'in:2,3,4'])
                ->label('Cards per row')
                ->help('Card layout only: 2, 3 or 4. Small screens show fewer.')
                ->field('select', [['value' => 2, 'label' => '2 cards per row'], ['value' => 3, 'label' => '3 cards per row'], ['value' => 4, 'label' => '4 cards per row']]),

            \Vizion\Support\ScopedDefinition::make('drift-plugins', 'show_background', 'show_background', true, ['boolean'])
                ->label('Background image')
                ->help("Use the plugin's gallery image (or its icon) behind each card or row.")
                ->field('toggle'),

            \Vizion\Support\ScopedDefinition::make('drift-plugins', 'show_overlay', 'show_overlay', true, ['boolean'])
                ->label('Dark overlay')
                ->help('Darkens the background image so the text stays readable.')
                ->field('toggle'),

            \Vizion\Support\ScopedDefinition::make('drift-plugins', 'overlay_opacity', 'overlay_opacity', 75, ['required', 'integer', 'min:0', 'max:100'])
                ->label('Overlay strength (%)')
                ->field('number'),

            \Vizion\Support\ScopedDefinition::make('drift-plugins', 'blur_enabled', 'blur_enabled', false, ['boolean'])
                ->label('Blur the background')
                ->field('toggle'),

            \Vizion\Support\ScopedDefinition::make('drift-plugins', 'blur_amount', 'blur_amount', 8, ['required', 'integer', 'min:0', 'max:40'])
                ->label('Blur amount (px)')
                ->field('number'),

            \Vizion\Support\ScopedDefinition::make('drift-plugins', 'require_plugin_egg', 'require_plugin_egg', true, ['boolean'])
                ->label('Only plugin-capable eggs')
                ->help('Show Drift Plugins only on servers whose egg name is a plugin server (Paper, Purpur, Spigot, Folia, Velocity...) or a mod+plugin hybrid (Mohist, Arclight...). Per-egg overrides win over this.')
                ->field('toggle'),

            \Vizion\Support\ScopedDefinition::make('drift-plugins', 'egg_overrides', 'egg_overrides', '{}', ['nullable', 'string', 'max:20000'])
                ->label('Egg overrides (JSON)')
                ->help('Per-egg choice as {"EGG_ID": "show" | "hide"}. Easier to edit on the Drift Plugins page.')
                ->field('text'),
        ]));
    }
}
