<?php

namespace DriftPlugins\Http\Controllers;

use DriftPlugins\Settings\PluginSettings;
use Illuminate\Http\JsonResponse;
use Illuminate\Routing\Controller;
use Knuckles\Scribe\Attributes\Endpoint;

/** Display settings for the plugin list (server routes). */
class LayoutController extends Controller
{
    #[Endpoint('Get plugin list layout', 'Layout, background, overlay and blur settings chosen by the administrator.')]
    public function show(PluginSettings $settings): JsonResponse
    {
        return new JsonResponse($settings->layout());
    }
}
