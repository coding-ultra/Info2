<?php

namespace DriftPlugins\Http\Controllers;

use DriftPlugins\Services\EggVisibility;
use DriftPlugins\Settings\PluginSettings;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Knuckles\Scribe\Attributes\Endpoint;
use Pterodactyl\Models\Egg;

/** Root administrators only (routes/admin.php). */
class ConfigController extends Controller
{
    #[Endpoint('Get Drift Plugins settings', 'All settings shown on the admin page.')]
    public function show(PluginSettings $settings): JsonResponse
    {
        return new JsonResponse($settings->all());
    }

    #[Endpoint('Update Drift Plugins settings', 'Saves the admin page.')]
    public function update(Request $request, PluginSettings $settings): JsonResponse
    {
        $data = $request->validate([
            'contact' => ['nullable', 'string', 'max:120'],
            'cache_minutes' => ['required', 'integer', 'min:1', 'max:1440'],
            'install_directory' => ['required', 'string', 'max:255', 'regex:#^/[A-Za-z0-9._/-]*$#'],
            'layout' => ['required', 'in:card,row'],
            'columns' => ['required', 'integer', 'in:2,3,4'],
            'show_background' => ['required', 'boolean'],
            'show_overlay' => ['required', 'boolean'],
            'overlay_opacity' => ['required', 'integer', 'min:0', 'max:100'],
            'blur_enabled' => ['required', 'boolean'],
            'blur_amount' => ['required', 'integer', 'min:0', 'max:40'],
            'require_plugin_egg' => ['required', 'boolean'],
            'egg_overrides' => ['nullable', 'array', 'max:2000'],
            'egg_overrides.*' => ['in:show,hide'],
        ]);

        $data['contact'] = trim((string) ($data['contact'] ?? ''));
        $data['egg_overrides'] = $data['egg_overrides'] ?? [];
        $settings->update($data);

        return new JsonResponse($settings->all());
    }

    #[Endpoint('List eggs', 'Every egg with the family it belongs to and whether Drift Plugins is shown on it by default.')]
    public function eggs(): JsonResponse
    {
        $eggs = Egg::query()->orderBy('name')->get()->map(function (Egg $egg) {
            $group = EggVisibility::groupOfName((string) $egg->name);

            return [
                'id' => (int) $egg->id,
                'name' => (string) $egg->name,
                'tags' => EggVisibility::tagsOf($egg),
                'plugins' => $group !== null,
                'group' => $group,
            ];
        });

        return new JsonResponse(['data' => $eggs->values()]);
    }
}
