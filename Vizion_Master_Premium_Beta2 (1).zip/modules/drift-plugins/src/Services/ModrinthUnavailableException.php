<?php

namespace DriftPlugins\Services;

use RuntimeException;

class ModrinthUnavailableException extends RuntimeException {}
