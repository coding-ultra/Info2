<?php

namespace DriftPlugins\Services;

use Illuminate\Http\Client\ConnectionException;
use Illuminate\Http\Client\RequestException;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Http;

/**
 * Thin, cached wrapper around the public Modrinth v2 API.
 */
class ModrinthClient
{
    public const BASE_URL = 'https://api.modrinth.com/v2';

    public const DOWNLOAD_HOST = 'cdn.modrinth.com';

    /** Loaders that run server plugins; used both as a default filter and to trim the loader list. */
    public const PLUGIN_LOADERS = ['paper', 'spigot', 'bukkit', 'purpur', 'folia', 'velocity', 'bungeecord', 'waterfall', 'sponge'];

    public const PER_PAGE = 12;

    public function __construct(private readonly string $contact, private readonly int $cacheMinutes) {}

    /**
     * @return array{hits: list<array<string, mixed>>, total: int, page: int, per_page: int, total_pages: int}
     */
    public function search(?string $query, ?string $loader, ?string $gameVersion, ?string $category, string $sort, int $page): array
    {
        $loaders = $loader ? [$loader] : self::PLUGIN_LOADERS;

        $facets = [array_map(fn (string $l) => "categories:$l", $loaders)];
        if ($gameVersion) {
            $facets[] = ["versions:$gameVersion"];
        }
        if ($category) {
            $facets[] = ["categories:$category"];
        }

        $params = [
            'query' => $query ?? '',
            'facets' => json_encode($facets),
            'index' => $sort,
            'limit' => self::PER_PAGE,
            'offset' => ($page - 1) * self::PER_PAGE,
        ];

        $body = $this->get('/search', $params);

        $total = (int) ($body['total_hits'] ?? 0);

        return [
            'hits' => array_values(array_map(fn (array $hit) => [
                'project_id' => (string) ($hit['project_id'] ?? ''),
                'slug' => (string) ($hit['slug'] ?? $hit['project_id'] ?? ''),
                'title' => (string) ($hit['title'] ?? ''),
                'description' => (string) ($hit['description'] ?? ''),
                'icon_url' => is_string($hit['icon_url'] ?? null) ? $hit['icon_url'] : null,
                'banner_url' => $this->bannerUrl($hit),
                'author' => (string) ($hit['author'] ?? ''),
                'downloads' => (int) ($hit['downloads'] ?? 0),
                'follows' => (int) ($hit['follows'] ?? 0),
                'categories' => array_values(array_filter((array) ($hit['display_categories'] ?? $hit['categories'] ?? []), 'is_string')),
                'date_modified' => is_string($hit['date_modified'] ?? null) ? $hit['date_modified'] : null,
            ], array_filter((array) ($body['hits'] ?? []), 'is_array'))),
            'total' => $total,
            'page' => $page,
            'per_page' => self::PER_PAGE,
            'total_pages' => max(1, (int) ceil($total / self::PER_PAGE)),
        ];
    }

    /**
     * Everything the "Read more" popup shows about one project.
     *
     * @return array<string, mixed>
     */
    public function project(string $project): array
    {
        $p = $this->get('/project/'.rawurlencode($project), []);

        $https = fn ($url) => is_string($url) && str_starts_with($url, 'https://') ? $url : null;
        $strings = fn ($list) => array_values(array_filter((array) $list, 'is_string'));

        $gallery = [];
        foreach ((array) ($p['gallery'] ?? []) as $image) {
            $url = is_array($image) ? ($image['url'] ?? null) : null;
            if (is_string($url) && str_starts_with($url, 'https://'.self::DOWNLOAD_HOST.'/')) {
                $gallery[] = ['url' => $url, 'title' => (string) ($image['title'] ?? ''), 'description' => (string) ($image['description'] ?? '')];
            }
            if (count($gallery) >= 12) {
                break;
            }
        }

        return [
            'project_id' => (string) ($p['id'] ?? $project),
            'slug' => (string) ($p['slug'] ?? $project),
            'title' => (string) ($p['title'] ?? ''),
            'description' => (string) ($p['description'] ?? ''),
            'body' => mb_substr((string) ($p['body'] ?? ''), 0, 20000),
            'icon_url' => $https($p['icon_url'] ?? null),
            'gallery' => $gallery,
            'categories' => $strings($p['categories'] ?? []),
            'loaders' => $strings($p['loaders'] ?? []),
            'game_versions' => array_slice($strings($p['game_versions'] ?? []), -12),
            'downloads' => (int) ($p['downloads'] ?? 0),
            'followers' => (int) ($p['followers'] ?? 0),
            'license' => is_array($p['license'] ?? null) ? (string) ($p['license']['name'] ?? $p['license']['id'] ?? '') : '',
            'published' => is_string($p['published'] ?? null) ? $p['published'] : null,
            'updated' => is_string($p['updated'] ?? null) ? $p['updated'] : null,
            'links' => array_filter([
                'source' => $https($p['source_url'] ?? null),
                'issues' => $https($p['issues_url'] ?? null),
                'wiki' => $https($p['wiki_url'] ?? null),
                'discord' => $https($p['discord_url'] ?? null),
            ]),
        ];
    }

    /**
     * Versions of a project that carry an installable file hosted on Modrinth's CDN.
     *
     * @return list<array<string, mixed>>
     */
    public function versions(string $project, ?string $loader, ?string $gameVersion): array
    {
        $params = [];
        $params['loaders'] = json_encode($loader ? [$loader] : self::PLUGIN_LOADERS);
        if ($gameVersion) {
            $params['game_versions'] = json_encode([$gameVersion]);
        }

        $versions = $this->get('/project/'.rawurlencode($project).'/version', $params);

        $out = [];
        foreach ($versions as $version) {
            $files = $version['files'] ?? [];
            $file = null;
            foreach ($files as $candidate) {
                if (! $this->isDownloadable($candidate['url'] ?? '', $candidate['filename'] ?? '')) {
                    continue;
                }
                if ($file === null || ($candidate['primary'] ?? false)) {
                    $file = $candidate;
                }
            }
            if ($file === null) {
                continue;
            }

            $out[] = [
                'id' => $version['id'],
                'name' => $version['name'] ?? $version['version_number'],
                'version_number' => $version['version_number'] ?? '',
                'version_type' => $version['version_type'] ?? 'release',
                'game_versions' => array_values($version['game_versions'] ?? []),
                'loaders' => array_values($version['loaders'] ?? []),
                'date_published' => $version['date_published'] ?? null,
                'downloads' => (int) ($version['downloads'] ?? 0),
                'file' => [
                    'url' => $file['url'],
                    'filename' => $file['filename'],
                    'size' => (int) ($file['size'] ?? 0),
                    'sha512' => $file['hashes']['sha512'] ?? null,
                ],
            ];
        }

        return $out;
    }

    /**
     * Filter options for the browse UI.
     *
     * @return array{loaders: list<array{id: string, name: string}>, game_versions: list<string>, categories: list<string>}
     */
    public function meta(): array
    {
        $loaders = [];
        foreach ($this->get('/tag/loader', [], 60) as $loader) {
            if (in_array($loader['name'], self::PLUGIN_LOADERS, true)) {
                $loaders[] = ['id' => $loader['name'], 'name' => ucfirst($loader['name'])];
            }
        }

        $versions = [];
        foreach ($this->get('/tag/game_version', [], 60) as $version) {
            if (($version['version_type'] ?? '') === 'release') {
                $versions[] = $version['version'];
            }
        }

        $categories = [];
        foreach ($this->get('/tag/category', [], 60) as $category) {
            if (($category['project_type'] ?? '') === 'plugin') {
                $categories[] = $category['name'];
            }
        }

        return [
            'loaders' => $loaders,
            'game_versions' => array_slice($versions, 0, 120),
            'categories' => $categories,
        ];
    }

    /** Only jar files served from Modrinth's own CDN are ever handed to the browser for installation. */
    private function isDownloadable(string $url, string $filename): bool
    {
        return parse_url($url, PHP_URL_SCHEME) === 'https'
            && parse_url($url, PHP_URL_HOST) === self::DOWNLOAD_HOST
            && str_ends_with(strtolower($filename), '.jar');
    }

    /**
     * @param  array<string, scalar>  $params
     * @return array<mixed>
     *
     * @throws ModrinthUnavailableException
     */
    private function get(string $path, array $params, ?int $minutes = null): array
    {
        $key = 'ext.vizion.drift-plugins-'.md5($path.json_encode($params));

        $fetch = function () use ($path, $params) {
            try {
                $agent = 'DriftPlugins/1.2.3'.($this->contact !== '' ? " ({$this->contact})" : '');

                return Http::withUserAgent($agent)
                    ->acceptJson()
                    ->timeout(10)
                    ->get(self::BASE_URL.$path, $params)
                    ->throw()
                    ->json() ?? [];
            } catch (ConnectionException|RequestException $e) {
                throw new ModrinthUnavailableException('Modrinth could not be reached. Try again shortly.', 0, $e);
            }
        };

        try {
            return Cache::remember($key, now()->addMinutes($minutes ?? $this->cacheMinutes), $fetch);
        } catch (ModrinthUnavailableException $e) {
            throw $e;
        } catch (\Throwable $e) {
            // The Panel's cache store is unwritable (e.g. storage/framework/cache has the wrong
            // owner). Caching is only an optimisation, so fetch directly instead of failing.
            report($e);

            return $fetch();
        }
    }

    /** Featured gallery image (or the first gallery image) of a hit, only if it is served from Modrinth's CDN. */
    private function bannerUrl(array $hit): ?string
    {
        $gallery = is_array($hit['gallery'] ?? null) ? ($hit['gallery'][0] ?? null) : null;
        $url = $hit['featured_gallery'] ?? $gallery;

        return is_string($url) && str_starts_with($url, 'https://'.self::DOWNLOAD_HOST.'/') ? $url : null;
    }
}
