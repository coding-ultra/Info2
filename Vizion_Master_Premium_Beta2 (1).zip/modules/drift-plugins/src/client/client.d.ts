import type { ExtensionDefinition } from '@pterodactyl/sdk';

declare const definition: ExtensionDefinition;
export default definition;
