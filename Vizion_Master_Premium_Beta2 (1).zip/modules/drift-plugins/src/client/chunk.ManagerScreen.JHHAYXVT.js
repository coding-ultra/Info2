import {
  getAvailability,
  deleteFiles,
  forget,
  installFile,
  readRegistry
} from "./chunk.chunk.YJI4FYIV.js";
import {
  getInstallDirectory
} from "./chunk.chunk.4YEQZHHQ.js";
import {
  Header,
  formatBytes,
  siblingHref
} from "./chunk.chunk.QBDZG3JR.js";

// src/client/screens/ManagerScreen.tsx
import { Alert as Alert2, ServerContentBlock, useServerPermission as useServerPermission2 } from "@pterodactyl/sdk";
import { useCurrentServerRequired } from "@pterodactyl/sdk";
import { useQuery as useQueryAvail } from "@tanstack/react-query";
import { Alert as AlertAvail, Spinner as SpinnerAvail, httpErrorToHuman as httpErrorAvail } from "@pterodactyl/sdk";

// src/client/components/InstalledPlugins.tsx
import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { Alert, Button, Dialog, Table, TitledGreyBox, httpErrorToHuman, invalidateServerData, toast, useServerFiles, useServerPermission } from "@pterodactyl/sdk";
import { Fragment, jsx, jsxs } from "react/jsx-runtime";
function InstalledPlugins({ serverUuid }) {
  const directory = getInstallDirectory();
  const files = useServerFiles(serverUuid, directory, (data) => data.data.filter((f) => f.attributes.is_file && f.attributes.name.toLowerCase().endsWith(".jar")));
  const canDelete = useServerPermission(["file.delete"], false);
  const canInstall = useServerPermission(["file.create", "file.update"], false);
  const [selected, setSelected] = useState([]);
  const [action, setAction] = useState(null);
  const rows = files.data ?? [];
  const names = rows.map((f) => f.attributes.name);
  const chosen = selected.filter((n) => names.includes(n));
  const registry = readRegistry(serverUuid);
  const reinstallable = chosen.filter((n) => registry[n]);
  const skipped = chosen.length - reinstallable.length;
  const toggle = (name) => setSelected((cur) => cur.includes(name) ? cur.filter((n) => n !== name) : [...cur, name]);
  const allChecked = names.length > 0 && chosen.length === names.length;
  const run = useMutation({
    mutationFn: async (kind) => {
      if (kind === "delete") {
        await deleteFiles(serverUuid, directory, chosen);
        forget(serverUuid, chosen);
      } else {
        await deleteFiles(serverUuid, directory, reinstallable);
        for (const name of reinstallable) {
          await installFile(serverUuid, registry[name].url, directory, name);
        }
      }
      await invalidateServerData(serverUuid, ["files"]);
      return kind;
    },
    onSuccess: (kind) => {
      toast.success(kind === "delete" ? "Plugins deleted. Restart the server to unload them." : "Plugins reinstalled. Restart the server to load them.");
      setSelected([]);
      setAction(null);
    },
    onError: (error) => {
      toast.error(httpErrorToHuman(error));
      void invalidateServerData(serverUuid, ["files"]);
      setAction(null);
    }
  });
  return /* @__PURE__ */ jsxs(TitledGreyBox, { title: `Plugin manager \xB7 ${directory}`, children: [
    /* @__PURE__ */ jsxs("div", { className: "vz:mb-3 vz:flex vz:flex-wrap vz:items-center vz:gap-2", children: [
      /* @__PURE__ */ jsx(Button, { size: "small", disabled: !canInstall || reinstallable.length === 0, onClick: () => setAction("reinstall"), children: "Reinstall selected" }),
      /* @__PURE__ */ jsx(Button, { size: "small", disabled: !canDelete || chosen.length === 0, onClick: () => setAction("delete"), children: "Delete selected" }),
      /* @__PURE__ */ jsx("span", { className: "vz:text-xs vz:text-muted-foreground", children: chosen.length > 0 ? `${chosen.length} selected` : "Tick plugins below to manage them" })
    ] }),
    /* @__PURE__ */ jsx(
      Table,
      {
        rows,
        keyOf: (file) => file.attributes.name,
        isFetching: files.isFetching,
        emptyState: files.isError ? `Nothing found in ${directory} yet.` : "No plugin jars installed yet.",
        columns: [
          {
            id: "select",
            label: /* @__PURE__ */ jsx("input", { type: "checkbox", "aria-label": "Select all", checked: allChecked, onChange: () => setSelected(allChecked ? [] : names) }),
            cell: (file) => /* @__PURE__ */ jsx(
              "input",
              {
                type: "checkbox",
                "aria-label": `Select ${file.attributes.name}`,
                checked: chosen.includes(file.attributes.name),
                onChange: () => toggle(file.attributes.name)
              }
            )
          },
          { id: "name", label: "File", cell: (file) => file.attributes.name },
          { id: "size", label: "Size", cell: (file) => formatBytes(file.attributes.size ?? 0) },
          { id: "modified", label: "Modified", cell: (file) => new Date(file.attributes.modified_at).toLocaleString() }
        ]
      }
    ),
    /* @__PURE__ */ jsx(Dialog, { open: action !== null, onClose: () => !run.isPending && setAction(null), title: action === "delete" ? "Delete plugins" : "Reinstall plugins", children: /* @__PURE__ */ jsxs("div", { className: "vz:grid vz:gap-3", children: [
      action === "delete" ? /* @__PURE__ */ jsxs("p", { className: "vz:text-sm", children: [
        "Permanently delete ",
        chosen.length,
        " plugin file",
        chosen.length === 1 ? "" : "s",
        " from ",
        directory,
        "? This cannot be undone."
      ] }) : /* @__PURE__ */ jsxs(Fragment, { children: [
        /* @__PURE__ */ jsxs("p", { className: "vz:text-sm", children: [
          "Re-download ",
          reinstallable.length,
          " plugin",
          reinstallable.length === 1 ? "" : "s",
          " from Modrinth, replacing the current file."
        ] }),
        skipped > 0 && /* @__PURE__ */ jsxs(Alert, { type: "warning", children: [
          skipped,
          " selected jar",
          skipped === 1 ? " was" : "s were",
          " not installed through Drift Plugins in this browser and will be left untouched."
        ] })
      ] }),
      /* @__PURE__ */ jsx("ul", { className: "vz:max-h-40 vz:overflow-auto vz:text-xs vz:text-muted-foreground", children: (action === "delete" ? chosen : reinstallable).map((n) => /* @__PURE__ */ jsx("li", { children: n }, n)) }),
      /* @__PURE__ */ jsxs("div", { className: "vz:flex vz:justify-end vz:gap-2", children: [
        /* @__PURE__ */ jsx(Button.Text, { onClick: () => setAction(null), disabled: run.isPending, children: "Cancel" }),
        /* @__PURE__ */ jsx(Button, { isLoading: run.isPending, onClick: () => action && run.mutate(action), children: action === "delete" ? "Delete" : "Reinstall" })
      ] })
    ] }) })
  ] });
}

// src/client/screens/ManagerScreen.tsx
import { jsx as jsx2, jsxs as jsxs2 } from "react/jsx-runtime";
function ManagerScreenInner() {
  const server = useCurrentServerRequired();
  const canRead = useServerPermission2(["file.read"], false);
  return /* @__PURE__ */ jsx2(ServerContentBlock, { title: "Plugin Manager", children: /* @__PURE__ */ jsxs2("div", { className: "vz:grid vz:gap-4", children: [
    /* @__PURE__ */ jsx2(Header, { subtitle: "Manage installed plugins", link: { label: "Browse plugins", href: siblingHref("browse") } }),
    !canRead && /* @__PURE__ */ jsx2(Alert2, { type: "warning", children: "You need the file read permission to manage plugins on this server." }),
    canRead && /* @__PURE__ */ jsx2(InstalledPlugins, { serverUuid: server.attributes.uuid })
  ] }) });
}
function ManagerScreen() {
  const server = useCurrentServerRequired();
  const uuid = server.attributes.uuid;
  const availability = useQueryAvail({ queryKey: ["drift-plugins", "availability", uuid], queryFn: () => getAvailability(uuid), staleTime: 60 * 1e3 });
  if (availability.isLoading) {
    return /* @__PURE__ */ jsx2(ServerContentBlock, { title: "Plugin Manager", children: /* @__PURE__ */ jsx2(SpinnerAvail, { centered: true }) });
  }
  if (availability.isError) {
    return /* @__PURE__ */ jsx2(ServerContentBlock, { title: "Plugin Manager", children: /* @__PURE__ */ jsx2(AlertAvail, { type: "danger", children: httpErrorAvail(availability.error) }) });
  }
  if (!availability.data?.enabled) {
    return /* @__PURE__ */ jsx2(ServerContentBlock, { title: "Plugin Manager", children: /* @__PURE__ */ jsx2(AlertAvail, { type: "warning", children: "Drift Plugins isn't available for this server's egg." }) });
  }
  return /* @__PURE__ */ jsx2(ManagerScreenInner, {});
}
export {
  ManagerScreen as default
};
