import {
  PluginCard,
  eggsKey,
  getAdminConfig,
  getEggs,
  getPreviewPlugins,
  gridClass,
  saveAdminConfig
} from "./chunk.chunk.L2OIYKCU.js";
import {
  Header
} from "./chunk.chunk.QBDZG3JR.js";

// src/client/screens/ConfigScreen.tsx
import { useEffect, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Alert, Button, ContentBox, Input, Label, PageContentBlock, Select, Spinner, Switch, httpErrorToHuman, toast } from "@pterodactyl/sdk";
import { jsx, jsxs } from "react/jsx-runtime";
var queryKey = ["drift-plugins", "admin-config"];
var SAMPLE_BANNER = "data:image/svg+xml;utf8," + encodeURIComponent(
  "<svg xmlns='http://www.w3.org/2000/svg' width='600' height='200'><defs><linearGradient id='g' x1='0' x2='1' y1='0' y2='1'><stop offset='0' stop-color='#22d3ee'/><stop offset='0.5' stop-color='#a855f7'/><stop offset='1' stop-color='#f97316'/></linearGradient></defs><rect width='600' height='200' fill='url(#g)'/><circle cx='460' cy='60' r='60' fill='#fff' fill-opacity='0.35'/><rect x='40' y='110' width='220' height='50' fill='#000' fill-opacity='0.25'/></svg>"
);
var SAMPLE = {
  project_id: "sample",
  slug: "sample",
  title: "Sample Plugin",
  description: "This is how a plugin looks with your current settings.",
  icon_url: null,
  banner_url: SAMPLE_BANNER,
  author: "drift",
  downloads: 125e4,
  follows: 4300,
  categories: ["utility", "economy"],
  date_modified: null
};
var SAMPLES = [SAMPLE, { ...SAMPLE, project_id: "sample2", title: "Another Plugin", banner_url: null, icon_url: null }];
var slider = { width: "100%" };
function EggVisibilityForm({ requirePluginEgg, overrides, onRequire, onOverrides }) {
  const eggs = useQuery({ queryKey: eggsKey, queryFn: getEggs, staleTime: 60 * 1e3 });
  const enabled = (egg) => {
    const choice = overrides[String(egg.id)];
    if (choice === "show") return true;
    if (choice === "hide") return false;
    return requirePluginEgg ? egg.plugins : true;
  };
  const choose = (id, choice) => {
    const next = { ...overrides };
    if (choice === "auto") delete next[String(id)];
    else next[String(id)] = choice;
    onOverrides(next);
  };
  return /* @__PURE__ */ jsx(ContentBox, { title: "Egg availability", children: /* @__PURE__ */ jsxs("div", { style: { display: "grid", gap: "1.25rem", maxWidth: "36rem" }, children: [
    /* @__PURE__ */ jsx(
      Switch,
      {
        label: "Only plugin-capable eggs",
        description: "Drift Plugins is hidden on servers whose egg is not a plugin server (Paper, Purpur, Spigot, Folia, Velocity and so on) or a mod + plugin hybrid (Mohist, Arclight and so on). Turn this off to show it on every egg.",
        checked: requirePluginEgg,
        onChange: (value) => onRequire(value)
      }
    ),
    /* @__PURE__ */ jsxs("div", { children: [
      /* @__PURE__ */ jsx(Label, { children: "Per-egg choice" }),
      /* @__PURE__ */ jsx("p", { className: "vz:text-xs vz:text-muted-foreground", children: "Automatic follows the switch above. Always show or Always hide overrides it for that egg." })
    ] }),
    eggs.isLoading && /* @__PURE__ */ jsx(Spinner, { centered: true }),
    eggs.isError && /* @__PURE__ */ jsx(Alert, { type: "danger", children: httpErrorToHuman(eggs.error) }),
    eggs.data && eggs.data.length === 0 && /* @__PURE__ */ jsx("p", { className: "vz:text-xs vz:text-muted-foreground", children: "No eggs found." }),
    eggs.data && eggs.data.length > 0 && /* @__PURE__ */ jsx("ul", { className: "vz:grid vz:gap-2", children: eggs.data.map((egg) => {
      const choice = overrides[String(egg.id)] ?? "auto";
      return /* @__PURE__ */ jsxs("li", { className: "vz:flex vz:flex-wrap vz:items-center vz:justify-between vz:gap-3", children: [
        /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsx("div", { className: "vz:text-sm vz:font-medium vz:text-foreground", children: egg.name }),
          /* @__PURE__ */ jsxs("div", { className: "vz:text-xs vz:text-muted-foreground", children: [
            enabled(egg) ? "Shown" : "Hidden",
            " \xB7 ",
            egg.group ?? "Not a plugin server"
          ] })
        ] }),
        /* @__PURE__ */ jsx("div", { style: { minWidth: "11rem" }, children: /* @__PURE__ */ jsx(
          Select,
          {
            value: choice,
            onChange: (v) => choose(egg.id, String(v) === "show" || String(v) === "hide" ? String(v) : "auto"),
            options: [
              { value: "auto", label: "Automatic" },
              { value: "show", label: "Always show" },
              { value: "hide", label: "Always hide" }
            ]
          }
        ) })
      ] }, egg.id);
    }) })
  ] }) });
}
function ConfigScreen() {
  const queryClient = useQueryClient();
  const config = useQuery({ queryKey, queryFn: getAdminConfig });
  const [form, setForm] = useState(null);
  const preview = useQuery({ queryKey: ["drift-plugins", "preview"], queryFn: getPreviewPlugins, staleTime: Infinity, refetchOnWindowFocus: false, retry: false });
  useEffect(() => {
    if (config.data && form === null) setForm(config.data);
  }, [config.data, form]);
  const save = useMutation({
    mutationFn: (input) => saveAdminConfig(input),
    onSuccess: (saved) => {
      queryClient.setQueryData(queryKey, saved);
      void queryClient.invalidateQueries({ queryKey: ["drift-plugins", "layout"] });
      setForm(saved);
      toast.success("Settings saved. Reload server pages to see the new layout.");
    },
    onError: (error) => toast.error(httpErrorToHuman(error))
  });
  if (config.isLoading || !form) {
    return /* @__PURE__ */ jsx(PageContentBlock, { title: "Drift Plugins", children: /* @__PURE__ */ jsx(ContentBox, { title: "Drift Plugins", children: config.isError ? /* @__PURE__ */ jsx(Alert, { type: "danger", children: httpErrorToHuman(config.error) }) : /* @__PURE__ */ jsx(Spinner, { centered: true }) }) });
  }
  const set = (key, value) => setForm({ ...form, [key]: value });
  const num = (value, min, max) => Math.min(max, Math.max(min, Number.parseInt(value, 10) || min));
  const isCard = form.layout === "card";
  const bg = form.show_background;
  return /* @__PURE__ */ jsx(PageContentBlock, { title: "Drift Plugins", children: /* @__PURE__ */ jsxs("div", { className: "vz:grid vz:gap-4", children: [
    /* @__PURE__ */ jsx(Header, { subtitle: "Settings and plugin list layout" }),
    /* @__PURE__ */ jsx(ContentBox, { title: "Plugin list layout", children: /* @__PURE__ */ jsxs("div", { style: { display: "grid", gap: "1.25rem", maxWidth: "36rem" }, children: [
      /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsx(Label, { children: "Layout" }),
        /* @__PURE__ */ jsx(
          Select,
          {
            value: form.layout,
            onChange: (v) => set("layout", String(v) === "row" ? "row" : "card"),
            options: [
              { value: "card", label: "Cards" },
              { value: "row", label: "Rows" }
            ]
          }
        )
      ] }),
      isCard && /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsx(Label, { children: "Cards per row" }),
        /* @__PURE__ */ jsx(
          Select,
          {
            value: String(form.columns),
            onChange: (v) => set("columns", [2, 3, 4].includes(Number(v)) ? Number(v) : 2),
            options: [
              { value: "2", label: "2 cards per row" },
              { value: "3", label: "3 cards per row" },
              { value: "4", label: "4 cards per row" }
            ]
          }
        )
      ] }),
      /* @__PURE__ */ jsx(
        Switch,
        {
          label: "Background image",
          description: "Use the plugin's gallery image (or its icon) behind each card or row.",
          checked: form.show_background,
          onChange: (checked) => set("show_background", checked)
        }
      ),
      /* @__PURE__ */ jsx(
        Switch,
        {
          label: "Dark overlay",
          description: "Darkens the image so the text stays readable.",
          checked: form.show_overlay,
          onChange: (checked) => set("show_overlay", checked)
        }
      ),
      bg && form.show_overlay && /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsxs(Label, { children: [
          "Overlay strength: ",
          form.overlay_opacity,
          "%"
        ] }),
        /* @__PURE__ */ jsx(
          "input",
          {
            type: "range",
            min: 0,
            max: 100,
            step: 5,
            value: form.overlay_opacity,
            style: slider,
            onChange: (e) => set("overlay_opacity", num(e.target.value, 0, 100))
          }
        )
      ] }),
      /* @__PURE__ */ jsx(
        Switch,
        {
          label: "Blur the background",
          description: "Softens the image behind the text.",
          checked: form.blur_enabled,
          onChange: (checked) => set("blur_enabled", checked)
        }
      ),
      bg && form.blur_enabled && /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsxs(Label, { children: [
          "Blur amount: ",
          form.blur_amount,
          "px"
        ] }),
        /* @__PURE__ */ jsx(
          "input",
          {
            type: "range",
            min: 0,
            max: 40,
            step: 1,
            value: form.blur_amount,
            style: slider,
            onChange: (e) => set("blur_amount", num(e.target.value, 0, 40))
          }
        )
      ] }),
      !bg && /* @__PURE__ */ jsx(Alert, { type: "info", children: "The background image is off, so the overlay and blur have nothing to apply to." })
    ] }) }),
    /* @__PURE__ */ jsx(ContentBox, { title: "Live preview", children: /* @__PURE__ */ jsxs("div", { style: { display: "grid", gap: "0.75rem" }, children: [
      /* @__PURE__ */ jsxs("div", { className: "vz:flex vz:items-center vz:justify-between vz:gap-2", children: [
        /* @__PURE__ */ jsx("span", { className: "vz:text-xs vz:text-muted-foreground", children: "4 random popular plugins from Modrinth, drawn with the settings above." }),
        /* @__PURE__ */ jsx(Button, { size: "small", isLoading: preview.isFetching, onClick: () => void preview.refetch(), children: "Shuffle" })
      ] }),
      preview.isError && /* @__PURE__ */ jsxs(Alert, { type: "warning", children: [
        "Could not load plugins from Modrinth (",
        httpErrorToHuman(preview.error),
        "). Showing samples instead."
      ] }),
      preview.isLoading ? /* @__PURE__ */ jsx(Spinner, { centered: true }) : /* @__PURE__ */ jsx("ul", { className: gridClass(form), children: (preview.data && preview.data.length > 0 ? preview.data : SAMPLES).map((plugin) => /* @__PURE__ */ jsx(PluginCard, { plugin, canInstall: true, onInstall: () => void 0, settings: form }, plugin.project_id)) })
    ] }) }),
    /* @__PURE__ */ jsx(
      EggVisibilityForm,
      {
        requirePluginEgg: form.require_plugin_egg !== false,
        overrides: form.egg_overrides ?? {},
        onRequire: (value) => set("require_plugin_egg", value),
        onOverrides: (value) => set("egg_overrides", value)
      }
    ),
    /* @__PURE__ */ jsx(ContentBox, { title: "General", children: /* @__PURE__ */ jsxs("div", { style: { display: "grid", gap: "1.25rem", maxWidth: "36rem" }, children: [
      /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsx(Label, { children: "Install directory" }),
        /* @__PURE__ */ jsx(Input, { value: form.install_directory, onChange: (e) => set("install_directory", e.target.value) }),
        /* @__PURE__ */ jsx("p", { className: "vz:mt-1 vz:text-xs vz:text-muted-foreground", children: "Folder, relative to the server root, that plugins are downloaded into." })
      ] }),
      /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsx(Label, { children: "Search cache (minutes)" }),
        /* @__PURE__ */ jsx(Input, { type: "number", min: 1, max: 1440, value: String(form.cache_minutes), onChange: (e) => set("cache_minutes", num(e.target.value, 1, 1440)) })
      ] }),
      /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsx(Label, { children: "Modrinth contact" }),
        /* @__PURE__ */ jsx(Input, { value: form.contact, onChange: (e) => set("contact", e.target.value), placeholder: "https://example.com or you@example.com" }),
        /* @__PURE__ */ jsx("p", { className: "vz:mt-1 vz:text-xs vz:text-muted-foreground", children: "Sent in the User-Agent of every Modrinth request, as Modrinth asks API consumers to identify themselves." })
      ] })
    ] }) }),
    /* @__PURE__ */ jsx("div", { className: "vz:flex vz:justify-end", children: /* @__PURE__ */ jsx(Button, { isLoading: save.isPending, onClick: () => save.mutate(form), children: "Save settings" }) })
  ] }) });
}
export {
  ConfigScreen as default
};
