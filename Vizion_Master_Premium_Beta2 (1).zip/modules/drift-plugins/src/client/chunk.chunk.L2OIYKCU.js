import {
  formatCount
} from "./chunk.chunk.QBDZG3JR.js";

// src/client/components/PluginCard.tsx
import { Button } from "@pterodactyl/sdk";
import { Fragment, jsx, jsxs } from "react/jsx-runtime";
var iconBase = {
  display: "inline-flex",
  alignItems: "center",
  justifyContent: "center",
  width: "1.5rem",
  height: "1.5rem",
  borderRadius: "0.375rem",
  cursor: "pointer",
  padding: 0
};
var svgProps = { width: 14, height: 14, viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: 2, strokeLinecap: "round", strokeLinejoin: "round", "aria-hidden": true };
var oneLine = { whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" };
var lines = (n) => ({ display: "-webkit-box", WebkitLineClamp: n, WebkitBoxOrient: "vertical", overflow: "hidden", textOverflow: "ellipsis" });
function PluginCard({ plugin, canInstall, onInstall, onReadMore, settings }) {
  const row = settings.layout === "row";
  const compact = !row && settings.columns === 4;
  const image = settings.show_background ? plugin.banner_url ?? plugin.icon_url : null;
  const blur = settings.blur_enabled ? settings.blur_amount : 0;
  const imageStyle = {
    filter: blur > 0 ? `blur(${blur}px)` : void 0,
    // Scaled up so the blurred edges never show a lighter border.
    transform: blur > 0 ? `scale(${1 + blur / 50})` : void 0
  };
  const alpha = settings.overlay_opacity / 100;
  const overlay = `linear-gradient(to right, rgba(0,0,0,${alpha}), rgba(0,0,0,${(alpha * 0.7).toFixed(2)}))`;
  const shadow = image && !settings.show_overlay ? "0 1px 3px rgba(0,0,0,0.85)" : void 0;
  const title = image ? { color: "#fff", textShadow: shadow } : void 0;
  const muted = image ? { color: "rgba(255,255,255,0.8)", textShadow: shadow } : void 0;
  const iconSize = row ? "vz:h-10 vz:w-10" : "vz:h-14 vz:w-14";
  const icon = plugin.icon_url ? /* @__PURE__ */ jsx("img", { src: plugin.icon_url, alt: "", loading: "lazy", className: `vz:relative vz:shrink-0 vz:rounded-md ${iconSize}` }) : /* @__PURE__ */ jsx("div", { className: `vz:relative vz:shrink-0 vz:rounded-md vz:border vz:border-border ${iconSize}` });
  const titleLink = /* @__PURE__ */ jsx(
    "a",
    {
      href: `https://modrinth.com/plugin/${plugin.slug}`,
      target: "_blank",
      rel: "noreferrer noopener",
      className: "vz:font-semibold vz:text-foreground vz:hover:underline",
      style: compact ? { ...title, ...oneLine, display: "block" } : title,
      children: plugin.title
    }
  );
  const author = /* @__PURE__ */ jsxs("span", { className: "vz:text-xs vz:text-muted-foreground", style: compact ? { ...muted, ...oneLine, display: "block" } : muted, children: [
    "by ",
    plugin.author
  ] });
  const description = /* @__PURE__ */ jsx("p", { className: "vz:mt-1 vz:text-sm vz:text-muted-foreground", style: { ...muted, ...row ? oneLine : lines(2) }, children: plugin.description });
  const stats = /* @__PURE__ */ jsxs("p", { className: `vz:text-xs vz:text-muted-foreground ${row ? "vz:mt-1" : "vz:mt-2"}`, style: { ...muted, ...oneLine }, children: [
    formatCount(plugin.downloads),
    " downloads \xB7 ",
    formatCount(plugin.follows),
    " follows",
    plugin.categories.length > 0 && ` \xB7 ${plugin.categories.join(", ")}`
  ] });
  const iconStyle = image ? { ...iconBase, color: "#fff", background: "rgba(0,0,0,0.45)", border: "1px solid rgba(255,255,255,0.35)" } : { ...iconBase, color: "var(--foreground)", background: "transparent", border: "1px solid var(--border)" };
  const iconButtons = /* @__PURE__ */ jsxs("span", { className: "vz:relative vz:flex vz:items-center vz:gap-1", style: { flexShrink: 0 }, children: [
    onReadMore && /* @__PURE__ */ jsx("button", { type: "button", title: "Show all details", "aria-label": `Show details of ${plugin.title}`, style: iconStyle, onClick: () => onReadMore(plugin), children: /* @__PURE__ */ jsxs("svg", { ...svgProps, children: [
      /* @__PURE__ */ jsx("circle", { cx: "12", cy: "12", r: "10" }),
      /* @__PURE__ */ jsx("path", { d: "M12 16v-4M12 8h.01" })
    ] }) }),
    /* @__PURE__ */ jsx(
      "a",
      {
        href: `https://modrinth.com/plugin/${plugin.slug}`,
        target: "_blank",
        rel: "noreferrer noopener",
        title: "Open on Modrinth",
        "aria-label": `Open ${plugin.title} on Modrinth`,
        style: { ...iconStyle, textDecoration: "none" },
        children: /* @__PURE__ */ jsx("svg", { ...svgProps, children: /* @__PURE__ */ jsx("path", { d: "M15 3h6v6M10 14 21 3M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6" }) })
      }
    )
  ] });
  const readMore = onReadMore && (row || settings.columns >= 3) && /* @__PURE__ */ jsx(
    "button",
    {
      type: "button",
      onClick: () => onReadMore(plugin),
      className: "vz:relative vz:text-xs",
      style: { background: "none", border: 0, padding: 0, cursor: "pointer", textDecoration: "underline", color: image ? "rgba(255,255,255,0.85)" : "var(--muted-foreground)" },
      children: "Read more"
    }
  );
  const buttons = /* @__PURE__ */ jsxs("div", { className: "vz:relative vz:flex vz:items-center vz:gap-2", children: [
    row && iconButtons,
    /* @__PURE__ */ jsx(Button, { size: "small", disabled: !canInstall, onClick: () => onInstall(plugin), children: "Install" })
  ] });
  const background = image && /* @__PURE__ */ jsxs(Fragment, { children: [
    /* @__PURE__ */ jsx(
      "img",
      {
        src: image,
        alt: "",
        "aria-hidden": true,
        loading: "lazy",
        className: "vz:absolute vz:inset-0 vz:h-full vz:w-full vz:object-cover",
        style: imageStyle
      }
    ),
    settings.show_overlay && /* @__PURE__ */ jsx("div", { "aria-hidden": true, className: "vz:absolute vz:inset-0", style: { background: overlay } })
  ] });
  if (compact) {
    return /* @__PURE__ */ jsxs("li", { className: "vz:relative vz:flex vz:flex-col vz:gap-2 vz:overflow-hidden vz:rounded-md vz:border vz:border-border vz:bg-card vz:p-3", children: [
      background,
      /* @__PURE__ */ jsx("div", { className: "vz:absolute", style: { top: "0.5rem", right: "0.5rem" }, children: iconButtons }),
      /* @__PURE__ */ jsxs("div", { className: "vz:relative vz:flex vz:items-center vz:gap-3", style: { paddingRight: "3.5rem" }, children: [
        icon,
        /* @__PURE__ */ jsxs("div", { className: "vz:min-w-0 vz:flex-1", children: [
          titleLink,
          author
        ] })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "vz:relative vz:min-w-0 vz:flex-1", children: [
        description,
        stats,
        readMore && /* @__PURE__ */ jsx("div", { className: "vz:mt-2", children: readMore })
      ] }),
      buttons
    ] });
  }
  return /* @__PURE__ */ jsxs(
    "li",
    {
      className: `vz:relative vz:flex vz:gap-3 vz:overflow-hidden vz:rounded-md vz:border vz:border-border vz:bg-card ${row ? "vz:items-center vz:p-2" : "vz:items-start vz:p-3"}`,
      children: [
        background,
        !row && /* @__PURE__ */ jsx("div", { className: "vz:absolute", style: { top: "0.5rem", right: "0.5rem" }, children: iconButtons }),
        icon,
        /* @__PURE__ */ jsxs("div", { className: "vz:relative vz:min-w-0 vz:flex-1", style: row ? void 0 : { paddingRight: "3.5rem" }, children: [
          /* @__PURE__ */ jsxs("div", { className: "vz:flex vz:flex-wrap vz:items-baseline vz:gap-x-2", children: [
            titleLink,
            author
          ] }),
          description,
          stats,
          readMore && /* @__PURE__ */ jsx("div", { className: "vz:mt-2", children: readMore })
        ] }),
        /* @__PURE__ */ jsx("div", { style: row ? void 0 : { alignSelf: "flex-end" }, children: buttons })
      ]
    }
  );
}

// src/client/layout.ts
import { http } from "@pterodactyl/sdk";
var DEFAULT_LAYOUT = {
  layout: "card",
  columns: 2,
  show_background: true,
  show_overlay: true,
  overlay_opacity: 75,
  blur_enabled: false,
  blur_amount: 8
};
async function getLayout(server) {
  const { data } = await http.get(`/api/client/servers/${server}/extensions/vizion/drift-plugins/layout`);
  return { ...DEFAULT_LAYOUT, ...data, columns: [2, 3, 4].includes(data.columns) ? data.columns : 2 };
}
var adminUrl = "/api/admin/extensions/vizion/drift-plugins/config";
var withOverrides = (settings) => ({
  ...settings,
  egg_overrides: settings.egg_overrides && !Array.isArray(settings.egg_overrides) ? settings.egg_overrides : {}
});
async function getAdminConfig() {
  return withOverrides((await http.get(adminUrl)).data);
}
async function saveAdminConfig(input) {
  return withOverrides((await http.put(adminUrl, input)).data);
}
var eggsKey = ["drift-plugins", "admin-eggs"];
async function getEggs() {
  return (await http.get("/api/admin/extensions/vizion/drift-plugins/eggs")).data.data ?? [];
}
async function getPreviewPlugins() {
  return (await http.get("/api/admin/extensions/vizion/drift-plugins/preview")).data.data;
}
function gridClass(settings) {
  if (settings.layout === "row") return "vz:grid vz:grid-cols-1 vz:gap-3";
  if (settings.columns === 3) return "vz:grid vz:grid-cols-1 vz:gap-3 vz:sm:grid-cols-2 vz:lg:grid-cols-3";
  if (settings.columns === 4) return "vz:grid vz:grid-cols-1 vz:gap-3 vz:sm:grid-cols-2 vz:lg:grid-cols-4";
  return "vz:grid vz:grid-cols-1 vz:gap-3 vz:sm:grid-cols-2";
}

export {
  PluginCard,
  DEFAULT_LAYOUT,
  getLayout,
  getAdminConfig,
  saveAdminConfig,
  eggsKey,
  getEggs,
  getPreviewPlugins,
  gridClass
};
