// src/client/api.ts
import { http } from "@pterodactyl/sdk";
var base = (server) => `/api/client/servers/${server}/extensions/vizion/drift-plugins`;
async function getAvailability(server) {
  return (await http.get(`${base(server)}/availability`)).data.data;
}
async function getMeta(server) {
  return (await http.get(`${base(server)}/meta`)).data;
}
async function searchPlugins(server, p) {
  const { data } = await http.get(`${base(server)}/search`, {
    params: {
      query: p.query || void 0,
      loader: p.loader || void 0,
      game_version: p.gameVersion || void 0,
      category: p.category || void 0,
      sort: p.sort,
      page: p.page
    }
  });
  return data;
}
async function getVersions(server, project, loader, gameVersion) {
  const { data } = await http.get(`${base(server)}/projects/${encodeURIComponent(project)}/versions`, {
    params: { loader: loader || void 0, game_version: gameVersion || void 0 }
  });
  return data.data;
}
async function installFile(serverUuid, url, directory, filename) {
  await http.post(`/api/client/servers/${serverUuid}/files/pull`, {
    url,
    directory,
    filename,
    use_header: false,
    foreground: true
  });
}
async function deleteFiles(serverUuid, root, files) {
  await http.post(`/api/client/servers/${serverUuid}/files/delete`, { root, files });
}
async function getDetails(server, project) {
  return (await http.get(`${base(server)}/projects/${encodeURIComponent(project)}`)).data;
}

// src/client/registry.ts
var key = (server) => `drift-plugins:installed:${server}`;
function readRegistry(server) {
  try {
    return JSON.parse(localStorage.getItem(key(server)) ?? "{}") ?? {};
  } catch {
    return {};
  }
}
function write(server, data) {
  try {
    localStorage.setItem(key(server), JSON.stringify(data));
  } catch {
  }
}
function remember(server, filename, record) {
  write(server, { ...readRegistry(server), [filename]: record });
}
function forget(server, filenames) {
  const data = readRegistry(server);
  filenames.forEach((f) => delete data[f]);
  write(server, data);
}

export {
  getAvailability,
  getMeta,
  searchPlugins,
  getVersions,
  installFile,
  deleteFiles,
  getDetails,
  readRegistry,
  remember,
  forget
};
