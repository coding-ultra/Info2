// src/client/config.ts
var installDirectory = "/plugins";
function setConfig(config) {
  const dir = config.install_directory;
  installDirectory = typeof dir === "string" && /^\/[A-Za-z0-9._/-]*$/.test(dir) ? dir.replace(/\/+$/, "") || "/" : "/plugins";
}
function getInstallDirectory() {
  return installDirectory;
}

export {
  setConfig,
  getInstallDirectory
};
