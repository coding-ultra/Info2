import {
  DEFAULT_LAYOUT,
  PluginCard,
  getLayout,
  gridClass
} from "./chunk.chunk.L2OIYKCU.js";
import {
  getAvailability,
  getDetails,
  getMeta,
  getVersions,
  installFile,
  remember,
  searchPlugins
} from "./chunk.chunk.YJI4FYIV.js";
import {
  getInstallDirectory
} from "./chunk.chunk.4YEQZHHQ.js";
import {
  Header,
  detectGameVersion,
  detectLoader,
  formatBytes,
  formatCount,
  siblingHref
} from "./chunk.chunk.QBDZG3JR.js";

// src/client/screens/ServerScreen.tsx
import { useEffect as useEffect3, useRef, useState as useState3 } from "react";
import { keepPreviousData, useQuery as useQuery3 } from "@tanstack/react-query";
import {
  Alert as Alert3,
  Input,
  Label as Label3,
  Pagination,
  Select as Select2,
  ServerContentBlock,
  Spinner as Spinner3,
  TitledGreyBox,
  httpErrorToHuman as httpErrorToHuman3,
  useCurrentServerRequired,
  useServerPermission,
  useServerStartup
} from "@pterodactyl/sdk";

// src/client/components/InstallDialog.tsx
import { useEffect, useState } from "react";
import { useMutation, useQuery } from "@tanstack/react-query";
import { Alert, Button, Dialog, Label, Select, Spinner, httpErrorToHuman, invalidateServerData, toast } from "@pterodactyl/sdk";
import { jsx, jsxs } from "react/jsx-runtime";
function InstallDialog({ plugin, serverUuid, loader, gameVersion, onClose }) {
  const [versionId, setVersionId] = useState("");
  const directory = getInstallDirectory();
  const versions = useQuery({
    queryKey: ["drift-plugins", "versions", serverUuid, plugin?.project_id, loader, gameVersion],
    queryFn: () => getVersions(serverUuid, plugin.project_id, loader, gameVersion),
    enabled: plugin !== null
  });
  useEffect(() => {
    setVersionId(versions.data?.[0]?.id ?? "");
  }, [versions.data]);
  const selected = versions.data?.find((v) => v.id === versionId);
  const install = useMutation({
    mutationFn: async () => {
      if (!selected) throw new Error("Pick a version first.");
      await installFile(serverUuid, selected.file.url, directory, selected.file.filename);
      remember(serverUuid, selected.file.filename, { url: selected.file.url, title: plugin?.title ?? selected.file.filename });
      await invalidateServerData(serverUuid, ["files"]);
    },
    onSuccess: () => {
      toast.success(`${plugin?.title} installed to ${directory}. Restart the server to load it.`);
      onClose();
    },
    onError: (error) => toast.error(httpErrorToHuman(error))
  });
  return /* @__PURE__ */ jsxs(Dialog, { open: plugin !== null, onClose, title: plugin ? `Install ${plugin.title}` : "", children: [
    versions.isLoading && /* @__PURE__ */ jsx(Spinner, { centered: true }),
    versions.isError && /* @__PURE__ */ jsx(Alert, { type: "danger", children: httpErrorToHuman(versions.error) }),
    versions.data && versions.data.length === 0 && /* @__PURE__ */ jsxs(Alert, { type: "warning", children: [
      "No version of this plugin matches the selected loader",
      gameVersion ? ` and Minecraft ${gameVersion}` : "",
      ". Change the filters and try again."
    ] }),
    versions.data && versions.data.length > 0 && /* @__PURE__ */ jsxs("div", { className: "vz:grid vz:gap-3", children: [
      /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsx(Label, { children: "Version" }),
        /* @__PURE__ */ jsx(
          Select,
          {
            value: versionId,
            onChange: (value) => setVersionId(String(value)),
            options: versions.data.map((v) => ({
              value: v.id,
              label: `${v.version_number} (${v.version_type}) \xB7 ${v.game_versions.slice(-3).join(", ")}`,
              textLabel: `${v.version_number} ${v.game_versions.join(" ")}`
            })),
            searchPlaceholder: "Search versions\u2026"
          }
        )
      ] }),
      selected && /* @__PURE__ */ jsxs("p", { className: "vz:text-sm vz:text-muted-foreground", children: [
        selected.file.filename,
        " \xB7 ",
        formatBytes(selected.file.size),
        " \u2192 ",
        directory,
        "/"
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "vz:flex vz:justify-end vz:gap-2", children: [
        /* @__PURE__ */ jsx(Button.Text, { onClick: onClose, children: "Cancel" }),
        /* @__PURE__ */ jsx(Button, { isLoading: install.isPending, disabled: !selected, onClick: () => install.mutate(), children: "Install" })
      ] })
    ] })
  ] });
}

// src/client/components/PluginDetailsDialog.tsx
import { useEffect as useEffect2, useState as useState2 } from "react";
import { useQuery as useQuery2 } from "@tanstack/react-query";
import { Alert as Alert2, Button as Button2, Dialog as Dialog2, Spinner as Spinner2, httpErrorToHuman as httpErrorToHuman2 } from "@pterodactyl/sdk";

// src/client/markdown.tsx
import { jsx as jsx2, jsxs as jsxs2 } from "react/jsx-runtime";
var IMAGE_HOST = "https://cdn.modrinth.com/";
var isLink = (url) => url.startsWith("https://");
var isImage = (url) => url.startsWith(IMAGE_HOST);
var INLINE = /(\[(?:!\[[^\]]*\]\([^)]*\)|[^\]])+\]\([^)\s]+(?:\s+"[^"]*")?\))|(!\[[^\]]*\]\([^)\s]+(?:\s+"[^"]*")?\))|(`[^`\n]+`)|(\*\*[^*\n]+\*\*|__[^_\n]+__)|(\*[^*\s][^*\n]*\*|(?<![A-Za-z0-9])_[^_\s][^_\n]*_(?![A-Za-z0-9]))|(https:\/\/[^\s<>)]+)/g;
function inline(text, keyPrefix) {
  const out = [];
  let last = 0;
  let n = 0;
  for (const m of text.matchAll(INLINE)) {
    const index = m.index ?? 0;
    if (index > last) out.push(text.slice(last, index));
    const key = `${keyPrefix}-${n++}`;
    const [whole] = m;
    if (m[1]) {
      const parts = /^\[((?:.|\n)*)\]\(([^)\s]+)/.exec(whole);
      const label = parts?.[1] ?? "";
      const url = parts?.[2] ?? "";
      out.push(
        isLink(url) ? /* @__PURE__ */ jsx2("a", { href: url, target: "_blank", rel: "noreferrer noopener nofollow", style: { textDecoration: "underline", color: "var(--foreground)" }, children: inline(label, key) }, key) : /* @__PURE__ */ jsx2("span", { children: inline(label, key) }, key)
      );
    } else if (m[2]) {
      const parts = /^!\[([^\]]*)\]\(([^)\s]+)/.exec(whole);
      const url = parts?.[2] ?? "";
      if (isImage(url)) {
        out.push(/* @__PURE__ */ jsx2("img", { src: url, alt: parts?.[1] ?? "", loading: "lazy", style: { maxWidth: "100%", height: "auto", borderRadius: "0.375rem", verticalAlign: "middle" } }, key));
      }
    } else if (m[3]) {
      out.push(
        /* @__PURE__ */ jsx2("code", { style: { background: "color-mix(in srgb, var(--foreground) 10%, transparent)", borderRadius: "0.25rem", padding: "0.05rem 0.3rem", fontSize: "0.85em" }, children: whole.slice(1, -1) }, key)
      );
    } else if (m[4]) {
      out.push(/* @__PURE__ */ jsx2("strong", { children: inline(whole.slice(2, -2), key) }, key));
    } else if (m[5]) {
      out.push(/* @__PURE__ */ jsx2("em", { children: inline(whole.slice(1, -1), key) }, key));
    } else if (m[6]) {
      out.push(
        /* @__PURE__ */ jsx2("a", { href: whole, target: "_blank", rel: "noreferrer noopener nofollow", style: { textDecoration: "underline", color: "var(--foreground)" }, children: whole }, key)
      );
    }
    last = index + whole.length;
  }
  if (last < text.length) out.push(text.slice(last));
  return out;
}
function normalise(source) {
  return source.replace(/\r\n?/g, "\n").replace(/<img[^>]*?src=["']([^"']+)["'][^>]*?>/gi, "![]($1)").replace(/<a[^>]*?href=["']([^"']+)["'][^>]*>([\s\S]*?)<\/a>/gi, "[$2]($1)").replace(/<br\s*\/?>/gi, "\n").replace(/<\/(p|div|h[1-6]|li|center)>/gi, "\n\n").replace(/<h([1-6])[^>]*>/gi, (_, level) => `${"#".repeat(Number(level))} `).replace(/<(strong|b)>([\s\S]*?)<\/\1>/gi, "**$2**").replace(/<(em|i)>([\s\S]*?)<\/\1>/gi, "*$2*").replace(/<!--[\s\S]*?-->/g, "").replace(/<\/?[a-zA-Z][^>]*>/g, "");
}
var cell = { border: "1px solid var(--border)", padding: "0.25rem 0.5rem", textAlign: "left" };
function Markdown({ source }) {
  const lines = normalise(source).split("\n");
  const blocks = [];
  let i = 0;
  let k = 0;
  while (i < lines.length) {
    const line = lines[i];
    const key = `b${k++}`;
    if (line.trim() === "") {
      i++;
    } else if (line.trim().startsWith("```")) {
      const code = [];
      i++;
      while (i < lines.length && !lines[i].trim().startsWith("```")) code.push(lines[i++]);
      i++;
      blocks.push(
        /* @__PURE__ */ jsx2("pre", { style: { overflowX: "auto", background: "color-mix(in srgb, var(--foreground) 8%, transparent)", borderRadius: "0.375rem", padding: "0.75rem", fontSize: "0.8rem" }, children: /* @__PURE__ */ jsx2("code", { children: code.join("\n") }) }, key)
      );
    } else if (/^#{1,6}\s/.test(line)) {
      const level = line.match(/^#+/)[0].length;
      const sizes = ["1.25rem", "1.125rem", "1rem", "0.95rem", "0.9rem", "0.85rem"];
      blocks.push(
        /* @__PURE__ */ jsx2("div", { role: "heading", "aria-level": level, style: { fontWeight: 600, fontSize: sizes[level - 1], marginTop: "0.5rem", color: "var(--foreground)" }, children: inline(line.replace(/^#{1,6}\s+/, "").replace(/\s*#+\s*$/, ""), key) }, key)
      );
      i++;
    } else if (/^\s*([-*_])\s*(\1\s*){2,}$/.test(line)) {
      blocks.push(/* @__PURE__ */ jsx2("hr", { style: { border: 0, borderTop: "1px solid var(--border)" } }, key));
      i++;
    } else if (/^>\s?/.test(line)) {
      const quote = [];
      while (i < lines.length && /^>\s?/.test(lines[i])) quote.push(lines[i++].replace(/^>\s?/, ""));
      blocks.push(
        /* @__PURE__ */ jsx2("blockquote", { style: { margin: 0, paddingLeft: "0.75rem", borderLeft: "3px solid var(--border)", color: "var(--muted-foreground)" }, children: inline(quote.join(" "), key) }, key)
      );
    } else if (/^\s*([-*+]|\d+\.)\s+/.test(line)) {
      const ordered = /^\s*\d+\./.test(line);
      const items = [];
      while (i < lines.length && /^\s*([-*+]|\d+\.)\s+/.test(lines[i])) items.push(lines[i++].replace(/^\s*([-*+]|\d+\.)\s+/, ""));
      const List = ordered ? "ol" : "ul";
      blocks.push(
        /* @__PURE__ */ jsx2(List, { style: { margin: 0, paddingLeft: "1.25rem", listStyle: ordered ? "decimal" : "disc", display: "grid", gap: "0.25rem" }, children: items.map((item, n) => /* @__PURE__ */ jsx2("li", { children: inline(item, `${key}-${n}`) }, n)) }, key)
      );
    } else if (line.trim().startsWith("|") && /^\s*\|?[\s:|-]+\|[\s:|-]*$/.test(lines[i + 1] ?? "")) {
      const split = (row) => row.trim().replace(/^\||\|$/g, "").split("|").map((c) => c.trim());
      const head = split(line);
      i += 2;
      const rows = [];
      while (i < lines.length && lines[i].trim().startsWith("|")) rows.push(split(lines[i++]));
      blocks.push(
        /* @__PURE__ */ jsx2("div", { style: { overflowX: "auto" }, children: /* @__PURE__ */ jsxs2("table", { style: { borderCollapse: "collapse", fontSize: "0.85rem" }, children: [
          /* @__PURE__ */ jsx2("thead", { children: /* @__PURE__ */ jsx2("tr", { children: head.map((h, n) => /* @__PURE__ */ jsx2("th", { style: cell, children: inline(h, `${key}h${n}`) }, n)) }) }),
          /* @__PURE__ */ jsx2("tbody", { children: rows.map((r, n) => /* @__PURE__ */ jsx2("tr", { children: r.map((c, m) => /* @__PURE__ */ jsx2("td", { style: cell, children: inline(c, `${key}r${n}c${m}`) }, m)) }, n)) })
        ] }) }, key)
      );
    } else {
      const paragraph = [];
      while (i < lines.length && lines[i].trim() !== "" && !/^(#{1,6}\s|>\s?|\s*([-*+]|\d+\.)\s+|```)/.test(lines[i]) && !lines[i].trim().startsWith("|")) {
        paragraph.push(lines[i++]);
      }
      if (paragraph.length === 0) {
        paragraph.push(lines[i++]);
      }
      blocks.push(/* @__PURE__ */ jsx2("p", { children: inline(paragraph.join("\n"), key) }, key));
    }
  }
  return /* @__PURE__ */ jsx2("div", { style: { display: "grid", gap: "0.75rem", fontSize: "0.875rem", lineHeight: 1.6, color: "var(--foreground)", overflowWrap: "anywhere" }, children: blocks });
}

// src/client/components/PluginDetailsDialog.tsx
import { Fragment, jsx as jsx3, jsxs as jsxs3 } from "react/jsx-runtime";
var LINK_LABELS = { source: "Source code", issues: "Issue tracker", wiki: "Wiki", discord: "Discord" };
var date = (value) => value ? new Date(value).toLocaleDateString() : "-";
var panel = { border: "1px solid var(--border)", borderRadius: "0.5rem", padding: "0.75rem" };
var chip = {
  border: "1px solid var(--border)",
  borderRadius: "999px",
  padding: "0.125rem 0.625rem",
  fontSize: "0.75rem",
  color: "var(--foreground)",
  background: "color-mix(in srgb, var(--foreground) 5%, transparent)"
};
var outlined = {
  display: "inline-flex",
  alignItems: "center",
  gap: "0.375rem",
  border: "1px solid var(--border)",
  borderRadius: "0.375rem",
  padding: "0.375rem 0.75rem",
  fontSize: "0.8rem",
  color: "var(--foreground)",
  background: "transparent",
  textDecoration: "none",
  cursor: "pointer"
};
var iconButton = { ...outlined, width: "2rem", height: "2rem", justifyContent: "center", padding: 0, fontSize: "1.25rem", lineHeight: 1 };
function Label2({ children }) {
  return /* @__PURE__ */ jsx3("div", { style: { fontSize: "0.7rem", letterSpacing: "0.04em", textTransform: "uppercase", color: "var(--muted-foreground)", marginBottom: "0.375rem" }, children });
}
function Chips({ label, items }) {
  if (items.length === 0) return null;
  return /* @__PURE__ */ jsxs3("div", { children: [
    /* @__PURE__ */ jsx3(Label2, { children: label }),
    /* @__PURE__ */ jsx3("div", { style: { display: "flex", flexWrap: "wrap", gap: "0.375rem" }, children: items.map((item) => /* @__PURE__ */ jsx3("span", { style: chip, children: item }, item)) })
  ] });
}
function PluginDetailsDialog({ plugin, serverUuid, canInstall, onClose, onInstall }) {
  const [tab, setTab] = useState2("description");
  const [viewer, setViewer] = useState2(null);
  useEffect2(() => {
    setTab("description");
    setViewer(null);
  }, [plugin?.project_id]);
  const details = useQuery2({
    queryKey: ["drift-plugins", "details", serverUuid, plugin?.project_id],
    queryFn: () => getDetails(serverUuid, plugin.project_id),
    enabled: plugin !== null,
    staleTime: 10 * 60 * 1e3
  });
  const d = details.data;
  const gallery = d?.gallery ?? [];
  const image = viewer !== null ? gallery[viewer] : void 0;
  useEffect2(() => {
    if (viewer === null) return;
    const onKey = (event) => {
      if (event.key === "ArrowRight") setViewer((v) => v === null ? v : (v + 1) % gallery.length);
      if (event.key === "ArrowLeft") setViewer((v) => v === null ? v : (v - 1 + gallery.length) % gallery.length);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [viewer, gallery.length]);
  const tabs = [
    { id: "description", label: "Description" },
    ...gallery.length > 0 ? [{ id: "gallery", label: `Gallery (${gallery.length})` }] : [],
    { id: "details", label: "Details" }
  ];
  return (
    // The header with the cross button is drawn here, so the Dialog's own title stays empty.
    /* @__PURE__ */ jsx3(Dialog2, { open: plugin !== null, onClose, title: "", children: plugin && /* @__PURE__ */ jsx3("div", { style: { display: "grid", gap: "1rem", maxHeight: "80vh", overflowY: "auto", overflowX: "hidden", minWidth: 0 }, children: image ? /* @__PURE__ */ jsxs3("div", { style: { display: "grid", gap: "0.75rem" }, children: [
      /* @__PURE__ */ jsxs3("div", { style: { display: "flex", alignItems: "center", justifyContent: "space-between", gap: "0.5rem" }, children: [
        /* @__PURE__ */ jsx3("button", { type: "button", style: outlined, onClick: () => setViewer(null), children: "\u2190 Back" }),
        /* @__PURE__ */ jsxs3("span", { style: { fontSize: "0.8rem", color: "var(--muted-foreground)" }, children: [
          (viewer ?? 0) + 1,
          " / ",
          gallery.length
        ] }),
        /* @__PURE__ */ jsx3("button", { type: "button", "aria-label": "Close", style: iconButton, onClick: onClose, children: "\xD7" })
      ] }),
      /* @__PURE__ */ jsxs3("div", { style: { position: "relative", display: "flex", alignItems: "center", justifyContent: "center", background: "rgba(0,0,0,0.85)", borderRadius: "0.5rem" }, children: [
        /* @__PURE__ */ jsx3("img", { src: image.url, alt: image.title, style: { maxWidth: "100%", maxHeight: "60vh", objectFit: "contain", borderRadius: "0.5rem" } }),
        gallery.length > 1 && /* @__PURE__ */ jsxs3(Fragment, { children: [
          /* @__PURE__ */ jsx3(
            "button",
            {
              type: "button",
              "aria-label": "Previous image",
              onClick: () => setViewer(((viewer ?? 0) - 1 + gallery.length) % gallery.length),
              style: { ...iconButton, position: "absolute", left: "0.5rem", color: "#fff", background: "rgba(0,0,0,0.55)", borderColor: "rgba(255,255,255,0.35)" },
              children: "\u2039"
            }
          ),
          /* @__PURE__ */ jsx3(
            "button",
            {
              type: "button",
              "aria-label": "Next image",
              onClick: () => setViewer(((viewer ?? 0) + 1) % gallery.length),
              style: { ...iconButton, position: "absolute", right: "0.5rem", color: "#fff", background: "rgba(0,0,0,0.55)", borderColor: "rgba(255,255,255,0.35)" },
              children: "\u203A"
            }
          )
        ] })
      ] }),
      (image.title || image.description) && /* @__PURE__ */ jsxs3("div", { children: [
        image.title && /* @__PURE__ */ jsx3("div", { style: { fontWeight: 600, color: "var(--foreground)" }, children: image.title }),
        image.description && /* @__PURE__ */ jsx3("div", { style: { fontSize: "0.85rem", color: "var(--muted-foreground)" }, children: image.description })
      ] }),
      /* @__PURE__ */ jsx3("div", { style: { display: "flex", gap: "0.5rem", overflowX: "auto", paddingBottom: "0.25rem" }, children: gallery.map((thumb, n) => /* @__PURE__ */ jsx3(
        "img",
        {
          src: thumb.url,
          alt: thumb.title,
          loading: "lazy",
          onClick: () => setViewer(n),
          style: {
            height: "3.5rem",
            flex: "0 0 auto",
            aspectRatio: "16 / 9",
            objectFit: "cover",
            borderRadius: "0.375rem",
            cursor: "pointer",
            outline: n === viewer ? "2px solid var(--foreground)" : "1px solid var(--border)"
          }
        },
        thumb.url
      )) })
    ] }) : /* @__PURE__ */ jsxs3(Fragment, { children: [
      /* @__PURE__ */ jsxs3("div", { style: { display: "flex", alignItems: "flex-start", gap: "0.75rem" }, children: [
        plugin.icon_url ? /* @__PURE__ */ jsx3("img", { src: plugin.icon_url, alt: "", style: { width: "4rem", height: "4rem", borderRadius: "0.75rem", flex: "0 0 auto" } }) : /* @__PURE__ */ jsx3("div", { style: { width: "4rem", height: "4rem", borderRadius: "0.75rem", border: "1px solid var(--border)", flex: "0 0 auto" } }),
        /* @__PURE__ */ jsxs3("div", { style: { minWidth: 0, flex: "1 1 auto" }, children: [
          /* @__PURE__ */ jsx3("h2", { style: { margin: 0, fontSize: "1.15rem", fontWeight: 700, color: "var(--foreground)", overflowWrap: "anywhere" }, children: plugin.title }),
          /* @__PURE__ */ jsxs3("p", { style: { margin: "0.125rem 0 0", fontSize: "0.8rem", color: "var(--muted-foreground)" }, children: [
            "by ",
            plugin.author
          ] })
        ] }),
        /* @__PURE__ */ jsx3("button", { type: "button", "aria-label": "Close", style: iconButton, onClick: onClose, children: "\xD7" })
      ] }),
      /* @__PURE__ */ jsx3("p", { style: { margin: 0, fontSize: "0.9rem", color: "var(--foreground)" }, children: plugin.description }),
      /* @__PURE__ */ jsxs3("div", { style: { display: "flex", flexWrap: "wrap", alignItems: "center", gap: "0.5rem 1rem", fontSize: "0.8rem", color: "var(--muted-foreground)" }, children: [
        /* @__PURE__ */ jsxs3("span", { children: [
          /* @__PURE__ */ jsx3("strong", { style: { color: "var(--foreground)" }, children: formatCount(d?.downloads ?? plugin.downloads) }),
          " downloads"
        ] }),
        /* @__PURE__ */ jsxs3("span", { children: [
          /* @__PURE__ */ jsx3("strong", { style: { color: "var(--foreground)" }, children: formatCount(d?.followers ?? plugin.follows) }),
          " followers"
        ] }),
        d?.updated && /* @__PURE__ */ jsxs3("span", { children: [
          "Updated ",
          date(d.updated)
        ] })
      ] }),
      /* @__PURE__ */ jsxs3("div", { style: { display: "flex", flexWrap: "wrap", gap: "0.5rem", alignItems: "center" }, children: [
        /* @__PURE__ */ jsx3(Button2, { disabled: !canInstall, onClick: () => onInstall(plugin), children: "Install" }),
        /* @__PURE__ */ jsx3("a", { href: `https://modrinth.com/plugin/${d?.slug ?? plugin.slug}`, target: "_blank", rel: "noreferrer noopener", style: outlined, children: "View on Modrinth \u2197" })
      ] }),
      /* @__PURE__ */ jsx3("div", { role: "tablist", style: { display: "flex", gap: "0.25rem", borderBottom: "1px solid var(--border)", overflowX: "auto" }, children: tabs.map((t) => /* @__PURE__ */ jsx3(
        "button",
        {
          type: "button",
          role: "tab",
          "aria-selected": tab === t.id,
          onClick: () => setTab(t.id),
          style: {
            background: "none",
            border: 0,
            borderBottom: tab === t.id ? "2px solid var(--foreground)" : "2px solid transparent",
            padding: "0.5rem 0.75rem",
            fontSize: "0.85rem",
            fontWeight: tab === t.id ? 600 : 400,
            color: tab === t.id ? "var(--foreground)" : "var(--muted-foreground)",
            cursor: "pointer",
            whiteSpace: "nowrap"
          },
          children: t.label
        },
        t.id
      )) }),
      details.isLoading && /* @__PURE__ */ jsx3(Spinner2, { centered: true }),
      details.isError && /* @__PURE__ */ jsx3(Alert2, { type: "danger", children: httpErrorToHuman2(details.error) }),
      d && tab === "description" && (d.body.trim() ? /* @__PURE__ */ jsx3(Markdown, { source: d.body }) : /* @__PURE__ */ jsx3("p", { style: { color: "var(--muted-foreground)", fontSize: "0.875rem" }, children: "This plugin has no long description." })),
      d && tab === "gallery" && /* @__PURE__ */ jsx3("div", { style: { display: "grid", gap: "0.75rem", gridTemplateColumns: "repeat(auto-fill, minmax(min(100%, 12rem), 1fr))" }, children: gallery.map((img, n) => /* @__PURE__ */ jsxs3(
        "button",
        {
          type: "button",
          onClick: () => setViewer(n),
          title: "Open image",
          style: { ...panel, padding: 0, overflow: "hidden", textAlign: "left", cursor: "zoom-in", background: "transparent" },
          children: [
            /* @__PURE__ */ jsx3("img", { src: img.url, alt: img.title, loading: "lazy", style: { display: "block", width: "100%", aspectRatio: "16 / 9", objectFit: "cover" } }),
            img.title && /* @__PURE__ */ jsx3("div", { style: { padding: "0.375rem 0.5rem", fontSize: "0.75rem", color: "var(--foreground)" }, children: img.title })
          ]
        },
        img.url
      )) }),
      d && tab === "details" && /* @__PURE__ */ jsxs3("div", { style: { display: "grid", gap: "1rem" }, children: [
        /* @__PURE__ */ jsx3("div", { style: { display: "grid", gap: "0.5rem", gridTemplateColumns: "repeat(auto-fit, minmax(8rem, 1fr))" }, children: [
          ["Downloads", formatCount(d.downloads)],
          ["Followers", formatCount(d.followers)],
          ["Updated", date(d.updated)],
          ["Published", date(d.published)],
          ["License", d.license || "-"]
        ].map(([label, value]) => /* @__PURE__ */ jsxs3("div", { style: panel, children: [
          /* @__PURE__ */ jsx3("div", { style: { fontSize: "0.7rem", color: "var(--muted-foreground)" }, children: label }),
          /* @__PURE__ */ jsx3("div", { style: { fontSize: "0.9rem", fontWeight: 600, color: "var(--foreground)", overflowWrap: "anywhere" }, children: value })
        ] }, label)) }),
        /* @__PURE__ */ jsx3(Chips, { label: "Categories", items: d.categories }),
        /* @__PURE__ */ jsx3(Chips, { label: "Loaders", items: d.loaders }),
        /* @__PURE__ */ jsx3(Chips, { label: "Minecraft versions", items: d.game_versions }),
        Object.keys(d.links).length > 0 && /* @__PURE__ */ jsxs3("div", { children: [
          /* @__PURE__ */ jsx3(Label2, { children: "Links" }),
          /* @__PURE__ */ jsx3("div", { style: { display: "flex", flexWrap: "wrap", gap: "0.5rem" }, children: Object.entries(d.links).map(([key, url]) => /* @__PURE__ */ jsxs3("a", { href: url, target: "_blank", rel: "noreferrer noopener", style: outlined, children: [
            LINK_LABELS[key] ?? key,
            " \u2197"
          ] }, key)) })
        ] })
      ] })
    ] }) }) })
  );
}

// src/client/screens/ServerScreen.tsx
import { jsx as jsx4, jsxs as jsxs4 } from "react/jsx-runtime";
var ANY = "any";
var SORTS = [
  { value: "relevance", label: "Relevance" },
  { value: "downloads", label: "Downloads" },
  { value: "follows", label: "Follows" },
  { value: "newest", label: "Newest" },
  { value: "updated", label: "Recently updated" }
];
function ServerScreenInner() {
  const server = useCurrentServerRequired();
  const uuid = server.attributes.uuid;
  const canInstall = useServerPermission(["file.create", "file.update"], false);
  const [text, setText] = useState3("");
  const [query, setQuery] = useState3("");
  const [loader, setLoader] = useState3(detectLoader(server.attributes.egg_tags));
  const [gameVersion, setGameVersion] = useState3("");
  const [category, setCategory] = useState3("");
  const [sort, setSort] = useState3("relevance");
  const [page, setPage] = useState3(1);
  const [installing, setInstalling] = useState3(null);
  const [reading, setReading] = useState3(null);
  useEffect3(() => {
    const timer = setTimeout(() => {
      setQuery(text.trim());
      setPage(1);
    }, 350);
    return () => clearTimeout(timer);
  }, [text]);
  const startup = useServerStartup(uuid, (data) => detectGameVersion(data.data.map((v) => v.attributes)));
  const versionPreselected = useRef(false);
  useEffect3(() => {
    if (!versionPreselected.current && startup.data) {
      versionPreselected.current = true;
      setGameVersion(startup.data);
    }
  }, [startup.data]);
  const meta = useQuery3({ queryKey: ["drift-plugins", "meta", uuid], queryFn: () => getMeta(uuid), staleTime: 60 * 60 * 1e3 });
  const layoutQuery = useQuery3({ queryKey: ["drift-plugins", "layout", uuid], queryFn: () => getLayout(uuid), staleTime: 5 * 60 * 1e3 });
  const layout = layoutQuery.data ?? DEFAULT_LAYOUT;
  const results = useQuery3({
    queryKey: ["drift-plugins", "search", uuid, query, loader, gameVersion, category, sort, page],
    queryFn: () => searchPlugins(uuid, { query, loader, gameVersion, category, sort, page }),
    placeholderData: keepPreviousData,
    enabled: canInstall
  });
  const change = (set) => (value) => {
    set(value);
    setPage(1);
  };
  const orAny = (value) => value === ANY ? "" : String(value);
  return /* @__PURE__ */ jsxs4(ServerContentBlock, { title: "Drift Plugins", children: [
    /* @__PURE__ */ jsxs4("div", { className: "vz:grid vz:gap-4", children: [
      /* @__PURE__ */ jsx4(Header, { subtitle: "Install Modrinth plugins", link: { label: "Plugin manager", href: siblingHref("manager") } }),
      !canInstall && /* @__PURE__ */ jsx4(Alert3, { type: "warning", children: "You need the file create and file update permissions to install plugins on this server." }),
      /* @__PURE__ */ jsx4(TitledGreyBox, { title: "Find plugins on Modrinth", children: /* @__PURE__ */ jsxs4("div", { className: "vz:grid vz:gap-3 vz:sm:grid-cols-2 vz:lg:grid-cols-5", children: [
        /* @__PURE__ */ jsxs4("div", { className: "vz:sm:col-span-2 vz:lg:col-span-2", children: [
          /* @__PURE__ */ jsx4(Label3, { children: "Search" }),
          /* @__PURE__ */ jsx4(Input, { value: text, onChange: (e) => setText(e.target.value), placeholder: "e.g. EssentialsX, LuckPerms\u2026" })
        ] }),
        /* @__PURE__ */ jsxs4("div", { children: [
          /* @__PURE__ */ jsx4(Label3, { children: "Loader" }),
          /* @__PURE__ */ jsx4(
            Select2,
            {
              value: loader || ANY,
              onChange: (v) => change(setLoader)(orAny(v)),
              options: [{ value: ANY, label: "Any plugin loader" }, ...(meta.data?.loaders ?? []).map((l) => ({ value: l.id, label: l.name }))]
            }
          )
        ] }),
        /* @__PURE__ */ jsxs4("div", { children: [
          /* @__PURE__ */ jsx4(Label3, { children: "Minecraft version" }),
          /* @__PURE__ */ jsx4(
            Select2,
            {
              value: gameVersion || ANY,
              onChange: (v) => change(setGameVersion)(orAny(v)),
              searchPlaceholder: "Search versions\u2026",
              options: [{ value: ANY, label: "Any version" }, ...(meta.data?.game_versions ?? []).map((v) => ({ value: v, label: v }))]
            }
          )
        ] }),
        /* @__PURE__ */ jsxs4("div", { children: [
          /* @__PURE__ */ jsx4(Label3, { children: "Category" }),
          /* @__PURE__ */ jsx4(
            Select2,
            {
              value: category || ANY,
              onChange: (v) => change(setCategory)(orAny(v)),
              options: [{ value: ANY, label: "All categories" }, ...(meta.data?.categories ?? []).map((c) => ({ value: c, label: c.replace(/-/g, " ") }))]
            }
          )
        ] }),
        /* @__PURE__ */ jsxs4("div", { children: [
          /* @__PURE__ */ jsx4(Label3, { children: "Sort by" }),
          /* @__PURE__ */ jsx4(Select2, { value: sort, onChange: (v) => change(setSort)(String(v)), options: SORTS })
        ] })
      ] }) }),
      results.isError && /* @__PURE__ */ jsx4(Alert3, { type: "danger", children: httpErrorToHuman3(results.error) }),
      results.isLoading && canInstall && /* @__PURE__ */ jsx4(Spinner3, { centered: true }),
      results.data && results.data.hits.length === 0 && /* @__PURE__ */ jsx4(Alert3, { type: "info", children: "No plugins match these filters." }),
      results.data && results.data.hits.length > 0 && /* @__PURE__ */ jsx4(
        Pagination,
        {
          data: {
            data: results.data.hits,
            meta: {
              pagination: {
                total: results.data.total,
                count: results.data.hits.length,
                per_page: results.data.per_page,
                current_page: results.data.page,
                total_pages: results.data.total_pages
              }
            }
          },
          onPageSelect: setPage,
          children: ({ items }) => /* @__PURE__ */ jsx4("ul", { className: gridClass(layout), children: items.map((plugin) => /* @__PURE__ */ jsx4(PluginCard, { plugin, canInstall, onInstall: setInstalling, onReadMore: setReading, settings: layout }, plugin.project_id)) })
        }
      )
    ] }),
    /* @__PURE__ */ jsx4(
      PluginDetailsDialog,
      {
        plugin: reading,
        serverUuid: uuid,
        canInstall,
        onClose: () => setReading(null),
        onInstall: (plugin) => {
          setReading(null);
          setInstalling(plugin);
        }
      }
    ),
    /* @__PURE__ */ jsx4(InstallDialog, { plugin: installing, serverUuid: uuid, loader, gameVersion, onClose: () => setInstalling(null) })
  ] });
}
function ServerScreen() {
  const server = useCurrentServerRequired();
  const uuid = server.attributes.uuid;
  const availability = useQuery3({ queryKey: ["drift-plugins", "availability", uuid], queryFn: () => getAvailability(uuid), staleTime: 60 * 1e3 });
  if (availability.isLoading) {
    return /* @__PURE__ */ jsx4(ServerContentBlock, { title: "Drift Plugins", children: /* @__PURE__ */ jsx4(Spinner3, { centered: true }) });
  }
  if (availability.isError) {
    return /* @__PURE__ */ jsx4(ServerContentBlock, { title: "Drift Plugins", children: /* @__PURE__ */ jsx4(Alert3, { type: "danger", children: httpErrorToHuman3(availability.error) }) });
  }
  if (!availability.data?.enabled) {
    return /* @__PURE__ */ jsx4(ServerContentBlock, { title: "Drift Plugins", children: /* @__PURE__ */ jsx4(Alert3, { type: "warning", children: "Drift Plugins isn't available for this server's egg." }) });
  }
  return /* @__PURE__ */ jsx4(ServerScreenInner, {});
}
export {
  ServerScreen as default
};
