import {
  setConfig
} from "./chunk.chunk.4YEQZHHQ.js";

// src/client/index.tsx
import { definePterodactylExtension } from "@pterodactyl/sdk";
var index_default = definePterodactylExtension({
  setup({ config, screens }) {
    setConfig(config);
    screens.register("config", () => import("./chunk.ConfigScreen.JUBXROUJ.js"));
    screens.register("main", () => import("./chunk.ServerScreen.YO7N6EOT.js"));
    screens.register("manager", () => import("./chunk.ManagerScreen.JHHAYXVT.js"));
  }
});
export {
  index_default as default
};
