<?php

namespace DriftPlugins\Settings;

use Pterodactyl\Services\Extensions\ExtensionSettings;

/**
 * Thin wrapper over the extension's key-value store. The keys match the definitions registered
 * in the provider, so /panel/drift-plugins and Admin -> Extensions always edit the same values.
 */
final class PluginSettings
{
    public const DEFAULTS = [
        'contact' => '',
        'cache_minutes' => 10,
        'install_directory' => '/plugins',
        'layout' => 'card',
        'columns' => 2,
        'show_background' => true,
        'show_overlay' => true,
        'overlay_opacity' => 75,
        'blur_enabled' => false,
        'blur_amount' => 8,
        'require_plugin_egg' => true,
        'egg_overrides' => '{}',
    ];

    public function __construct(private readonly ExtensionSettings $store) {}

    private function bool(string $key): bool
    {
        return filter_var($this->store->get($key, self::DEFAULTS[$key]), FILTER_VALIDATE_BOOLEAN);
    }

    private function int(string $key, int $min, int $max): int
    {
        return min($max, max($min, (int) $this->store->get($key, self::DEFAULTS[$key])));
    }

    /** What every server page needs to draw the plugin list. @return array<string, mixed> */
    public function layout(): array
    {
        $layout = (string) $this->store->get('layout', self::DEFAULTS['layout']);

        return [
            'layout' => $layout === 'row' ? 'row' : 'card',
            'columns' => in_array((int) $this->store->get('columns', self::DEFAULTS['columns']), [2, 3, 4], true) ? (int) $this->store->get('columns', self::DEFAULTS['columns']) : 2,
            'show_background' => $this->bool('show_background'),
            'show_overlay' => $this->bool('show_overlay'),
            'overlay_opacity' => $this->int('overlay_opacity', 0, 100),
            'blur_enabled' => $this->bool('blur_enabled'),
            'blur_amount' => $this->int('blur_amount', 0, 40),
        ];
    }

    /** Everything the admin page edits. @return array<string, mixed> */
    public function all(): array
    {
        return [
            ...$this->layout(),
            'contact' => (string) $this->store->get('contact', ''),
            'cache_minutes' => $this->int('cache_minutes', 1, 1440),
            'install_directory' => (string) $this->store->get('install_directory', self::DEFAULTS['install_directory']),
            'require_plugin_egg' => $this->bool('require_plugin_egg'),
            'egg_overrides' => self::overrides($this->store->get('egg_overrides', self::DEFAULTS['egg_overrides'])),
        ];
    }

    /**
     * Keeps only "egg id => show|hide" pairs. Accepts an array or the stored JSON string.
     *
     * @return array<string, string>
     */
    public static function overrides(mixed $value): array
    {
        if (is_string($value)) {
            $value = json_decode($value, true);
        }

        $clean = [];
        foreach (is_array($value) ? $value : [] as $eggId => $choice) {
            if (preg_match('/^\d{1,10}$/', (string) $eggId) === 1 && ($choice === 'show' || $choice === 'hide')) {
                $clean[(string) $eggId] = $choice;
            }
        }

        return $clean;
    }

    /** @param array<string, mixed> $values */
    public function update(array $values): void
    {
        // The per-egg choices are stored as one JSON string, so the stored value always has a plain type.
        if (array_key_exists('egg_overrides', $values)) {
            $values['egg_overrides'] = json_encode((object) self::overrides($values['egg_overrides']));
        }

        $this->store->setMany(array_intersect_key($values, self::DEFAULTS));
    }
}
