<?php

use DriftPlugins\Http\Controllers\BrowseController;
use Illuminate\Support\Facades\Route;

// Final URLs: /api/client/servers/{server}/extensions/vizion/drift-plugins/...
// Whether Drift Plugins is shown for this server's egg.
Route::get('/availability', [BrowseController::class, 'availability'])->name('availability');
Route::get('/meta', [BrowseController::class, 'meta'])->name('meta');
Route::get('/search', [BrowseController::class, 'search'])->name('search');
Route::get('/projects/{project}', [BrowseController::class, 'details'])->where('project', '[A-Za-z0-9_.-]+')->name('details');
Route::get('/projects/{project}/versions', [BrowseController::class, 'versions'])->name('versions');
Route::get('/layout', [\DriftPlugins\Http\Controllers\LayoutController::class, 'show'])->name('layout');
