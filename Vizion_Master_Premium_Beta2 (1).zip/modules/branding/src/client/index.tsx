import { definePterodactylExtension } from '@pterodactyl/sdk';
import { applyFavicon, setConfig } from './config.ts';
import { mountLogo } from './logo.ts';

export default definePterodactylExtension({
    setup({ config }) {
        // Settings (logo, favicon, placement, ...) are edited in Vizion's module panel.
        setConfig(config);

        // The server-rendered head already has the favicon; this also covers a change made in this tab
        // without reloading, and the head tag cache.
        applyFavicon();
        mountLogo();
    },
});
