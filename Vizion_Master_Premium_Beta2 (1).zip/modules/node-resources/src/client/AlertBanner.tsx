import { useQuery } from '@tanstack/react-query';
import { PanelLink } from '@pterodactyl/sdk';
import { getAlerts, keys } from './api';

/** Shown above the admin overview and node list when a node needs attention. */
export default function AlertBanner() {
    const query = useQuery({ queryKey: keys.alerts, queryFn: getAlerts, refetchInterval: 120_000, retry: false });
    const warnings = query.data?.warnings ?? [];
    if (warnings.length === 0) return null;

    return (
        <section aria-label={'Node resource warnings'} className={'vz:mb-4 vz:flex vz:flex-col vz:gap-2'}>
            {warnings.map((warning) => (
                <div
                    key={`${warning.node.id}-${warning.id}`}
                    role={'alert'}
                    className={`vz:flex vz:flex-wrap vz:items-center vz:justify-between vz:gap-2 vz:rounded-sm vz:border vz:px-3 vz:py-2 vz:text-sm ${
                        warning.level === 'danger'
                            ? 'vz:border-destructive/40 vz:bg-destructive/10 vz:text-destructive'
                            : 'vz:border-warning/40 vz:bg-warning/10 vz:text-warning'
                    }`}
                >
                    <span>
                        <strong>{warning.node.name}:</strong> {warning.text}
                    </span>
                    <PanelLink
                        destination={{ extension: 'node-resources', screen: 'node', params: { id: String(warning.node.id) } }}
                        className={'vz:underline'}
                    >
                        Open
                    </PanelLink>
                </div>
            ))}
        </section>
    );
}
