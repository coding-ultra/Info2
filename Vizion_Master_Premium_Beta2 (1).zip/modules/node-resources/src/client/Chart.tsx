import { useState } from 'react';
import { axisTime } from './format';
import { buildPaths, nearestIndex, type Point } from './chart';

export interface Series {
    id: string;
    label: string;
    /** A panel colour token, e.g. `--chart-1`. */
    token: string;
    points: Point[];
    area?: boolean;
}

interface Props {
    title: string;
    series: Series[];
    /** Start and end of the time axis, in seconds. */
    from: number;
    to: number;
    /** The top of the vertical axis. */
    max: number;
    format: (value: number) => string;
    /** A line across the chart, such as the size of the disk. */
    limit?: { value: number; label: string } | null;
    /** Seconds between points; a hole wider than twice this breaks the line. */
    step: number;
    note?: string;
    empty?: string;
}

const WIDTH = 600;
const HEIGHT = 120;

/** A small line/area chart drawn in SVG with the panel's colours. */
export default function Chart({ title, series, from, to, max, format, limit, step, note, empty = 'No data in this range yet.' }: Props) {
    const [hover, setHover] = useState<number | null>(null);
    const hasData = series.some((item) => item.points.some((point) => point.v !== null));
    const drawn = series.map((item) => ({ item, paths: buildPaths(item.points, from, to, max, WIDTH, HEIGHT, Math.max(step * 2, 600)) }));
    const primary = series[0];
    const latest = primary ? [...primary.points].reverse().find((point) => point.v !== null) : undefined;

    const at = hover === null ? null : Math.min(1, Math.max(0, hover));
    const nearest = (points: Point[]) => (at === null ? -1 : nearestIndex(points, at, from, to));
    const hoverTime = at === null ? null : from + at * (to - from);

    return (
        <div className={'vz:flex vz:flex-col vz:gap-1'}>
            <div className={'vz:flex vz:flex-wrap vz:items-baseline vz:justify-between vz:gap-2'}>
                <span className={'vz:text-sm vz:font-medium vz:text-foreground'}>{title}</span>
                <span className={'vz:flex vz:flex-wrap vz:items-center vz:gap-3 vz:text-xs vz:text-muted-foreground'}>
                    {series.map((item) => (
                        <span key={item.id} className={'vz:inline-flex vz:items-center vz:gap-1'}>
                            <span
                                aria-hidden
                                className={'vz:inline-block vz:h-2 vz:w-2 vz:rounded-full'}
                                style={{ background: `var(${item.token})` }}
                            />
                            {item.label}
                        </span>
                    ))}
                    {latest && latest.v !== null && <span className={'vz:text-foreground'}>{format(latest.v)}</span>}
                </span>
            </div>

            {!hasData ? (
                <p
                    className={
                        'vz:flex vz:h-28 vz:items-center vz:justify-center vz:rounded-sm vz:bg-muted/40 vz:text-xs vz:text-muted-foreground'
                    }
                >
                    {empty}
                </p>
            ) : (
                <div className={'vz:flex vz:gap-2'}>
                    <div
                        className={
                            'vz:flex vz:w-14 vz:shrink-0 vz:flex-col vz:justify-between vz:py-0.5 vz:text-right vz:text-[10px] vz:text-muted-foreground'
                        }
                    >
                        <span>{format(max)}</span>
                        <span>{format(0)}</span>
                    </div>
                    <div className={'vz:flex vz:min-w-0 vz:flex-1 vz:flex-col'}>
                        <div
                            className={'vz:relative'}
                            onMouseMove={(event) => {
                                const box = event.currentTarget.getBoundingClientRect();
                                setHover(box.width > 0 ? (event.clientX - box.left) / box.width : null);
                            }}
                            onMouseLeave={() => setHover(null)}
                        >
                            <svg
                                role={'img'}
                                aria-label={`${title}, ${series.map((item) => item.label).join(' and ')}`}
                                viewBox={`0 0 ${WIDTH} ${HEIGHT}`}
                                preserveAspectRatio={'none'}
                                className={'vz:block vz:h-28 vz:w-full vz:overflow-visible'}
                            >
                                {[0.25, 0.5, 0.75, 1].map((fraction) => (
                                    <line
                                        key={fraction}
                                        x1={0}
                                        x2={WIDTH}
                                        y1={HEIGHT * fraction}
                                        y2={HEIGHT * fraction}
                                        style={{ stroke: 'var(--border)', vectorEffect: 'non-scaling-stroke' }}
                                        strokeWidth={1}
                                        strokeDasharray={fraction === 1 ? undefined : '2 4'}
                                    />
                                ))}
                                {limit && limit.value > 0 && limit.value <= max && (
                                    <line
                                        x1={0}
                                        x2={WIDTH}
                                        y1={HEIGHT - (limit.value / max) * HEIGHT}
                                        y2={HEIGHT - (limit.value / max) * HEIGHT}
                                        style={{ stroke: 'var(--destructive)', vectorEffect: 'non-scaling-stroke' }}
                                        strokeWidth={1}
                                        strokeDasharray={'6 4'}
                                    />
                                )}
                                {drawn.map(({ item, paths }) => (
                                    <g key={item.id}>
                                        {item.area && paths.area && (
                                            <path d={paths.area} style={{ fill: `var(${item.token})`, opacity: 0.15 }} />
                                        )}
                                        {paths.line && (
                                            <path
                                                d={paths.line}
                                                fill={'none'}
                                                strokeWidth={2}
                                                strokeLinejoin={'round'}
                                                style={{ stroke: `var(${item.token})`, vectorEffect: 'non-scaling-stroke' }}
                                            />
                                        )}
                                    </g>
                                ))}
                            </svg>
                            {at !== null && hoverTime !== null && (
                                <>
                                    <div
                                        aria-hidden
                                        className={'vz:pointer-events-none vz:absolute vz:inset-y-0 vz:w-px vz:bg-muted-foreground/60'}
                                        style={{ left: `${at * 100}%` }}
                                    />
                                    <div
                                        role={'tooltip'}
                                        className={
                                            'vz:pointer-events-none vz:absolute vz:top-0 vz:z-10 vz:rounded-sm vz:border vz:border-border vz:bg-popover vz:px-2 vz:py-1 vz:text-xs vz:text-foreground vz:shadow-md'
                                        }
                                        style={at > 0.6 ? { right: `${(1 - at) * 100}%` } : { left: `${at * 100}%` }}
                                    >
                                        <div className={'vz:text-muted-foreground'}>
                                            {new Date(hoverTime * 1000).toLocaleString([], { dateStyle: 'short', timeStyle: 'short' })}
                                        </div>
                                        {series.map((item) => {
                                            const point = item.points[nearest(item.points)];
                                            return (
                                                <div key={item.id} className={'vz:flex vz:justify-between vz:gap-3'}>
                                                    <span style={{ color: `var(${item.token})` }}>{item.label}</span>
                                                    <span>{point && point.v !== null ? format(point.v) : '-'}</span>
                                                </div>
                                            );
                                        })}
                                    </div>
                                </>
                            )}
                        </div>
                        <div className={'vz:flex vz:justify-between vz:text-[10px] vz:text-muted-foreground'}>
                            <span>{axisTime(from, to - from)}</span>
                            <span>{axisTime(to, to - from)}</span>
                        </div>
                    </div>
                </div>
            )}
            {note && <p className={'vz:text-xs vz:text-muted-foreground'}>{note}</p>}
        </div>
    );
}
