import type { ReactNode } from 'react';
import { levelFor, percentOf } from './format';
import type { ProbeState } from './api';

const BAR: Record<ReturnType<typeof levelFor>, string> = {
    success: 'vz:bg-success',
    warning: 'vz:bg-warning',
    destructive: 'vz:bg-destructive',
    muted: 'vz:bg-muted-foreground/40',
};

/** A thin bar. `part` of `whole`; coloured by the panel's usage thresholds. */
export function Meter({ label, part, whole, text }: { label: string; part: number | null; whole: number | null; text: ReactNode }) {
    const percent = percentOf(part, whole);
    const level = levelFor(percent);

    return (
        <div className={'vz:flex vz:flex-col vz:gap-1'}>
            <div className={'vz:flex vz:justify-between vz:gap-2 vz:text-xs'}>
                <span className={'vz:text-muted-foreground'}>{label}</span>
                <span className={'vz:text-foreground'}>{text}</span>
            </div>
            <div
                role={'progressbar'}
                aria-label={label}
                aria-valuemin={0}
                aria-valuemax={100}
                aria-valuenow={percent === null ? undefined : Math.round(Math.min(100, percent))}
                className={'vz:h-2 vz:w-full vz:overflow-hidden vz:rounded-full vz:bg-muted'}
            >
                <div className={`vz:h-full vz:rounded-full ${BAR[level]}`} style={{ width: `${Math.min(100, percent ?? 0)}%` }} />
            </div>
        </div>
    );
}

/** A number with a caption above and a note below. */
export function Stat({
    label,
    value,
    note,
    tone,
}: {
    label: string;
    value: ReactNode;
    note?: ReactNode;
    tone?: 'warning' | 'destructive';
}) {
    return (
        <div className={'vz:flex vz:min-w-0 vz:flex-col'}>
            <span className={'vz:text-xs vz:text-muted-foreground'}>{label}</span>
            <span
                className={`vz:text-lg vz:font-semibold ${tone === 'destructive' ? 'vz:text-destructive' : tone === 'warning' ? 'vz:text-warning' : 'vz:text-foreground'}`}
            >
                {value}
            </span>
            {note && <span className={'vz:text-xs vz:text-muted-foreground'}>{note}</span>}
        </div>
    );
}

/** What the probe is doing, in a few words. */
export function probeText(state: ProbeState): string {
    switch (state) {
        case 'none':
            return 'No probe';
        case 'installing':
            return 'Probe installing';
        case 'failed':
            return 'Probe install failed';
        case 'suspended':
            return 'Probe suspended';
        case 'waiting':
            return 'Probe starting';
        case 'starting':
            return 'Probe starting';
        case 'ok':
            return 'Probe running';
        case 'stale':
            return 'Probe quiet';
        case 'offline':
            return 'Probe stopped';
        case 'unreachable':
            return 'Node not reachable';
    }
}
