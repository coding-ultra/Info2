<?php

declare(strict_types=1);

namespace ServerExpiry\Actions;

use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Log;
use Pterodactyl\Contracts\Servers\CreatesServers;
use Pterodactyl\Contracts\Servers\TogglesServerSuspension;
use Pterodactyl\Models\Objects\DeploymentObject;
use Pterodactyl\Models\Server;
use ServerExpiry\Models\ServerExpiry;
use Throwable;

final readonly class CreatesServersDecorator implements CreatesServers
{
    public function __construct(private CreatesServers $inner)
    {
    }

    public function create(array $data, ?DeploymentObject $deployment = null): Server
    {
        $server = $this->inner->create($data, $deployment);

        // Check if expiry information was provided via data payload or HTTP request
        $expiresAt = $data['expires_at']
            ?? $data['server_expire_at']
            ?? $data['expiration_date']
            ?? $data['expiry_date']
            ?? request()->input('expires_at')
            ?? request()->input('server_expire_at')
            ?? request()->input('expiration_date')
            ?? request()->input('expiry_date')
            ?? request()->input('server_expiry.expires_at')
            ?? request()->input('extensions.vizion.expires_at');

        $action = $data['action']
            ?? $data['expiry_action']
            ?? request()->input('action')
            ?? request()->input('expiry_action')
            ?? request()->input('server_expiry.action')
            ?? request()->input('extensions.vizion.action')
            ?? 'suspend';

        if (!in_array($action, ['suspend', 'delete'], true)) {
            $action = 'suspend';
        }

        if (!empty($expiresAt)) {
            try {
                ServerExpiry::query()->updateOrCreate(
                    ['server_id' => $server->id],
                    [
                        'expires_at' => Carbon::parse($expiresAt),
                        'action'     => $action,
                    ]
                );

                $this->unsuspendIfSuspended($server, (string) $expiresAt);
            } catch (Throwable $e) {
                Log::error("[ServerExpiry] Failed setting expiry on server creation: " . $e->getMessage());
            }
        }

        return $server;
    }

    private function unsuspendIfSuspended(Server $server, ?string $expiresAt): void
    {
        if (empty($expiresAt)) {
            return;
        }

        try {
            $parsed = Carbon::parse($expiresAt);
            if ($parsed->isFuture() && $server->isSuspended()) {
                /** @var TogglesServerSuspension $suspension */
                $suspension = app(TogglesServerSuspension::class);
                $suspension->toggle($server, TogglesServerSuspension::ACTION_UNSUSPEND);
                $server->refresh();

                if (class_exists(\Pterodactyl\Facades\Activity::class)) {
                    \Pterodactyl\Facades\Activity::event('admin:server.unsuspend')
                        ->subject($server)
                        ->property('name', $server->name)
                        ->log();
                }
            }
        } catch (Throwable $e) {
            Log::error("[ServerExpiry] Failed to auto-unsuspend server {$server->id}: " . $e->getMessage(), [
                'exception' => $e,
            ]);
        }
    }
}
