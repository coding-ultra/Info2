<?php

declare(strict_types=1);

// No client API routes needed for this extension.
// Expiry CRUD is exposed through the Application API (routes/application.php).
