<?php

declare(strict_types=1);

use Illuminate\Support\Facades\Route;
use ServerExpiry\Http\Controllers\ServerExpiryController;

/*
|--------------------------------------------------------------------------
| Server Expiry — Server Scoped API Routes
|--------------------------------------------------------------------------
| Mounted at: /api/client/servers/{server}/extensions/vizion/server-expiry
|
| GET  /api/client/servers/{server}/extensions/vizion/server-expiry
*/

Route::get('/', [ServerExpiryController::class, 'show']);
