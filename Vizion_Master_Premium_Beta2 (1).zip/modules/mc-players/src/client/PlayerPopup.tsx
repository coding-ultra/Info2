import { useEffect, useRef } from 'react';
import { createPortal } from 'react-dom';
import { PanelLink } from '@pterodactyl/sdk';
import { Maximize2, X } from 'lucide-react';
import PlayerProfile from './PlayerProfile';

/** The player profile over the console page. Escape, the backdrop or the close button close it. */
export default function PlayerPopup({ server, name, onClose }: { server: string; name: string; onClose: () => void }) {
    const panel = useRef<HTMLDivElement>(null);

    useEffect(() => {
        const onKey = (event: KeyboardEvent) => {
            // A confirm dialog opened from inside the popup handles its own Escape.
            if (event.key === 'Escape' && !document.querySelector('[role="alertdialog"], [role="dialog"]:not([data-mcp-popup])')) {
                onClose();
            }
        };
        document.addEventListener('keydown', onKey);
        const overflow = document.body.style.overflow;
        document.body.style.overflow = 'hidden';
        panel.current?.focus();

        return () => {
            document.removeEventListener('keydown', onKey);
            document.body.style.overflow = overflow;
        };
    }, [onClose]);

    return createPortal(
        <div
            className={'vz:fixed vz:inset-0 vz:z-50 vz:flex vz:items-center vz:justify-center vz:bg-black/60 vz:p-2 vz:sm:p-6'}
            onMouseDown={(event) => {
                if (event.target === event.currentTarget) onClose();
            }}
        >
            <div
                ref={panel}
                role={'dialog'}
                aria-modal
                aria-label={`Player ${name}`}
                data-mcp-popup
                tabIndex={-1}
                className={
                    'vz:flex vz:max-h-full vz:w-full vz:max-w-3xl vz:flex-col vz:overflow-hidden vz:rounded-lg vz:border vz:border-border vz:bg-background vz:shadow-2xl vz:outline-none'
                }
            >
                <div className={'vz:flex vz:items-center vz:justify-end vz:gap-1 vz:border-b vz:border-border vz:px-3 vz:py-2'}>
                    <PanelLink
                        destination={{ extension: 'mc-players', screen: 'player', params: { id: server, player: name } }}
                        className={
                            'vz:flex vz:items-center vz:gap-1 vz:rounded vz:px-2 vz:py-1 vz:text-sm vz:text-muted-foreground vz:hover:bg-muted vz:hover:text-foreground'
                        }
                        onClick={onClose}
                    >
                        <Maximize2 className={'vz:size-4'} aria-hidden />
                        Full page
                    </PanelLink>
                    <button
                        type={'button'}
                        aria-label={'Close'}
                        className={'vz:rounded vz:p-1 vz:text-muted-foreground vz:hover:bg-muted vz:hover:text-foreground'}
                        onClick={onClose}
                    >
                        <X className={'vz:size-5'} aria-hidden />
                    </button>
                </div>
                <div className={'vz:min-h-0 vz:flex-1 vz:overflow-y-auto vz:p-4 vz:sm:p-5'}>
                    <PlayerProfile server={server} name={name} />
                </div>
            </div>
        </div>,
        document.body,
    );
}
