import { Alert, PanelLink, ServerContentBlock, useCurrentServerRequired, type ScreenComponentProps } from '@pterodactyl/sdk';
import { ArrowLeft } from 'lucide-react';
import PlayerProfile from '../PlayerProfile';
import { isValidName } from '../console';

/** /server/<id>/player/<name>: the full player page. */
export default function PlayerScreen({ data }: ScreenComponentProps) {
    const server = useCurrentServerRequired();
    const name = decodeURIComponent(data.params.player ?? '');

    return (
        <ServerContentBlock title={name ? `${name} · Players` : 'Player'}>
            <div className={'vz:mx-auto vz:flex vz:max-w-4xl vz:flex-col vz:gap-4'}>
                <PanelLink
                    destination={{ to: '/server/$id', params: { id: server.attributes.identifier } }}
                    className={
                        'vz:flex vz:w-fit vz:items-center vz:gap-1 vz:text-sm vz:text-muted-foreground vz:hover:text-foreground'
                    }
                >
                    <ArrowLeft className={'vz:size-4'} aria-hidden />
                    Console
                </PanelLink>
                {isValidName(name) ? (
                    <div className={'vz:rounded-lg vz:border vz:border-border vz:bg-background vz:p-4 vz:sm:p-6'}>
                        <PlayerProfile server={server.attributes.identifier} name={name} />
                    </div>
                ) : (
                    <Alert type={'danger'}>That is not a valid player name.</Alert>
                )}
            </div>
        </ServerContentBlock>
    );
}
