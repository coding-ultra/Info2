<?php

use DriftProperties\Http\Controllers\AdminSettingsController;
use Illuminate\Support\Facades\Route;

// Final URLs: /api/admin/extensions/vizion/drift-properties/... (root administrators only)
Route::get('/display', [AdminSettingsController::class, 'show'])->name('display.show');
Route::put('/display', [AdminSettingsController::class, 'update'])->name('display.update');
