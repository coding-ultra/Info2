<?php

namespace DriftProperties;

use DriftProperties\Settings\DisplaySettings;
use Vizion\Support\ModuleProvider;
use Pterodactyl\Services\Extensions\ExtensionSettingDefinition;
use Pterodactyl\Services\Extensions\ExtensionSettingsDefinition;

class DriftPropertiesProvider extends ModuleProvider
{
    public function register(): void
    {
        // No container bindings needed.
    }

    public function boot(): void
    {
        // The Drift Properties admin page (/panel/drift-properties) reads and writes the settings below through this wrapper.
        $this->app->instance(DisplaySettings::class, new DisplaySettings($this->settings()));

        // routes/admin.php -> /api/admin/extensions/vizion/drift-properties
        // There are no server routes: the server page reads and writes server.properties through the Panel's own file API.
        $this->registerApiRoutes();

        // Frontend settings are readable by every signed-in user, so nothing secret goes here.
        // normalizeUsing keeps the stored type correct, because frontendType() is checked before exposure.
        $this->registerSettings(new ExtensionSettingsDefinition($this->settings(), [
            \Vizion\Support\ScopedDefinition::make('drift-properties', 'enabled', 'enabled', true, ['boolean'])
                ->label('Enable Drift Properties')
                ->help('Turn the Properties page on or off for every server. Off hides the page; nothing else is changed.')
                ->field('toggle')
                ->normalizeUsing(fn ($value) => filter_var($value, FILTER_VALIDATE_BOOLEAN))
                ->frontend()
                ->frontendType('boolean'),

            \Vizion\Support\ScopedDefinition::make('drift-properties', 'properties_file', 'properties_file', '/server.properties', ['required', 'string', 'max:255', 'regex:#^/[A-Za-z0-9._/-]*[A-Za-z0-9._-]$#', 'not_regex:#(^|/)\.\.(/|$)#'])
                ->label('File location')
                ->help('Path of server.properties, relative to the server root.')
                ->field('text')
                ->frontend()
                ->frontendType('string'),

            \Vizion\Support\ScopedDefinition::make('drift-properties', 'show_descriptions', 'show_descriptions', true, ['boolean'])
                ->label('Show descriptions')
                ->help('Show a short explanation under each known property.')
                ->field('toggle')
                ->normalizeUsing(fn ($value) => filter_var($value, FILTER_VALIDATE_BOOLEAN))
                ->frontend()
                ->frontendType('boolean'),

            \Vizion\Support\ScopedDefinition::make('drift-properties', 'show_custom', 'show_custom', true, ['boolean'])
                ->label('Show other properties')
                ->help('List properties that are in the file but are not in the built-in list (shown under Others), so they can be edited too.')
                ->field('toggle')
                ->normalizeUsing(fn ($value) => filter_var($value, FILTER_VALIDATE_BOOLEAN))
                ->frontend()
                ->frontendType('boolean'),

            \Vizion\Support\ScopedDefinition::make('drift-properties', 'minimal_cards', 'minimal_cards', false, ['boolean'])
                ->label('Minimal cards')
                ->help('Show each property as a small card, two per row, instead of one property per line.')
                ->field('toggle')
                ->normalizeUsing(fn ($value) => filter_var($value, FILTER_VALIDATE_BOOLEAN))
                ->frontend()
                ->frontendType('boolean'),

            \Vizion\Support\ScopedDefinition::make('drift-properties', 'category_nav', 'category_nav', 'off', ['required', 'string', 'in:off,navbar,sidebar,sidebar-left'])
                ->label('Category switcher')
                ->help('Lets users show one category at a time. Type off, navbar (a row of tabs above the list), sidebar-left (a list on the left) or sidebar (a list on the right).')
                ->field('text')
                ->normalizeUsing(fn ($value) => in_array(is_string($value) ? strtolower(trim($value)) : $value, ['off', 'navbar', 'sidebar', 'sidebar-left'], true) ? strtolower(trim($value)) : 'off')
                ->frontend()
                ->frontendType('string'),
        ]));
    }
}
