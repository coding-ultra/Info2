import { CATALOG, CATEGORIES, customDefinition, knownDefinition, type PropDef } from './catalog';
import { valuesOf, type ParsedProperties } from './properties';

export interface Row {
    def: PropDef;
    /** The value in the file, or undefined for a property that is being added. */
    original: string | undefined;
    /** The value to show: the user's edit if there is one. */
    value: string;
    edited: boolean;
}

export interface Group {
    category: string;
    rows: Row[];
}

const order = new Map(CATALOG.map((def, index) => [def.key, index]));

/**
 * Builds the rows of the editor from the file, the user's edits (`draft`) and the properties they are adding.
 * Keys the built-in list does not know are shown as custom properties unless `showCustom` is false.
 */
export function buildRows(parsed: ParsedProperties, draft: Record<string, string>, added: string[], showCustom: boolean): Row[] {
    const file = valuesOf(parsed);
    const rows: Row[] = [];

    for (const [key, original] of file) {
        const def = knownDefinition(key) ?? (showCustom ? customDefinition(key, original) : undefined);
        if (!def) continue;
        const value = draft[key] ?? original;
        rows.push({ def, original, value, edited: value !== original });
    }

    for (const key of added) {
        if (file.has(key)) continue;
        const def = knownDefinition(key) ?? customDefinition(key, draft[key] ?? '');
        rows.push({ def, original: undefined, value: draft[key] ?? def.default ?? '', edited: true });
    }

    return rows.sort((a, b) => (order.get(a.def.key) ?? Number.MAX_SAFE_INTEGER) - (order.get(b.def.key) ?? Number.MAX_SAFE_INTEGER) || a.def.key.localeCompare(b.def.key));
}

/** Rows that match the search text (name, key, description or current value) and, optionally, only the edited ones. */
export function filterRows(rows: Row[], query: string, editedOnly: boolean): Row[] {
    const needle = query.trim().toLowerCase();

    return rows.filter((row) => {
        if (editedOnly && !row.edited) return false;
        if (needle === '') return true;

        return [row.def.key, row.def.label, row.def.description, row.def.category, row.def.type === 'secret' ? '' : row.value].some((text) => text.toLowerCase().includes(needle));
    });
}

export function groupRows(rows: Row[]): Group[] {
    return CATEGORIES.map((category) => ({ category, rows: rows.filter((row) => row.def.category === category) })).filter((group) => group.rows.length > 0);
}

/** The key -> value map to hand to `serializeProperties`. */
export function changesOf(rows: Row[]): Record<string, string> {
    return Object.fromEntries(rows.filter((row) => row.edited).map((row) => [row.def.key, row.value]));
}

/** Known properties that are not in the file and not already being added. */
export function missingKeys(parsed: ParsedProperties, added: string[]): PropDef[] {
    const file = valuesOf(parsed);
    return CATALOG.filter((def) => !file.has(def.key) && !added.includes(def.key));
}

export const isValidCustomKey = (key: string): boolean => /^[A-Za-z0-9._-]+$/.test(key);
