import { useQuery } from '@tanstack/react-query';
import { Alert, PageContentBlock, Spinner, httpErrorToHuman } from '@pterodactyl/sdk';
import { displayKey, getDisplaySettings } from '../api';
import DisplayForm from '../components/DisplayForm';
import Footer from '../components/Footer';
import Header from '../components/Header';

/** Drift Properties settings page for root administrators, at /panel/drift-properties. */
export default function AdminScreen() {
    const query = useQuery({ queryKey: displayKey, queryFn: getDisplaySettings });

    return (
        <PageContentBlock title={'Drift Properties'}>
            <div className={'vz:grid vz:gap-4'}>
                <Header title={'Drift Properties'} subtitle={'Settings every server uses for the properties editor. Changes show up for users the next time they load the Panel.'} />

                {query.isLoading && <Spinner centered />}
                {query.isError && <Alert type={'danger'}>{httpErrorToHuman(query.error)}</Alert>}
                {query.data && <DisplayForm key={JSON.stringify(query.data)} data={query.data} />}

                <Footer />
            </div>
        </PageContentBlock>
    );
}
