import { DISCORD_LOGO, DISCORD_URL } from '../brand';

/** "Join our Discord" call to action, a real link in Discord blurple. */
export default function DiscordButton() {
    return (
        <a
            href={DISCORD_URL}
            target={'_blank'}
            rel={'noopener noreferrer'}
            className={'vz:flex vz:items-center vz:gap-2 vz:rounded-md vz:px-3 vz:py-2 vz:text-sm vz:font-semibold vz:no-underline'}
            style={{ background: '#5865f2', color: '#fff' }}
        >
            <img src={DISCORD_LOGO} alt={''} width={20} height={15} aria-hidden={true} />
            Join our Discord
        </a>
    );
}
