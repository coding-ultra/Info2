import { DISCORD_URL } from '../brand';

/** Credit line shown at the bottom of both pages. */
export default function Footer() {
    return (
        <p className={'vz:text-center vz:text-xs vz:text-muted-foreground'}>
            Made by{' '}
            <a href={DISCORD_URL} target={'_blank'} rel={'noopener noreferrer'} className={'vz:font-semibold vz:text-foreground'}>
                Drift Development
            </a>
            . Questions or ideas? Join our Discord.
        </p>
    );
}
