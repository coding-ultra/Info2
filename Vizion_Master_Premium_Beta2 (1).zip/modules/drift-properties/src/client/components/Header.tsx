import { DRIFT_ICON } from '../brand';
import DiscordButton from './DiscordButton';

/** The page heading with the Drift icon and the Discord button. */
export default function Header({ title, subtitle }: { title: string; subtitle: string }) {
    return (
        <div className={'vz:flex vz:flex-wrap vz:items-center vz:justify-between vz:gap-3'}>
            <div className={'vz:flex vz:items-center vz:gap-3'}>
                <img src={DRIFT_ICON} alt={''} width={40} height={40} className={'vz:rounded-md'} />
                <div>
                    <h2 className={'vz:font-semibold vz:text-foreground'}>{title}</h2>
                    <p className={'vz:text-xs vz:text-muted-foreground'}>{subtitle}</p>
                </div>
            </div>
            <DiscordButton />
        </div>
    );
}
