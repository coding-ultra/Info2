import { DISCORD_LOGO } from './discordLogo';

export const DISCORD_URL = 'https://discord.gg/eFQZayYSGN';

/**
 * A "Join our Discord" call to action in Discord's blurple. It is a real link, so it can be
 * opened in a new tab, copied or middle-clicked. Styled with this extension's own `drift:`
 * Tailwind prefix and the Panel's tokens for focus rings.
 */
export default function DiscordButton() {
    return (
        <a
            href={DISCORD_URL}
            target='_blank'
            rel='noopener noreferrer'
            className='vz:group vz:flex vz:w-full vz:items-center vz:gap-3 vz:rounded-lg vz:bg-[#5865f2] vz:px-4 vz:py-3 vz:text-[#ffffff] vz:no-underline vz:shadow-lg vz:shadow-[#5865f2]/30 vz:ring-1 vz:ring-inset vz:ring-[#ffffff26] vz:transition vz:duration-150 vz:hover:-translate-y-px vz:hover:bg-[#4752c4] vz:hover:text-[#ffffff] vz:hover:shadow-xl vz:hover:shadow-[#5865f2]/40 vz:focus-visible:outline-2 vz:focus-visible:outline-offset-2 vz:focus-visible:outline-ring'
        >
            <span className='vz:flex vz:size-9 vz:flex-none vz:items-center vz:justify-center vz:rounded-md vz:bg-[#ffffff26]'>
                <img src={DISCORD_LOGO} alt='' width='22' height='17' className='vz:block vz:h-auto vz:w-[22px]' aria-hidden='true' />
            </span>
            <span className='vz:flex vz:min-w-0 vz:flex-1 vz:flex-col vz:text-left'>
                <span className='vz:text-sm vz:font-semibold vz:leading-tight'>Join our Discord</span>
                <span className='vz:text-xs vz:leading-tight vz:text-[#ffffffbf]'>
                    Get help and chat with the community
                </span>
            </span>
            <svg
                viewBox='0 0 24 24'
                width='18'
                height='18'
                fill='none'
                stroke='currentColor'
                strokeWidth='2'
                strokeLinecap='round'
                strokeLinejoin='round'
                className='vz:flex-none vz:opacity-80 vz:transition-transform vz:duration-150 vz:group-hover:translate-x-0.5'
                aria-hidden='true'
            >
                <path d='M5 12h14M13 6l6 6-6 6' />
            </svg>
        </a>
    );
}

/** Rendered on the admin overview (slot panel.overview.after). */
export function AdminDiscord() {
    return (
        <div className='vz:mt-4 vz:max-w-sm'>
            <DiscordButton />
        </div>
    );
}
