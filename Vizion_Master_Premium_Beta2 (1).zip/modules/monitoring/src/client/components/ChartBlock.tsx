import type { ReactNode } from 'react';

/** Same frame as the console's CPU and memory graphs. */
export default function ChartBlock({ title, legend, children }: { title: string; legend?: ReactNode; children: ReactNode }) {
    return (
        <div className='vz:group vz:relative vz:rounded-sm vz:border-b-4 vz:border-border vz:bg-popover vz:pt-2 vz:shadow-lg'>
            <div className='vz:flex vz:items-center vz:justify-between vz:gap-3 vz:px-4 vz:py-2'>
                <h3 className='vz:font-header vz:font-medium vz:transition-colors vz:duration-100 vz:group-hover:text-foreground'>{title}</h3>
                {legend && <div className='vz:flex vz:items-center vz:gap-3 vz:text-sm vz:text-muted-foreground'>{legend}</div>}
            </div>
            <div className='vz:ml-2 vz:pb-2'>{children}</div>
        </div>
    );
}
