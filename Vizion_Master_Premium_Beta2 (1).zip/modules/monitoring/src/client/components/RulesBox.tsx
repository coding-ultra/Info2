import { useState } from 'react';
import { Button, Dialog, TitledGreyBox } from '@pterodactyl/sdk';
import type { ChannelOption, Rule, RuleInput } from '../api';
import { plural } from '../lib/format';
import Pill from './Pill';
import RuleDialog from './RuleDialog';

interface Props {
    title: string;
    rules: Rule[];
    channels: ChannelOption[];
    canManage: boolean;
    global?: boolean;
    saving: boolean;
    removing: boolean;
    onSave: (input: RuleInput, id: number | undefined, done: () => void) => void;
    onDelete: (id: number, done: () => void) => void;
}

export default function RulesBox({ title, rules, channels, canManage, global, saving, removing, onSave, onDelete }: Props) {
    const [editing, setEditing] = useState<Rule | 'new' | null>(null);
    const [deleting, setDeleting] = useState<Rule | null>(null);

    return (
        <TitledGreyBox title={title}>
            {rules.length === 0 ? (
                <p className='vz:text-sm vz:text-muted-foreground'>No rules yet.</p>
            ) : (
                <ul className='vz:grid vz:grid-cols-1 vz:gap-3'>
                    {rules.map((rule) => (
                        <li key={rule.id} className='vz:flex vz:flex-wrap vz:items-center vz:justify-between vz:gap-x-3 vz:gap-y-2'>
                            <div className='vz:min-w-0 vz:flex-1 vz:basis-40'>
                                <p className='vz:truncate vz:text-sm vz:text-foreground' title={rule.description}>
                                    {rule.description}
                                </p>
                                <p className='vz:truncate vz:text-xs vz:text-muted-foreground' title={rule.mine ? undefined : `Set up by ${rule.owner}`}>
                                    {rule.mine ? (rule.channels.length ? `Notifies ${plural(rule.channels.length, 'channel')}` : 'No notifications') : `Set up by ${rule.owner}`}
                                </p>
                            </div>
                            <div className='vz:ml-auto vz:flex vz:shrink-0 vz:items-center vz:gap-2'>
                                {!rule.enabled && <Pill>Paused</Pill>}
                                {canManage && (
                                    <>
                                        <Button.Text size='xsmall' onClick={() => setEditing(rule)}>
                                            Edit
                                        </Button.Text>
                                        <Button.Danger size='xsmall' onClick={() => setDeleting(rule)}>
                                            Delete
                                        </Button.Danger>
                                    </>
                                )}
                            </div>
                        </li>
                    ))}
                </ul>
            )}
            {canManage && (
                <div className='vz:mt-4 vz:flex vz:justify-end'>
                    <Button size='small' onClick={() => setEditing('new')}>
                        New rule
                    </Button>
                </div>
            )}
            {editing && (
                <RuleDialog
                    rule={editing === 'new' ? null : editing}
                    channels={channels}
                    global={global}
                    pending={saving}
                    onClose={() => setEditing(null)}
                    onSave={(input) => onSave(input, editing === 'new' ? undefined : editing.id, () => setEditing(null))}
                />
            )}
            <Dialog.Confirm
                open={deleting !== null}
                onClose={() => setDeleting(null)}
                title='Delete this rule?'
                confirm='Delete'
                pending={removing}
                onConfirmed={() => deleting && onDelete(deleting.id, () => setDeleting(null))}
            >
                {deleting?.description}. Its alert history is deleted too.
            </Dialog.Confirm>
        </TitledGreyBox>
    );
}
