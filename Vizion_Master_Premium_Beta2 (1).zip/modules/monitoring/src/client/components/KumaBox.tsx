import { useState } from 'react';
import { Button, Input, TitledGreyBox } from '@pterodactyl/sdk';
import type { ServerMonitoring } from '../api';
import { formatAgo } from '../lib/format';
import Pill from './Pill';

interface Props {
    push: ServerMonitoring['push'];
    interval: number;
    pending: boolean;
    onSave: (url: string | null) => void;
}

export default function KumaBox({ push, interval, pending, onSave }: Props) {
    const [editing, setEditing] = useState(false);
    const [url, setUrl] = useState('');

    return (
        <TitledGreyBox title='Uptime Kuma'>
            {push && !editing ? (
                <div className='vz:grid vz:grid-cols-1 vz:gap-3 vz:text-sm'>
                    <div className='vz:flex vz:items-center vz:justify-between vz:gap-3'>
                        <span className='vz:min-w-0 vz:truncate vz:text-foreground' title={push.host}>
                            {push.host}
                        </span>
                        {push.last_error ? <Pill tone='danger'>Failing</Pill> : push.last_up === null ? <Pill>Waiting</Pill> : push.last_up ? <Pill tone='success'>Up</Pill> : <Pill tone='danger'>Down</Pill>}
                    </div>
                    <p className='vz:text-xs vz:break-words vz:text-muted-foreground'>{push.last_error ?? `Last heartbeat ${formatAgo(push.pushed_at)}.`}</p>
                    <div className='vz:flex vz:justify-end vz:gap-2'>
                        <Button.Text size='small' disabled={pending} onClick={() => onSave(null)}>
                            Remove
                        </Button.Text>
                        <Button.Text size='small' onClick={() => setEditing(true)}>
                            Change
                        </Button.Text>
                    </div>
                </div>
            ) : (
                <form
                    className='vz:grid vz:grid-cols-1 vz:gap-3'
                    onSubmit={(event) => {
                        event.preventDefault();
                        onSave(url.trim());
                        setEditing(false);
                        setUrl('');
                    }}
                >
                    <p className='vz:text-sm vz:text-muted-foreground'>
                        Add a <span className='vz:text-foreground'>Push</span> monitor in Uptime Kuma with a heartbeat interval of {interval * 60 + 60} seconds, then paste its push URL here.
                    </p>
                    <Input aria-label='Push URL' type='url' placeholder='https://status.example.com/api/push/…' value={url} onChange={(event) => setUrl(event.currentTarget.value)} />
                    <div className='vz:flex vz:justify-end vz:gap-2'>
                        {push && (
                            <Button.Text size='small' type='button' onClick={() => setEditing(false)}>
                                Cancel
                            </Button.Text>
                        )}
                        <Button size='small' type='submit' disabled={!url.includes('/api/push/')} isLoading={pending}>
                            Connect
                        </Button>
                    </div>
                </form>
            )}
        </TitledGreyBox>
    );
}
