import type { ReactNode } from 'react';

const TONES = {
    neutral: 'vz:border-border vz:bg-muted vz:text-muted-foreground',
    success: 'vz:border-success/25 vz:bg-success/10 vz:text-success',
    warning: 'vz:border-warning/25 vz:bg-warning/10 vz:text-warning',
    danger: 'vz:border-destructive/25 vz:bg-destructive/10 vz:text-destructive',
};

/** Styled like the panel's node status badge. */
export default function Pill({ tone = 'neutral', children }: { tone?: keyof typeof TONES; children: ReactNode }) {
    return (
        <span className={`vz:inline-flex vz:items-center vz:gap-1.5 vz:whitespace-nowrap vz:rounded-sm vz:border vz:px-2 vz:py-0.5 vz:text-xs vz:font-medium ${TONES[tone]}`}>
            <span aria-hidden className='vz:h-1.5 vz:w-1.5 vz:rounded-full vz:bg-current' />
            {children}
        </span>
    );
}
