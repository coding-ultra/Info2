import { PanelLink } from '@pterodactyl/sdk';
import type { Headline } from '../api';

/** Four headline numbers, shared by the admin page and the overview widget. */
export default function StatTiles({ summary, linked = false }: { summary: Headline; linked?: boolean }) {
    const healthy = summary.scheduler.ok && summary.queue.ok;
    const tiles = [
        { label: 'Servers running', value: `${summary.servers.running} / ${summary.servers.total}`, tone: '' },
        { label: 'Nodes reachable', value: `${summary.nodes.reachable} / ${summary.nodes.total}`, tone: summary.nodes.reachable < summary.nodes.total ? 'vz:text-destructive' : '' },
        { label: 'Open alerts', value: String(summary.alerts), tone: summary.alerts > 0 ? 'vz:text-destructive' : '' },
        { label: 'Background jobs', value: healthy ? 'Running' : 'Stalled', tone: healthy ? 'vz:text-success' : 'vz:text-destructive' },
    ];

    return (
        <div className='vz:mb-6 vz:grid vz:grid-cols-2 vz:gap-3 vz:lg:grid-cols-4'>
            {tiles.map((tile) => {
                const content = (
                    <>
                        <p className='vz:truncate vz:text-sm vz:text-muted-foreground' title={tile.label}>
                            {tile.label}
                        </p>
                        <p className={`vz:mt-1 vz:truncate vz:font-header vz:text-2xl vz:font-semibold vz:text-foreground ${tile.tone}`} title={tile.value}>
                            {tile.value}
                        </p>
                    </>
                );
                const className = 'vz:block vz:min-w-0 vz:rounded-sm vz:border vz:border-transparent vz:bg-card vz:p-5 vz:no-underline';

                return linked ? (
                    <PanelLink key={tile.label} destination={{ extension: 'monitoring', screen: 'admin' }} className={`${className} vz:hover:border-border`}>
                        {content}
                    </PanelLink>
                ) : (
                    <div key={tile.label} className={className}>
                        {content}
                    </div>
                );
            })}
        </div>
    );
}
