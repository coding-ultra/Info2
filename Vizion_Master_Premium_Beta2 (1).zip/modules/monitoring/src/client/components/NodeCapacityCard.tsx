import { NamedIcon, TitledGreyBox } from '@pterodactyl/sdk';
import type { NodeHealth } from '../api';
import { HOST_UNKNOWN, cpuText } from '../lib/capacity';
import CapacityBar from './CapacityBar';
import Pill from './Pill';

function Note({ icon, children }: { icon: string; children: string }) {
    return (
        <p className='vz:flex vz:items-start vz:gap-1.5 vz:text-xs vz:leading-relaxed vz:text-muted-foreground'>
            <NamedIcon name={icon} aria-hidden className='vz:mt-0.5 vz:h-3.5 vz:w-3.5 vz:shrink-0' />
            <span className='vz:min-w-0'>{children}</span>
        </p>
    );
}

/** Memory, disk and CPU of one node. `wide` puts memory and disk side by side. */
export default function NodeCapacityCard({ node, wide = false }: { node: NodeHealth; wide?: boolean }) {
    const note = !node.panel_host ? HOST_UNKNOWN : !node.disk.host ? "Disk usage outside Pterodactyl is unknown: the panel cannot see this node's disk." : null;

    return (
        <TitledGreyBox
            className='vz:min-w-0'
            title={
                <div className='vz:flex vz:min-w-0 vz:items-center vz:justify-between vz:gap-3'>
                    <h3 className='vz:truncate vz:font-header vz:text-sm vz:font-semibold vz:uppercase vz:tracking-wide vz:text-foreground' title={node.name}>
                        {node.name}
                    </h3>
                    {node.reachable === false ? <Pill tone='danger'>Offline</Pill> : node.panel_host && <Pill>Runs the panel</Pill>}
                </div>
            }
        >
            <div className={`vz:grid vz:grid-cols-1 vz:gap-6 ${wide ? 'vz:md:grid-cols-2' : ''}`}>
                <CapacityBar label='Memory' capacity={node.memory} />
                <CapacityBar label='Disk' capacity={node.disk} />
            </div>
            <div className='vz:mt-4 vz:grid vz:grid-cols-1 vz:gap-1.5 vz:border-t vz:border-border vz:pt-3'>
                <Note icon='cpu'>{`CPU · ${cpuText(node.cpu)}`}</Note>
                {note && <Note icon='info'>{note}</Note>}
            </div>
        </TitledGreyBox>
    );
}
