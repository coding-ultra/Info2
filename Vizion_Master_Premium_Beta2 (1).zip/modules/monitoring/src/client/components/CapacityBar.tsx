import { Fragment } from 'react';
import { NamedIcon } from '@pterodactyl/sdk';
import type { Capacity, SegmentKey } from '../api';
import { SEGMENT_LABELS, allocationText, compactAllocationParts, describeSegments, warningText } from '../lib/capacity';
import { formatMiB } from '../lib/format';

const COLOURS: Record<SegmentKey, string> = {
    servers: 'vz:bg-chart-1',
    other: 'vz:bg-muted-foreground/60',
    free: 'vz:bg-sunken vz:ring-1 vz:ring-inset vz:ring-border',
    unused: 'vz:bg-sunken vz:ring-1 vz:ring-inset vz:ring-border',
};

export function Swatch({ segment }: { segment: SegmentKey }) {
    return <span aria-hidden className={`vz:inline-block vz:h-2.5 vz:w-2.5 vz:shrink-0 vz:rounded-[2px] ${COLOURS[segment]}`} />;
}

/** Servers, everything else on the machine and what is left, stacked on one track. Free space is the track itself. */
export function StackedBar({ label, capacity, className = '' }: { label: string; capacity: Capacity; className?: string }) {
    const filled = capacity.segments.filter((segment) => (segment.key === 'servers' || segment.key === 'other') && segment.mib > 0);

    return (
        <div role='img' aria-label={describeSegments(label, capacity)} className={`vz:flex vz:h-2 vz:w-full vz:gap-0.5 vz:overflow-hidden vz:rounded-sm vz:bg-sunken ${className}`}>
            {filled.map((segment) => (
                <div
                    key={segment.key}
                    data-segment={segment.key}
                    title={`${SEGMENT_LABELS[segment.key]}: ${formatMiB(segment.mib)} (${segment.percent}%)`}
                    className={`vz:h-full vz:min-w-0.5 vz:shrink-0 ${COLOURS[segment.key]}`}
                    style={{ width: `${segment.percent}%` }}
                />
            ))}
        </div>
    );
}

function Legend({ capacity }: { capacity: Capacity }) {
    return (
        <ul className='vz:mt-2 vz:flex vz:flex-wrap vz:gap-x-3 vz:gap-y-1 vz:text-xs vz:text-muted-foreground'>
            {capacity.segments.map((segment) => (
                <li key={segment.key} className='vz:flex vz:items-center vz:gap-1.5 vz:whitespace-nowrap'>
                    <Swatch segment={segment.key} />
                    {SEGMENT_LABELS[segment.key]}
                    <span className='vz:text-foreground'>{formatMiB(segment.mib)}</span>
                </li>
            ))}
        </ul>
    );
}

function Warning({ capacity }: { capacity: Capacity }) {
    const text = warningText(capacity);

    return text ? (
        <p className='vz:mt-1 vz:flex vz:items-start vz:gap-1.5 vz:text-xs vz:text-warning'>
            <NamedIcon name='triangle-alert' aria-hidden className='vz:mt-px vz:h-3.5 vz:w-3.5 vz:shrink-0' />
            <span className='vz:min-w-0'>{text}</span>
        </p>
    ) : null;
}

/** One resource of a node: stacked usage, a legend with values and the allocation line. */
export default function CapacityBar({ label, capacity }: { label: string; capacity: Capacity }) {
    return (
        <div className='vz:min-w-0'>
            <div className='vz:mb-1.5 vz:flex vz:items-baseline vz:justify-between vz:gap-3 vz:text-sm'>
                <span className='vz:font-medium vz:text-foreground'>{label}</span>
                <span className='vz:truncate vz:text-xs vz:text-muted-foreground'>{formatMiB(capacity.total)} total</span>
            </div>
            <StackedBar label={label} capacity={capacity} />
            <Legend capacity={capacity} />
            <p className={`vz:mt-2 vz:text-xs vz:leading-relaxed ${capacity.warnings.length ? 'vz:text-warning' : 'vz:text-muted-foreground'}`}>{allocationText(capacity)}</p>
            <Warning capacity={capacity} />
        </div>
    );
}

/** The overview widget's short form: label, how much is allocated and left, and the bar. The numbers wrap between their parts when narrow. */
export function CompactCapacity({ label, capacity }: { label: string; capacity: Capacity }) {
    const warning = warningText(capacity);

    return (
        <div className='vz:min-w-0' title={[describeSegments(label, capacity), allocationText(capacity), warning].filter(Boolean).join('\n')}>
            <div className='vz:flex vz:flex-wrap vz:items-baseline vz:justify-between vz:gap-x-2 vz:text-xs'>
                <span className='vz:text-muted-foreground'>{label}</span>
                <span className={`vz:flex vz:min-w-0 vz:items-center vz:gap-1 ${warning ? 'vz:text-warning' : 'vz:text-foreground'}`}>
                    {warning && <NamedIcon name='triangle-alert' aria-label={warning} className='vz:h-3 vz:w-3 vz:shrink-0' />}
                    <span className='vz:min-w-0'>
                        {compactAllocationParts(capacity).map((part, index) => (
                            <Fragment key={part}>
                                {index > 0 && ' · '}
                                <span className='vz:whitespace-nowrap'>{part}</span>
                            </Fragment>
                        ))}
                    </span>
                </span>
            </div>
            <StackedBar label={label} capacity={capacity} className='vz:mt-1' />
        </div>
    );
}
