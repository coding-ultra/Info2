import { useQuery } from '@tanstack/react-query';
import { PanelLink } from '@pterodactyl/sdk';
import { getSummary, keys, type NodeCapacity } from '../api';
import { SEGMENT_LABELS } from '../lib/capacity';
import { CompactCapacity, Swatch } from './CapacityBar';
import StatTiles from './StatTiles';

const SHOWN = 6;

export default function OverviewWidget() {
    const summary = useQuery({ queryKey: keys.summary, queryFn: getSummary, refetchInterval: 60_000, retry: false });

    return summary.data ? (
        <>
            <StatTiles summary={summary.data} linked />
            {summary.data.capacity?.length > 0 && <CapacityOverview nodes={summary.data.capacity} />}
        </>
    ) : null;
}

/** Nodes needing attention first, so a long list still shows them. */
function CapacityOverview({ nodes }: { nodes: NodeCapacity[] }) {
    const pressure = (node: NodeCapacity) => node.memory.warnings.length + node.disk.warnings.length;
    const shown = [...nodes].sort((a, b) => pressure(b) - pressure(a)).slice(0, SHOWN);
    const measured = nodes.some((node) => node.panel_host);

    return (
        <section aria-label='Node capacity' className='vz:mb-6 vz:min-w-0 vz:rounded-sm vz:bg-card vz:p-5'>
            <div className='vz:mb-4 vz:flex vz:items-center vz:justify-between vz:gap-3'>
                <h2 className='vz:font-header vz:text-sm vz:font-semibold vz:uppercase vz:tracking-wide vz:text-foreground'>Node capacity</h2>
                <PanelLink destination={{ extension: 'monitoring', screen: 'admin' }} className='vz:shrink-0 vz:text-xs vz:text-muted-foreground vz:hover:text-foreground'>
                    {nodes.length > SHOWN ? `All ${nodes.length} nodes` : 'Details'}
                </PanelLink>
            </div>
            <ul className='vz:grid vz:grid-cols-1 vz:gap-4'>
                {shown.map((node) => (
                    <li key={node.id} className='vz:grid vz:grid-cols-1 vz:items-end vz:gap-x-6 vz:gap-y-2 vz:md:grid-cols-2 vz:xl:grid-cols-[minmax(0,12rem)_minmax(0,1fr)_minmax(0,1fr)]'>
                        <p className='vz:truncate vz:text-sm vz:text-foreground vz:md:col-span-2 vz:xl:col-span-1' title={node.name}>
                            {node.name}
                            {node.reachable === false && <span className='vz:text-destructive'> · offline</span>}
                        </p>
                        <CompactCapacity label='Memory' capacity={node.memory} />
                        <CompactCapacity label='Disk' capacity={node.disk} />
                    </li>
                ))}
            </ul>
            <ul aria-label='Legend' className='vz:mt-4 vz:flex vz:flex-wrap vz:items-center vz:gap-x-3 vz:gap-y-1 vz:text-xs vz:text-muted-foreground'>
                {(measured ? (['servers', 'other', 'free'] as const) : (['servers', 'unused'] as const)).map((segment) => (
                    <li key={segment} className='vz:flex vz:items-center vz:gap-1.5 vz:whitespace-nowrap'>
                        <Swatch segment={segment} />
                        {segment === 'free' ? 'Free or not measured' : SEGMENT_LABELS[segment]}
                    </li>
                ))}
            </ul>
        </section>
    );
}
