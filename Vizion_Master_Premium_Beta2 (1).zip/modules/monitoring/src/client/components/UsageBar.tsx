/** The usage bar from the node About tab. */
export default function UsageBar({ used, total, label }: { used: number; total: number; label: string }) {
    const percent = total > 0 ? Math.min(100, (used / total) * 100) : 0;
    const colour = percent >= 90 ? 'vz:bg-destructive' : percent >= 75 ? 'vz:bg-warning' : 'vz:bg-success';

    return (
        <div className='vz:min-w-24'>
            <p className='vz:text-xs vz:text-muted-foreground'>{label}</p>
            <div className='vz:mt-1 vz:h-2 vz:w-full vz:overflow-hidden vz:rounded-sm vz:bg-sunken' role='meter' aria-valuenow={Math.round(percent)} aria-valuemin={0} aria-valuemax={100} aria-label={label}>
                <div className={`vz:h-2 vz:rounded-sm ${colour}`} style={{ width: `${percent}%` }} />
            </div>
        </div>
    );
}
