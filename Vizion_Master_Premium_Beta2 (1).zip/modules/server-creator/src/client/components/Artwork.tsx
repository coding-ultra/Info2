import { useState } from 'react';

/** Game artwork in Steam's header format, or the game's name when there is none. */
export default function Artwork({ src, name, className = '' }: { src: string | null; name: string; className?: string }) {
    const [failed, setFailed] = useState(false);

    return (
        <div className={`vz:relative vz:aspect-[460/215] vz:overflow-hidden vz:rounded-sm vz:bg-sunken ${className}`}>
            {src && !failed ? (
                <img src={src} alt='' loading='lazy' referrerPolicy='no-referrer' onError={() => setFailed(true)} className='vz:h-full vz:w-full vz:object-cover' />
            ) : (
                <span className='vz:absolute vz:inset-0 vz:flex vz:items-center vz:justify-center vz:p-2 vz:text-center vz:font-header vz:text-sm vz:font-semibold vz:text-muted-foreground vz:sm:p-3 vz:sm:text-lg'>
                    <span className='vz:line-clamp-2 vz:break-words'>{name}</span>
                </span>
            )}
        </div>
    );
}
