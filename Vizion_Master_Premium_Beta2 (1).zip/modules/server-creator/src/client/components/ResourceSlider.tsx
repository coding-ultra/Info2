import { useState } from 'react';
import { Input, Label } from '@pterodactyl/sdk';
import { EDIT_UNITS, clamp, editable, formatSize, indexOf, labels, leftText, parseSize, positionOf, recommended, scaleFor, stopCount, ticks, valueAt, type Sized } from '../lib/resources';

interface Props {
    id: string;
    resource: Sized;
    label: string;
    value: number;
    min: number;
    max: number;
    onChange: (value: number) => void;
    /** What the plan still has for this server, and the plan's total. */
    quota?: { available: number; limit: number };
    /** Mark a recommended size on the track. Only makes sense when a game sets the minimum. */
    suggest?: boolean;
}

const thumb = [
    'vz:[&::-webkit-slider-thumb]:size-7 vz:[&::-webkit-slider-thumb]:appearance-none vz:[&::-webkit-slider-thumb]:rounded-full vz:[&::-webkit-slider-thumb]:border-4 vz:[&::-webkit-slider-thumb]:border-primary vz:[&::-webkit-slider-thumb]:bg-card vz:[&::-webkit-slider-thumb]:shadow-md vz:[&::-webkit-slider-thumb]:transition-shadow',
    'vz:[&::-moz-range-thumb]:size-7 vz:[&::-moz-range-thumb]:box-border vz:[&::-moz-range-thumb]:rounded-full vz:[&::-moz-range-thumb]:border-4 vz:[&::-moz-range-thumb]:border-primary vz:[&::-moz-range-thumb]:bg-card vz:[&::-moz-range-thumb]:shadow-md vz:[&::-moz-range-track]:bg-transparent',
    'vz:focus-visible:[&::-webkit-slider-thumb]:ring-4 vz:focus-visible:[&::-webkit-slider-thumb]:ring-ring/50 vz:focus-visible:[&::-moz-range-thumb]:ring-4 vz:focus-visible:[&::-moz-range-thumb]:ring-ring/50',
].join(' ');

/** Keeps a label inside the track's width when it sits near either end. */
function placed(at: number) {
    if (at < 0.1) return { className: 'vz:-left-3.5', style: undefined };
    if (at > 0.9) return { className: 'vz:-right-3.5', style: undefined };

    return { className: 'vz:-translate-x-1/2', style: { left: `${at * 100}%` } };
}

/** A memory, disk or CPU picker that reads in GiB and cores but works in the API's MiB and percent. */
export default function ResourceSlider({ id, resource, label, value, min, max, onChange, quota, suggest = false }: Props) {
    const [draft, setDraft] = useState<string | null>(null);
    const fixed = max <= min;
    const scale = scaleFor(resource, min, max);
    const shown = fixed && max === min ? min : value;
    const friendly = formatSize(resource, shown);
    const outside = !fixed && (value < min || value > max);
    const suggestion = suggest && !fixed ? recommended(resource, scale) : null;
    const filled = fixed ? (max < min ? 0 : 1) : outside ? (value > max ? 1 : 0) : positionOf(scale, value);
    const marks = labels(resource, scale, 0.2, suggestion);
    const suggested = suggestion === null ? null : positionOf(scale, suggestion);

    const commit = () => {
        const parsed = draft === null ? null : parseSize(resource, draft);

        setDraft(null);
        parsed !== null && onChange(clamp(parsed, min, max));
    };

    return (
        <div className='vz:grid vz:gap-1'>
            <div className='vz:flex vz:min-h-9 vz:items-center vz:justify-between vz:gap-3'>
                <Label htmlFor={id}>{label}</Label>
                {draft === null ? (
                    <button
                        type='button'
                        disabled={fixed}
                        aria-label={`${label}: ${friendly}. Type an exact value`}
                        title={fixed ? undefined : 'Type an exact value'}
                        onClick={() => setDraft(editable(resource, value))}
                        className={`vz:-mr-1 vz:rounded-sm vz:px-1 vz:font-header vz:text-lg vz:font-semibold vz:tabular-nums vz:underline-offset-4 vz:decoration-dashed vz:decoration-muted-foreground vz:enabled:cursor-text vz:enabled:underline vz:enabled:hover:decoration-primary vz:focus-visible:outline-2 vz:focus-visible:outline-ring ${outside || max < min ? 'vz:text-destructive' : 'vz:text-foreground'}`}
                    >
                        {friendly}
                    </button>
                ) : (
                    <div className='vz:flex vz:items-center vz:gap-2'>
                        <Input
                            autoFocus
                            inputMode='decimal'
                            aria-label={`${label} in ${EDIT_UNITS[resource]}`}
                            className='vz:w-24 vz:text-right vz:tabular-nums'
                            value={draft}
                            onFocus={(event) => event.currentTarget.select()}
                            onChange={(event) => setDraft(event.currentTarget.value)}
                            onBlur={commit}
                            onKeyDown={(event) => {
                                if (event.key === 'Enter') {
                                    event.preventDefault();
                                    commit();
                                } else if (event.key === 'Escape') {
                                    setDraft(null);
                                }
                            }}
                        />
                        <span className='vz:text-sm vz:text-muted-foreground'>{EDIT_UNITS[resource]}</span>
                    </div>
                )}
            </div>
            <div className={`vz:relative vz:h-11 ${fixed ? 'vz:opacity-60' : ''}`}>
                <div aria-hidden className='vz:pointer-events-none vz:absolute vz:inset-x-3.5 vz:top-1/2 vz:h-2 vz:-translate-y-1/2 vz:rounded-full vz:bg-sunken'>
                    <div className='vz:absolute vz:inset-y-0 vz:left-0 vz:rounded-full vz:bg-primary' style={{ width: `${filled * 100}%` }} />
                    {ticks(resource, scale).map((tick) => (
                        <span
                            key={tick.value}
                            className={`vz:absolute vz:top-1/2 vz:-translate-1/2 vz:rounded-full ${tick.value === suggestion ? 'vz:size-2.5 vz:ring-2 vz:ring-primary' : 'vz:size-1.5'} ${tick.at <= filled ? 'vz:bg-primary-foreground/70' : 'vz:bg-muted-foreground/60'}`}
                            style={{ left: `${tick.at * 100}%` }}
                        />
                    ))}
                </div>
                <input
                    id={id}
                    type='range'
                    min={0}
                    max={fixed ? 1 : stopCount(scale) - 1}
                    step={1}
                    value={fixed ? filled : indexOf(scale, value)}
                    disabled={fixed}
                    aria-valuetext={friendly}
                    aria-describedby={quota || fixed ? `${id}-left` : undefined}
                    onChange={(event) => onChange(valueAt(scale, Number(event.currentTarget.value)))}
                    className={`vz:relative vz:block vz:h-full vz:w-full vz:cursor-pointer vz:appearance-none vz:bg-transparent vz:outline-none vz:disabled:cursor-not-allowed ${thumb}`}
                />
            </div>
            <div className={`vz:relative vz:mx-3.5 vz:text-xs vz:text-muted-foreground ${suggestion === null ? 'vz:h-4' : 'vz:h-9'}`}>
                {marks.map(({ value: mark, at }) => {
                    const { className, style } = placed(at);

                    return (
                        <span key={mark} aria-hidden className={`vz:absolute vz:top-0 vz:whitespace-nowrap ${className} ${mark === suggestion ? 'vz:font-medium vz:text-primary' : ''}`} style={style}>
                            {formatSize(resource, mark)}
                        </span>
                    );
                })}
                {suggestion !== null && suggested !== null && (
                    <button
                        type='button'
                        aria-pressed={value === suggestion}
                        aria-label={`Use the recommended ${formatSize(resource, suggestion)}`}
                        onClick={() => onChange(suggestion)}
                        className={`vz:absolute vz:top-4 vz:whitespace-nowrap vz:rounded-sm vz:text-[0.6875rem] vz:font-medium vz:uppercase vz:tracking-wide vz:text-primary vz:hover:underline vz:focus-visible:outline-2 vz:focus-visible:outline-ring ${placed(suggested).className}`}
                        style={placed(suggested).style}
                    >
                        Recommended
                    </button>
                )}
            </div>
            <div id={`${id}-left`} className='vz:mt-1 vz:flex vz:flex-wrap vz:justify-between vz:gap-x-3 vz:text-xs vz:text-muted-foreground'>
                {quota && <p>{leftText(resource, fixed ? shown : value, quota.available, quota.limit)}</p>}
                {fixed && <p className={max < min ? 'vz:text-destructive' : undefined}>{max < min ? 'No room left in your plan to change it' : 'Set by your plan'}</p>}
            </div>
            {outside && (
                <p className='vz:text-xs vz:text-destructive'>
                    Pick between {formatSize(resource, min)} and {formatSize(resource, max)}.
                </p>
            )}
        </div>
    );
}
