import { useQuery } from '@tanstack/react-query';
import { Button, usePanelNavigate } from '@pterodactyl/sdk';
import { getOverview, keys } from '../api';
import { remainingText } from '../lib/format';

/** Shown above the server list for users who may create servers. */
export default function CreateBanner() {
    const navigate = usePanelNavigate();
    const overview = useQuery({ queryKey: keys.overview, queryFn: getOverview, staleTime: 30_000, retry: false });

    if (!overview.data || overview.data.quota.limits.servers < 1 || overview.data.games.length === 0) {
        return null;
    }

    return (
        <div className='vz:mb-4 vz:flex vz:flex-col vz:gap-3 vz:rounded-sm vz:border vz:border-border vz:bg-card vz:px-4 vz:py-3 vz:sm:flex-row vz:sm:items-center vz:sm:justify-between'>
            <p className='vz:text-sm vz:text-muted-foreground'>{remainingText(overview.data.quota.remaining)}</p>
            {overview.data.quota.remaining.servers > 0 && (
                <Button size='small' className='vz:shrink-0' onClick={() => navigate({ extension: 'server-creator', screen: 'create' })}>
                    Create server
                </Button>
            )}
        </div>
    );
}
