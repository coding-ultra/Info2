import { useState } from 'react';
import { useMutation, useQuery } from '@tanstack/react-query';
import { Button, Checkbox, Dialog, Input, Label, httpErrorToHuman, toast, usePanelNavigate, type ExtensionResourceContext } from '@pterodactyl/sdk';
import { duplicateServer, getCopies, keys, type Copy } from '../api';
import UserSelect from './UserSelect';

const STEPS: Record<Copy['step'], string> = {
    backup: 'Starting a backup of the original',
    'backing-up': 'Backing up the original',
    restore: 'Waiting for the copy to finish installing',
    restoring: 'Restoring the backup into the copy',
    cleanup: 'Deleting the temporary backup',
    done: 'Files copied',
    failed: 'Copying files failed',
};

/** "Duplicate" on the admin server page, plus the progress of file copies from or to this server. */
export default function DuplicateButton({ data }: { data: ExtensionResourceContext }) {
    const navigate = usePanelNavigate();
    const server = data.kind === 'admin.server' ? data.resource.attributes : null;
    const [open, setOpen] = useState(false);
    const [name, setName] = useState('');
    const [owner, setOwner] = useState<number | null>(null);
    const [files, setFiles] = useState(true);

    const copies = useQuery({
        queryKey: keys.copies(server?.id ?? 0),
        queryFn: () => getCopies(server!.id),
        enabled: server !== null,
        refetchInterval: (query) => (query.state.data?.some((copy) => !['done', 'failed'].includes(copy.step)) ? 5000 : false),
    });

    const duplication = useMutation({
        mutationFn: () => duplicateServer(server!.id, { name: name.trim(), owner: owner ?? server!.user, files }),
        onSuccess: ({ id }) => {
            toast.success(files ? 'Server duplicated. Its files are copied in the background.' : 'Server duplicated.');
            setOpen(false);
            navigate({ to: '/panel/servers/$id', params: { id: String(id) } });
        },
        onError: (error) => toast.error(httpErrorToHuman(error)),
    });

    if (!server) {
        return null;
    }

    const active = (copies.data ?? []).filter((copy) => !['done'].includes(copy.step) && Date.now() - new Date(copy.created_at).getTime() < 86_400_000);

    return (
        <div className='vz:mb-4 vz:flex vz:flex-col vz:gap-3'>
            <div className='vz:flex vz:justify-end'>
                <Button.Text
                    size='small'
                    onClick={() => {
                        setName(`${server.name} (copy)`);
                        setOwner(server.user);
                        setOpen(true);
                    }}
                >
                    Duplicate
                </Button.Text>
            </div>
            {active.map((copy) => (
                <p key={copy.id} className={`vz:rounded-sm vz:border vz:px-4 vz:py-2 vz:text-sm ${copy.step === 'failed' ? 'vz:border-destructive/25 vz:bg-destructive/10 vz:text-destructive' : 'vz:border-border vz:bg-card vz:text-muted-foreground'}`}>
                    {copy.target.id === server.id ? `Copying files from ${copy.source}` : `Copying files to ${copy.target.name}`}: {STEPS[copy.step]}
                    {copy.error ? `. ${copy.error}` : copy.step === 'failed' ? '.' : '…'}
                </p>
            ))}
            <Dialog open={open} onClose={() => setOpen(false)} title={`Duplicate ${server.name}`} preventExternalClose={duplication.isPending}>
                <div className='vz:grid vz:gap-4'>
                    <p className='vz:text-sm vz:text-muted-foreground'>Creates a server with the same egg, startup, variables and limits on the same node, with a new port.</p>
                    <div>
                        <Label htmlFor='srvc-copy-name'>Name</Label>
                        <Input id='srvc-copy-name' value={name} maxLength={191} onChange={(event) => setName(event.currentTarget.value)} />
                    </div>
                    <div>
                        <Label htmlFor='srvc-copy-owner'>Owner</Label>
                        <UserSelect id='srvc-copy-owner' value={owner} fallback={{ id: server.user, label: 'Current owner' }} onChange={(user) => setOwner(user.id)} />
                    </div>
                    <label className='vz:flex vz:items-center vz:gap-2 vz:text-sm vz:text-foreground'>
                        <Checkbox checked={files} onChange={setFiles} />
                        Copy files
                    </label>
                    {files && <p className='vz:-mt-2 vz:text-xs vz:text-muted-foreground'>Takes a backup of this server and restores it into the copy. The backup is deleted afterwards.</p>}
                </div>
                <Dialog.Footer>
                    <Button.Text className='vz:w-full vz:sm:w-auto' disabled={duplication.isPending} onClick={() => setOpen(false)}>
                        Cancel
                    </Button.Text>
                    <Button className='vz:w-full vz:sm:w-auto' disabled={name.trim() === ''} isLoading={duplication.isPending} onClick={() => duplication.mutate()}>
                        Duplicate
                    </Button>
                </Dialog.Footer>
            </Dialog>
        </div>
    );
}
