import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Button, Dialog, Input, Label, Select, Switch } from '@pterodactyl/sdk';
import { keys, searchSteam, type Admin, type Game, type GameInput, type PopularGame } from '../api';
import { formatSize } from '../lib/resources';
import Artwork from './Artwork';

const RANGES = [
    { key: 'memory', label: 'Memory (MiB)' },
    { key: 'disk', label: 'Disk (MiB)' },
    { key: 'cpu', label: 'CPU (%)' },
] as const;

const FEATURES = [
    { key: 'databases', label: 'Databases' },
    { key: 'backups', label: 'Backups' },
    { key: 'allocations', label: 'Extra ports' },
] as const;

interface Props {
    game: Game | null;
    /** Starts a new game from ready-made settings. */
    preset?: PopularGame | null;
    eggs: Admin['eggs'];
    pending: boolean;
    onClose: () => void;
    onSave: (input: GameInput) => void;
}

const CATALOG = 'catalog:';

function blank(eggs: Admin['eggs']): GameInput {
    return {
        egg_id: eggs[0]?.id ?? null,
        name: '',
        description: null,
        image: null,
        steam_app_id: null,
        docker_image: null,
        enabled: true,
        sort: 0,
        memory_min: 1024,
        memory_max: 4096,
        disk_min: 5120,
        disk_max: 20480,
        cpu_min: 100,
        cpu_max: 200,
        databases: 0,
        backups: 1,
        allocations: 0,
        ports: 1,
        port_variables: [],
        port_range: null,
    };
}

function fromPreset(preset: PopularGame, eggs: Admin['eggs']): GameInput {
    return { ...blank(eggs), ...preset, catalog_id: preset.egg_id === null ? preset.catalog_id : null };
}

export default function GameDialog({ game, preset = null, eggs, pending, onClose, onSave }: Props) {
    const [input, setInput] = useState<GameInput>(() => game ?? (preset ? fromPreset(preset, eggs) : blank(eggs)));
    const [portNames, setPortNames] = useState(input.port_variables.join(', '));
    const [term, setTerm] = useState('');
    const steam = useQuery({ queryKey: keys.steam(term), queryFn: () => searchSteam(term), enabled: term.trim().length >= 2 });
    const set = (changes: Partial<GameInput>) => setInput((current) => ({ ...current, ...changes }));
    const egg = eggs.find((item) => item.id === input.egg_id);
    const artwork = input.image || (input.steam_app_id ? `https://cdn.cloudflare.steamstatic.com/steam/apps/${input.steam_app_id}/header.jpg` : null);
    const valid = input.name.trim() !== '' && ((input.egg_id ?? 0) > 0 || !!input.catalog_id) && RANGES.every(({ key }) => input[`${key}_min`] <= input[`${key}_max`]);
    const eggOptions = [
        ...(preset && preset.egg_id === null ? [{ value: `${CATALOG}${preset.catalog_id}`, label: `${preset.catalog_egg} (import from the egg catalog)` }] : []),
        ...eggs.map((item) => ({ value: item.id, label: item.name })),
    ];

    return (
        <Dialog open onClose={onClose} title={game ? `Edit ${game.name}` : preset ? `Add ${preset.name}` : 'Add a game'} preventExternalClose={pending}>
            <div className='vz:grid vz:gap-4'>
                <div className='vz:grid vz:gap-4 vz:sm:grid-cols-[minmax(0,1fr)_10rem]'>
                    <div className='vz:grid vz:content-start vz:gap-4'>
                        <div>
                            <Label htmlFor='srvc-egg'>Egg</Label>
                            <Select
                                id='srvc-egg'
                                value={input.egg_id ?? `${CATALOG}${input.catalog_id}`}
                                onChange={(value) =>
                                    String(value).startsWith(CATALOG) ? set({ egg_id: null, catalog_id: String(value).slice(CATALOG.length), docker_image: null }) : set({ egg_id: Number(value), catalog_id: null, docker_image: null })
                                }
                                options={eggOptions}
                            />
                        </div>
                        <div>
                            <Label htmlFor='srvc-game-name'>Name</Label>
                            <Input id='srvc-game-name' value={input.name} maxLength={191} onChange={(event) => set({ name: event.currentTarget.value })} />
                        </div>
                    </div>
                    <Artwork src={artwork} name={input.name || 'No artwork'} className='vz:self-end' />
                </div>
                <div>
                    <Label htmlFor='srvc-description'>Description</Label>
                    <Input id='srvc-description' value={input.description ?? ''} maxLength={1000} onChange={(event) => set({ description: event.currentTarget.value || null })} />
                </div>
                <div className='vz:grid vz:gap-4 vz:sm:grid-cols-2'>
                    <div>
                        <Label htmlFor='srvc-steam'>Steam artwork</Label>
                        <Select
                            id='srvc-steam'
                            placeholder={input.steam_app_id ? `App ${input.steam_app_id}` : 'Search Steam'}
                            searchPlaceholder='Game name'
                            value={input.steam_app_id}
                            onSearchChange={setTerm}
                            onChange={(value) => {
                                const result = steam.data?.find((item) => item.id === Number(value));
                                set({ steam_app_id: Number(value) || null, name: input.name || result?.name || '' });
                            }}
                            options={(steam.data ?? []).map((item) => ({ value: item.id, label: item.name }))}
                        />
                    </div>
                    <div>
                        <Label htmlFor='srvc-image'>Or an image URL</Label>
                        <Input id='srvc-image' type='url' placeholder='https://…' value={input.image ?? ''} onChange={(event) => set({ image: event.currentTarget.value || null })} />
                    </div>
                </div>
                {egg && egg.images.length > 1 && (
                    <div>
                        <Label htmlFor='srvc-docker'>Docker image</Label>
                        <Select id='srvc-docker' placeholder='Egg default' value={input.docker_image} onChange={(value) => set({ docker_image: String(value) || null })} options={egg.images.map((image) => ({ value: image, label: image }))} />
                    </div>
                )}
                <div className='vz:grid vz:gap-4 vz:sm:grid-cols-3'>
                    {RANGES.map(({ key, label }) => (
                        <div key={key} className='vz:grid vz:gap-2'>
                            <Label htmlFor={`srvc-${key}-min`}>{label}</Label>
                            <div className='vz:flex vz:items-center vz:gap-2'>
                                <Input id={`srvc-${key}-min`} aria-label={`${label} minimum`} type='number' min={0} value={input[`${key}_min`]} onChange={(event) => set({ [`${key}_min`]: Number(event.currentTarget.value) })} />
                                <span className='vz:text-muted-foreground'>–</span>
                                <Input aria-label={`${label} maximum`} type='number' min={0} value={input[`${key}_max`]} onChange={(event) => set({ [`${key}_max`]: Number(event.currentTarget.value) })} />
                            </div>
                            <p className={`vz:text-xs ${input[`${key}_min`] > input[`${key}_max`] ? 'vz:text-destructive' : 'vz:text-muted-foreground'}`}>
                                {formatSize(key, input[`${key}_min`])} to {formatSize(key, input[`${key}_max`])}
                            </p>
                        </div>
                    ))}
                </div>
                <div className='vz:grid vz:grid-cols-3 vz:gap-4'>
                    {FEATURES.map(({ key, label }) => (
                        <div key={key}>
                            <Label htmlFor={`srvc-${key}`}>{label}</Label>
                            <Input id={`srvc-${key}`} type='number' min={0} max={100} value={input[key]} onChange={(event) => set({ [key]: Number(event.currentTarget.value) })} />
                        </div>
                    ))}
                </div>
                <div className='vz:grid vz:gap-2'>
                    <div className='vz:grid vz:gap-4 vz:sm:grid-cols-[10rem_minmax(0,1fr)]'>
                        <div>
                            <Label htmlFor='srvc-ports'>Ports in a row</Label>
                            <Input id='srvc-ports' type='number' min={1} max={10} value={input.ports} onChange={(event) => set({ ports: Number(event.currentTarget.value) })} />
                        </div>
                        <div>
                            <Label htmlFor='srvc-port-variables'>Variables for the extra ports</Label>
                            <Input
                                id='srvc-port-variables'
                                placeholder='QUERY_PORT, RCON_PORT'
                                disabled={input.ports < 2}
                                value={portNames}
                                onChange={(event) => {
                                    setPortNames(event.currentTarget.value);
                                    set({ port_variables: event.currentTarget.value.split(/[\s,]+/).filter(Boolean) });
                                }}
                            />
                        </div>
                    </div>
                    <p className='vz:text-xs vz:text-muted-foreground'>For games that need more than one port. The second, third and so on go into these egg variables, in order.</p>
                </div>
                <div className='vz:grid vz:gap-2'>
                    <div>
                        <Label htmlFor='srvc-port-range'>Port range</Label>
                        <Input id='srvc-port-range' placeholder='25565-25600' maxLength={191} value={input.port_range ?? ''} onChange={(event) => set({ port_range: event.currentTarget.value || null })} />
                    </div>
                    <p className='vz:text-xs vz:text-muted-foreground'>Servers of this game only get ports from these ports and ranges, separated by commas, also after a switch or egg change. Empty for any free port.</p>
                </div>
                <label className='vz:flex vz:items-center vz:justify-between vz:gap-3 vz:text-sm'>
                    <span>Users can pick this game</span>
                    <Switch aria-label='Enabled' checked={input.enabled} onChange={() => set({ enabled: !input.enabled })} />
                </label>
            </div>
            <Dialog.Footer>
                <Button.Text className='vz:w-full vz:sm:w-auto' disabled={pending} onClick={onClose}>
                    Cancel
                </Button.Text>
                <Button className='vz:w-full vz:sm:w-auto' disabled={!valid} isLoading={pending} onClick={() => onSave(input)}>
                    Save
                </Button>
            </Dialog.Footer>
        </Dialog>
    );
}
