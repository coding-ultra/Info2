import { useState } from 'react';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { Button, Checkbox, Dialog, Switch, TitledGreyBox, httpErrorToHuman, invalidateServerData, toast, useServerResources } from '@pterodactyl/sdk';
import { keys, switchGame, type Game, type OwnedServer } from '../api';
import { SIZED, range, shortfall } from '../lib/games';
import { clamp, type Sized } from '../lib/resources';
import Artwork from './Artwork';
import ResourceSlider from './ResourceSlider';

interface Props {
    identifier: string;
    uuid: string;
    data: OwnedServer;
}

export default function GameBox({ identifier, uuid, data }: Props) {
    const [open, setOpen] = useState(false);
    const state = useServerResources(uuid, (resources) => resources.attributes.current_state).data;
    const stopped = state === 'offline' || state === 'stopped';
    const games = data.games ?? [];

    return (
        <TitledGreyBox title='Game'>
            <div className='vz:flex vz:flex-col vz:gap-4 vz:sm:flex-row vz:sm:items-center'>
                <Artwork src={data.artwork ?? null} name={data.game ?? 'No game'} className='vz:w-full vz:shrink-0 vz:sm:w-40' />
                <div className='vz:min-w-0 vz:flex-1'>
                    <p className='vz:font-medium vz:text-foreground'>{data.game ?? 'No game'}</p>
                    <p className='vz:mt-1 vz:text-sm vz:text-muted-foreground'>
                        {data.allow_switch && games.length > 0 ? 'Switch to another game. The server takes on its egg, limits and ports.' : 'The game this server was created for.'}
                    </p>
                </div>
            </div>
            {data.allow_switch && games.length > 0 && (
                <div className='vz:mt-4 vz:flex vz:flex-col vz:items-end vz:gap-2'>
                    <Button size='small' className='vz:w-full vz:sm:w-auto' disabled={!stopped} onClick={() => setOpen(true)}>
                        Switch game
                    </Button>
                    {!stopped && <p className='vz:text-xs vz:text-warning'>Stop the server to switch its game.</p>}
                </div>
            )}
            {open && <SwitchDialog identifier={identifier} data={data} games={games} onClose={() => setOpen(false)} />}
        </TitledGreyBox>
    );
}

function SwitchDialog({ identifier, data, games, onClose }: { identifier: string; data: OwnedServer; games: Game[]; onClose: () => void }) {
    const queryClient = useQueryClient();
    const remaining = data.remaining!;
    const [game, setGame] = useState<Game | null>(null);
    const [sizes, setSizes] = useState<Record<Sized, number>>({ memory: 0, disk: 0, cpu: 0 });
    const [keepVariables, setKeepVariables] = useState(true);
    const [reinstall, setReinstall] = useState(true);

    const switching = useMutation({
        mutationFn: () => switchGame(identifier, { game: game!.id, ...sizes, keep_variables: keepVariables, reinstall }),
        onSuccess: (fresh) => {
            queryClient.setQueryData(keys.server(identifier), fresh);
            invalidateServerData(identifier, ['server', 'startup']);
            toast.success(reinstall ? `Switched to ${game!.name}. The server is reinstalling.` : `Switched to ${game!.name}.`);
            onClose();
        },
        onError: (error) => toast.error(httpErrorToHuman(error)),
    });

    const pick = (picked: Game) => {
        setGame(picked);
        setSizes(Object.fromEntries(SIZED.map(({ key }) => [key, clamp(data.current![key], range(picked, remaining, key).min, range(picked, remaining, key).max)])) as Record<Sized, number>);
    };

    const valid = game !== null && SIZED.every(({ key }) => sizes[key] >= range(game, remaining, key).min && sizes[key] <= range(game, remaining, key).max);

    return (
        <Dialog open onClose={onClose} title='Switch game' preventExternalClose={switching.isPending}>
            <div className='vz:grid vz:gap-5'>
                <div className='vz:grid vz:grid-cols-2 vz:gap-2 vz:sm:grid-cols-4'>
                    {games.map((item) => {
                        const blocked = shortfall(item, remaining);
                        const selected = game?.id === item.id;

                        return (
                            <button
                                key={item.id}
                                type='button'
                                disabled={blocked !== null}
                                aria-pressed={selected}
                                onClick={() => pick(item)}
                                className={`vz:flex vz:min-w-0 vz:flex-col vz:gap-1.5 vz:rounded-sm vz:border-2 vz:bg-card vz:p-1.5 vz:text-left vz:transition-colors vz:disabled:cursor-not-allowed vz:disabled:opacity-50 ${selected ? 'vz:border-primary' : 'vz:border-transparent vz:enabled:hover:border-border'}`}
                            >
                                <Artwork src={item.artwork} name={item.name} />
                                <span className='vz:line-clamp-1 vz:break-words vz:text-sm vz:font-medium vz:text-foreground'>{item.name}</span>
                                {blocked && <span className='vz:line-clamp-1 vz:text-xs vz:text-muted-foreground'>{blocked}</span>}
                            </button>
                        );
                    })}
                </div>
                {game && (
                    <>
                        <div className='vz:grid vz:gap-6'>
                            {SIZED.map(({ key, label }) => {
                                const { min, max } = range(game, remaining, key);

                                return (
                                    <ResourceSlider
                                        key={`${game.id}-${key}`}
                                        id={`srvc-switch-${key}`}
                                        resource={key}
                                        label={label}
                                        value={sizes[key]}
                                        min={min}
                                        max={max}
                                        onChange={(value) => setSizes((current) => ({ ...current, [key]: value }))}
                                        quota={data.quota?.[key]}
                                        suggest
                                    />
                                );
                            })}
                        </div>
                        <div className='vz:grid vz:gap-3'>
                            <Switch label='Keep variable values' description='Values the new egg still accepts are kept; everything else goes back to its default.' checked={keepVariables} onChange={setKeepVariables} />
                            <label className='vz:flex vz:items-center vz:gap-2 vz:text-sm'>
                                <Checkbox checked={reinstall} onChange={setReinstall} />
                                Reinstall afterwards, so the new game installs its files
                            </label>
                        </div>
                        <p className='vz:text-xs vz:text-muted-foreground'>
                            The startup command and Docker image are reset for {game.name}.
                            {(game.port_range || game.ports > 1) &&
                                ` The server moves to ${game.ports > 1 ? `${game.ports} free ports in a row` : 'a free port'}${game.port_range ? ` in ${game.port_range}` : ''} unless its own already fit.`}
                            {reinstall && ' The install script runs afterwards and can overwrite files.'}
                        </p>
                    </>
                )}
            </div>
            <Dialog.Footer>
                <Button.Text className='vz:w-full vz:sm:w-auto' disabled={switching.isPending} onClick={onClose}>
                    Cancel
                </Button.Text>
                <Button className='vz:w-full vz:sm:w-auto' disabled={!valid} isLoading={switching.isPending} onClick={() => switching.mutate()}>
                    Switch game
                </Button>
            </Dialog.Footer>
        </Dialog>
    );
}
