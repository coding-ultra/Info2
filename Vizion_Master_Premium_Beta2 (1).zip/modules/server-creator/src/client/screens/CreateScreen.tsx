import { useRef, useState } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { Button, Input, Label, PageContentBlock, Spinner, TitledGreyBox, httpErrorToHuman, toast, usePanelNavigate } from '@pterodactyl/sdk';
import { createServer, getOverview, keys, type Game, type Limits } from '../api';
import Artwork from '../components/Artwork';
import ResourceSlider from '../components/ResourceSlider';
import { remainingText } from '../lib/format';
import { SIZED, range, shortfall } from '../lib/games';
import { formatSize, type Sized } from '../lib/resources';

export default function CreateScreen() {
    const navigate = usePanelNavigate();
    const queryClient = useQueryClient();
    const overview = useQuery({ queryKey: keys.overview, queryFn: getOverview });
    const [game, setGame] = useState<Game | null>(null);
    const [name, setName] = useState('');
    const [sizes, setSizes] = useState<Record<Sized, number>>({ memory: 0, disk: 0, cpu: 0 });
    const [environment, setEnvironment] = useState<Record<string, string>>({});
    const setup = useRef<HTMLElement>(null);

    const creation = useMutation({
        mutationFn: () => createServer({ game: game!.id, name: name.trim(), ...sizes, environment }),
        onSuccess: ({ identifier }) => {
            toast.success('Server created. It is being installed now.');
            queryClient.invalidateQueries({ queryKey: keys.overview });
            navigate({ to: '/server/$id', params: { id: identifier } });
        },
        onError: (error) => toast.error(httpErrorToHuman(error)),
    });

    const pick = (picked: Game, remaining: Limits) => {
        setGame(picked);
        setName((current) => (current === '' || current === game?.name ? picked.name : current));
        setSizes({ memory: range(picked, remaining, 'memory').min, disk: range(picked, remaining, 'disk').min, cpu: range(picked, remaining, 'cpu').min });
        setEnvironment(Object.fromEntries((picked.variables ?? []).map((variable) => [variable.key, variable.default])));
        // On phones the setup step starts below the game list, so bring it into view.
        requestAnimationFrame(() => {
            const top = setup.current?.getBoundingClientRect().top;
            top !== undefined && top > window.innerHeight * 0.75 && setup.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });
        });
    };

    if (!overview.data) {
        return (
            <PageContentBlock title='Create server'>
                {overview.isError ? <p className='vz:text-sm vz:text-destructive'>{httpErrorToHuman(overview.error)}</p> : <Spinner centered size={Spinner.Size.LARGE} />}
            </PageContentBlock>
        );
    }

    const { remaining, limits } = overview.data.quota;
    const valid = game !== null && name.trim() !== '' && SIZED.every(({ key }) => sizes[key] >= range(game, remaining, key).min && sizes[key] <= range(game, remaining, key).max);

    return (
        <PageContentBlock title='Create server'>
            <header className='vz:mb-6'>
                <h1 className='vz:font-header vz:text-2xl vz:font-semibold vz:text-foreground'>Create a server</h1>
                <p className='vz:mt-1 vz:text-sm vz:leading-relaxed vz:text-foreground/70'>{remainingText(remaining)}</p>
            </header>

            {overview.data.games.length === 0 || remaining.servers < 1 ? (
                <p className='vz:py-8 vz:text-center vz:text-sm vz:text-muted-foreground'>{remaining.servers < 1 ? 'Delete a server or ask an administrator for a higher limit.' : 'There are no games to choose from yet.'}</p>
            ) : (
                <div className='vz:grid vz:gap-6'>
                    <section>
                        <h2 className='vz:mb-3 vz:font-header vz:text-sm vz:font-semibold vz:uppercase vz:tracking-wide vz:text-foreground'>1. Pick a game</h2>
                        <div className='vz:grid vz:grid-cols-2 vz:gap-3 vz:sm:gap-4 vz:lg:grid-cols-4'>
                            {overview.data.games.map((item) => {
                                const blocked = shortfall(item, remaining);
                                const selected = game?.id === item.id;

                                return (
                                    <button
                                        key={item.id}
                                        type='button'
                                        disabled={blocked !== null}
                                        aria-pressed={selected}
                                        onClick={() => pick(item, remaining)}
                                        className={`vz:flex vz:min-w-0 vz:flex-col vz:gap-2 vz:rounded-sm vz:border-2 vz:bg-card vz:p-2 vz:text-left vz:sm:gap-3 vz:sm:p-3 vz:transition-colors vz:disabled:cursor-not-allowed vz:disabled:opacity-50 ${selected ? 'vz:border-primary' : 'vz:border-transparent vz:enabled:hover:border-border'}`}
                                    >
                                        <Artwork src={item.artwork} name={item.name} />
                                        <div className='vz:min-w-0'>
                                            <p className='vz:line-clamp-2 vz:break-words vz:font-medium vz:text-foreground'>{item.name}</p>
                                            <p className='vz:line-clamp-2 vz:text-xs vz:text-muted-foreground'>{blocked ?? item.description ?? `${formatSize('memory', item.memory_min)} to ${formatSize('memory', item.memory_max)} memory`}</p>
                                        </div>
                                    </button>
                                );
                            })}
                        </div>
                    </section>

                    {game && (
                        <section ref={setup} className='vz:scroll-mt-4'>
                            <h2 className='vz:mb-3 vz:font-header vz:text-sm vz:font-semibold vz:uppercase vz:tracking-wide vz:text-foreground'>2. Set it up</h2>
                            <form
                                className='vz:grid vz:gap-6 vz:lg:grid-cols-2'
                                onSubmit={(event) => {
                                    event.preventDefault();
                                    valid && creation.mutate();
                                }}
                            >
                                <TitledGreyBox title='Server'>
                                    <div className='vz:grid vz:gap-6'>
                                        <div>
                                            <Label htmlFor='srvc-name'>Name</Label>
                                            <Input id='srvc-name' maxLength={191} value={name} onChange={(event) => setName(event.currentTarget.value)} />
                                        </div>
                                        {SIZED.map(({ key, label }) => {
                                            const { min, max } = range(game, remaining, key);

                                            return (
                                                <ResourceSlider
                                                    key={`${game.id}-${key}`}
                                                    id={`srvc-${key}`}
                                                    resource={key}
                                                    label={label}
                                                    value={sizes[key]}
                                                    min={min}
                                                    max={max}
                                                    onChange={(value) => setSizes((current) => ({ ...current, [key]: value }))}
                                                    quota={{ available: remaining[key], limit: limits[key] }}
                                                    suggest
                                                />
                                            );
                                        })}
                                    </div>
                                </TitledGreyBox>
                                <TitledGreyBox title='Settings' className='vz:flex vz:flex-col' contentClassName='vz:flex vz:flex-1 vz:flex-col vz:gap-6'>
                                    <div className='vz:grid vz:gap-4'>
                                        {(game.variables ?? []).length === 0 && <p className='vz:text-sm vz:text-muted-foreground'>Nothing to set up. You can change startup settings later.</p>}
                                        {(game.variables ?? []).map((variable) => (
                                            <div key={variable.key}>
                                                <Label htmlFor={`srvc-var-${variable.key}`}>
                                                    {variable.name}
                                                    {variable.required && ' *'}
                                                </Label>
                                                <Input id={`srvc-var-${variable.key}`} value={environment[variable.key] ?? ''} onChange={(event) => setEnvironment({ ...environment, [variable.key]: event.currentTarget.value })} />
                                                {variable.description && <p className='vz:mt-1 vz:text-xs vz:break-words vz:text-muted-foreground'>{variable.description}</p>}
                                            </div>
                                        ))}
                                    </div>
                                    <div className='vz:mt-auto vz:flex vz:justify-end'>
                                        <Button type='submit' className='vz:w-full vz:sm:w-auto' disabled={!valid} isLoading={creation.isPending}>
                                            Create server
                                        </Button>
                                    </div>
                                </TitledGreyBox>
                            </form>
                        </section>
                    )}
                </div>
            )}
        </PageContentBlock>
    );
}
