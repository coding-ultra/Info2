<?php

declare(strict_types=1);

namespace EggChanger;

use Vizion\Support\ModuleProvider;

class EggChangerProvider extends ModuleProvider
{
    public function boot(): void
    {
        $this->registerApiRoutes();
        $this->loadExtensionMigrations();

        $this->registerPermissions('Egg changer.', [
            'change' => 'Switch the server to another egg the administrator allows.',
        ]);
    }
}
