import { useQuery } from '@tanstack/react-query';
import { Badge, CopyOnClick, PageContentBlock, PanelLink, Spinner, TitledGreyBox, httpErrorToHuman } from '@pterodactyl/sdk';
import { getTools, keys, type ToolInfo } from '../api';

function Code({ children }: { children: string }) {
    return (
        <CopyOnClick text={children}>
            <pre className='vz:rounded-sm vz:bg-terminal vz:px-4 vz:py-3 vz:font-mono vz:text-sm vz:break-all vz:whitespace-pre-wrap vz:text-terminal-foreground'>{children}</pre>
        </CopyOnClick>
    );
}

function KindBadge({ tool }: { tool: ToolInfo }) {
    if (tool.kind === 'destroy') return <Badge tone='danger' size='sm'>Destructive</Badge>;
    if (tool.kind === 'write') return <Badge tone='warning' size='sm'>Changes</Badge>;
    if (tool.kind === 'control') return <Badge tone='info' size='sm'>Control</Badge>;
    return null;
}

function groupTools(tools: ToolInfo[]): [string, ToolInfo[]][] {
    const groups = new Map<string, ToolInfo[]>();
    for (const tool of tools) groups.set(tool.group, [...(groups.get(tool.group) ?? []), tool]);

    return [...groups.entries()];
}

function Tools() {
    const catalog = useQuery({ queryKey: keys.tools, queryFn: getTools });

    if (catalog.isLoading) return <Spinner centered />;
    if (catalog.isError) return <p className='vz:text-sm vz:text-destructive'>{httpErrorToHuman(catalog.error)}</p>;
    if (!catalog.data!.enabled) return <p className='vz:text-sm vz:text-muted-foreground'>An administrator turned MCP off.</p>;

    return (
        <div className='vz:grid vz:gap-5'>
            {groupTools(catalog.data!.tools).map(([group, tools]) => (
                <section key={group}>
                    <h3 className='vz:mb-2 vz:text-xs vz:uppercase vz:text-muted-foreground'>{group}</h3>
                    <ul className='vz:grid vz:gap-2 vz:sm:grid-cols-2'>
                        {tools.map((tool) => (
                            <li key={tool.name} className='vz:rounded-sm vz:border vz:border-border vz:p-3'>
                                <p className='vz:flex vz:items-center vz:gap-2 vz:font-mono vz:text-sm vz:text-foreground'>
                                    {tool.name}
                                    <KindBadge tool={tool} />
                                </p>
                                <p className='vz:mt-1 vz:text-xs vz:text-muted-foreground'>{tool.description}</p>
                            </li>
                        ))}
                    </ul>
                </section>
            ))}
        </div>
    );
}

export default function McpScreen() {
    const url = `${window.location.origin}/api/client/extensions/vizion/mcp`;
    const json = JSON.stringify({ mcpServers: { pterodactyl: { type: 'http', url, headers: { Authorization: 'Bearer ptlc_YOUR_KEY' }, timeout: 120000 } } }, null, 2);

    return (
        <PageContentBlock title='MCP'>
            <div className='vz:grid vz:gap-6'>
                <TitledGreyBox title='Connect an AI assistant'>
                    <ol className='vz:grid vz:list-decimal vz:gap-3 vz:pl-5 vz:text-sm'>
                        <li>
                            Create an API key under{' '}
                            <PanelLink destination={{ to: '/account/api' }} className='vz:text-primary vz:underline'>
                                API Credentials
                            </PanelLink>
                            . Limit it to your computer's IP address if you can.
                        </li>
                        <li>Add the server below to your assistant and replace the key.</li>
                        <li>Ask it something like "Restart my survival server and show me the console".</li>
                    </ol>
                    <p className='vz:mt-4 vz:mb-1 vz:text-xs vz:uppercase vz:text-muted-foreground'>Endpoint</p>
                    <Code>{url}</Code>
                </TitledGreyBox>
                <TitledGreyBox title='Claude Code'>
                    <Code>{`claude mcp add --transport http pterodactyl ${url} --header "Authorization: Bearer ptlc_YOUR_KEY"`}</Code>
                </TitledGreyBox>
                <TitledGreyBox title='Cursor, VS Code, Claude Desktop and others'>
                    <p className='vz:mb-2 vz:text-sm vz:text-muted-foreground'>
                        Add this to the MCP settings of your app. Waiting for a restart or a backup can take up to a minute, so allow long requests. Apps that only connect with an OAuth login are not supported.
                    </p>
                    <Code>{json}</Code>
                </TitledGreyBox>
                <TitledGreyBox title='Tools'>
                    <p className='vz:mb-4 vz:text-sm vz:text-muted-foreground'>The assistant acts as you, so it can only use what your server permissions allow.</p>
                    <Tools />
                </TitledGreyBox>
            </div>
        </PageContentBlock>
    );
}
