<?php

namespace McVersion;

use Vizion\Support\ModuleProvider;

class McVersionProvider extends ModuleProvider
{
    public function boot(): void
    {
        // Loads routes/server.php at /api/client/servers/{server}/extensions/vizion/mc-version.
        // The page uses the panel's own file, startup and Docker image permissions,
        // so there are no extension permissions to register.
        $this->registerApiRoutes();
    }
}
