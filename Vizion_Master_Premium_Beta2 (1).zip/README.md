# Vizion Premium Master (Pterodactyl 2.0.0-beta.2)

One extension, id `vizion`, containing the 24 modules that used to be separate extensions. The Premium
Compact UI (compact module grid, cards, dark theme) is kept; each module opens its real
configuration, has its own ON/OFF switch, and **MCP is OFF by default**.

> **Compatibility note.** Panel `2.0.0-beta.2` ships Extension SDK `2.0.0-beta.6` (see the Panel's
> CHANGELOG). The manifest therefore requires `sdk: ^2.0.0-beta.6`, which is what the Panel provides.

## What is in it

`docs/MODULES.md` lists all 24 modules with their permissions, route files, migrations and screens.
`docs/ROUTES.md` lists the backend routes. `docs/CHANGES.md` lists what changed versus your previous package.
`docs/VERIFICATION.md` says exactly what was checked and what was **not**.

## How it works (short)

* Each module's provider now extends `Vizion\Support\ModuleProvider`; `VizionServiceProvider` creates them the
  way the Panel's loader does (`new Provider($app, $manifest)`, begin, register, commit). The previous package
  used `$app->register($class)`, which makes every child provider throw and silently not load.
* Settings: one merged definition in the Panel's native settings registry. Keys are prefixed per module
  (`mc_players__bans_enabled`); module code is unchanged because `ScopedSettings` adds/strips the prefix.
* Uploads, saving and validation use the Panel's native endpoints for `vizion`
  (`GET|PATCH /api/admin/extensions/vizion/settings`, `POST|DELETE …/settings/{input}/file`).
* Module routes live under `…/extensions/vizion/<module>/…`; permissions are `ext.vizion.<module>-<action>`.
* ON/OFF is the boolean setting `<module>__vz_enabled`. OFF = nothing of the module is registered (routes,
  schedules, commands, listeners, head tags, frontend slots/forms) and its routes answer 404; settings, data
  and permissions are kept.

## Not verified (read this)

Nothing here has been executed on a Panel. The environment it was written in had no PHP, no network and no
`node_modules`, so `php -l`, `tsc`, `vite build` and a live test were **not** run. See `docs/VERIFICATION.md`
for the static checks that were run. Run the steps in `INSTALL.md` on a staging panel first.
