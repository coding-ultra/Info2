# Vizion modules (24 of 24)

Generated from the final tree. *Settings* counts `ScopedDefinition::make(...)` call sites; a few modules build fields in loops, so the live number can be higher (the Vizion panel always shows the real list).

| # | Module | id | Source version | Default | Settings | Permissions (`ext.vizion.<id>-<key>`) | Route files | Migrations | Screens |
|---|---|---|---|---|---|---|---|---|---|
| 1 | Branding | `branding` | 1.1.0 | ON | 6 | – | – | 0 | – |
| 2 | Demo Account | `demo` | 1.0.0 | ON | 3 | – | web.php | 0 | – |
| 3 | Drift Mod | `drift-mod` | 1.1.0 | ON | 10 | – | admin.php, server.php | 0 | server:main, admin:admin |
| 4 | Drift Plugins | `drift-plugins` | 1.5.0 | ON | 12 | – | admin.php, server.php | 0 | admin:config, server:main, server:manager |
| 5 | Drift Properties | `drift-properties` | 1.0.0 | ON | 6 | – | admin.php | 0 | server:main, admin:admin |
| 6 | Drift Register | `drift-register` | 1.6.1 | ON | 12 | – | admin.php, authenticated.php, client.php, root.php, web.php | 8 | admin:config, admin:user |
| 7 | Egg Changer | `egg-changer` | 1.1.1 | ON | 0 | `egg-changer-change` | admin.php, server.php | 2 | admin:groups |
| 8 | Minecraft Console | `mc-console` | 1.1.0 | ON | 0 | `mc-console-suggestions` | server.php | 0 | – |
| 9 | Minecraft Players | `mc-players` | 1.4.1 | ON | 5 | `mc-players-ban`, `mc-players-kick`, `mc-players-op`, `mc-players-view`, `mc-players-whitelist` | client.php, server.php | 0 | server:player |
| 10 | Minecraft Version | `mc-version` | 1.0.0 | ON | 0 | – | server.php | 0 | server:version |
| 11 | Minecraft World | `mc-world` | 1.0.0 | ON | 1 | – | server.php | 0 | server:world |
| 12 | MCP | `mcp` | 1.1.0 | **OFF** | 5 | – | client.php | 0 | account:mcp |
| 13 | Monitoring | `monitoring` | 1.1.1 | ON | 3 | `monitoring-manage`, `monitoring-read` | admin.php, client.php, server.php | 1 | server:server, account:alerts, admin:admin, admin:server-tab |
| 14 | Node Resources | `node-resources` | 1.0.0 | ON | 3 | `node-resources-history` | admin.php, server.php | 4 | admin:overview, admin:node |
| 15 | Palworld Tools | `palworld-tools` | 1.0.0 | ON | 1 | `palworld-tools-players`, `palworld-tools-saves`, `palworld-tools-settings`, `palworld-tools-view` | server.php | 1 | server:settings, server:saves |
| 16 | Server Creator | `server-creator` | 1.4.0 | ON | 3 | – | admin.php, client.php, server.php | 3 | account:create, server:resources, admin:admin, admin:user-tab |
| 17 | Server Expiry | `server-expiry` | 1.1 | ON | 0 | – | admin.php, application.php, client.php, server.php | 1 | – |
| 18 | Server Groups | `server-groups` | 1.0.1 | ON | 0 | – | admin.php, client.php | 1 | account:groups, admin:admin |
| 19 | Server Splitter | `server-splitter` | 1.0.0 | ON | 0 | `server-splitter-manage`, `server-splitter-read` | admin.php, server.php | 1 | server:split, admin:settings |
| 20 | Single Sign-On | `sso` | 1.2.0 | ON | 4 | – | account.php, client.php, web.php | 1 | account:connections |
| 21 | Subdomains | `subdomains` | 1.2.2 | ON | 5 | `subdomains-create`, `subdomains-delete`, `subdomains-manage`, `subdomains-read`, `subdomains-update` | admin.php, server.php | 3 | server:subdomains, admin:admin, admin:server-tab, admin:egg-tab |
| 22 | Terraria Tools | `terraria-tools` | 1.0.1 | ON | 1 | `terraria-tools-admin`, `terraria-tools-ban`, `terraria-tools-kick`, `terraria-tools-view`, `terraria-tools-worlds` | server.php | 0 | server:worlds, server:settings |
| 23 | Valheim Tools | `valheim-tools` | 1.0.0 | ON | 2 | `valheim-tools-lists`, `valheim-tools-mods`, `valheim-tools-players`, `valheim-tools-settings`, `valheim-tools-view`, `valheim-tools-worlds` | server.php | 1 | server:lists, server:worlds, server:mods |
| 24 | Votifier Tester | `votifier-tester` | 2.0.0 | ON | 4 | `votifier-tester-send` | server.php | 0 | server:votifier |

Source folders: `branding-1.1.0`, `demo`, `drift-mod`, `drift-plugins`, `drift-properties`, `drift-register`, `egg-changer-1.1.1`, `mc-console-1.1.0`, `mc-players-1.4.1`, `mc-version-1.0.0`, `mc-world-1.0.0`, `mcp-1.1.0`, `monitoring-1.1.1`, `node-resources-1.0.0`, `palworld-tools-1.0.0`, `server-creator-1.4.0`, `server-expiry-1.1`, `server-groups-1.0.1`, `server-splitter-1.0.0`, `sso-1.2.0`, `subdomains-1.2.2`, `terraria-tools-1.0.1`, `valheim-tools-1.0.0`, `votifier-tester-2.0.0`.

`branding:settings` (a stand-alone settings page) is the only original screen not carried over; Vizion's own module panel edits the same fields through the Panel's native settings API.
