# Verification record

Everything below is a **static** check run on the final tree. Nothing was executed on a Panel.

## Checks that were run, and their results

| Check | How | Result |
|---|---|---|
| `extension.json` against the SDK schema | the SDK's `manifest.schema.json`, with a small validator that was first shown to pass an original manifest and fail two deliberately broken fields | 0 errors |
| Panel's semantic manifest rules | read `ExtensionManifestValidator` / `ExtensionManifest`: id regex and reserved ids, icon-file regex (`resources/icon.png`), namespace format, `ui.entry`, `ui.mode`, `when.runtime`, screen path rules | satisfied; 42 screens (limit 64), unique ids, longest 24 chars |
| Exactly one root `extension.json` | `find` | 1 |
| 24 modules registered | `resources/modules.json` ↔ autoload map ↔ provider file ↔ `extends ModuleProvider` | 24/24 |
| `ModuleProvider` vs the real `ExtensionProvider` | mechanical signature comparison (visibility, parameters, return types, `final`) | 20 overrides compatible, 0 incompatible |
| PHP structure | tokenizer-style checker (strings, comments, heredocs; brackets balanced; open tag). The same checker reports only the same 2 Blade templates on the untouched originals | 583 PHP files clean |
| TypeScript/TSX/JS syntax | TypeScript's own parser on every file | 236 files, 0 errors |
| SDK imports | every named import from `@pterodactyl/sdk` against the exports of the SDK `types/index.d.ts` | 830 imports, 68 names, 0 missing |
| Relative imports | resolved on disk | 457 resolved, 0 missing |
| Endpoints ↔ routes | every route file a provider mounts has a generated wrapper; every client URL (49) lands in an area and path segment its module routes | 0 unmatched |
| Screens | the 41 module screens registered at runtime vs declared in the manifest | identical sets |
| Permissions | every `ext.vizion.<module>-<key>` used in code/manifest vs the keys the module registers; dynamically built names (`'ext.x.'.$p`) found and rewritten | consistent |
| Settings contract | `ScopedDefinition::make` matches `ExtensionSettingDefinition::make(key, input, default, rules, public)`; `ScopedSettings` overrides only public methods of `ExtensionSettings`; `ModuleSettingsView` extends the non-final `ExtensionSettingsDefinition` | matches Panel source |
| Leftovers of the old scheme | grep for raw `make(`, old permission strings, un-namespaced URLs, old Tailwind prefixes, registry reads | none |
| JSON files | parsed | 33 valid |

## NOT verified

* `php -l` / any PHP execution (no PHP binary was available). The structure checker is not a PHP parser.
* `npm run typecheck` (`tsc`): React/SDK type packages were not available, so only syntax and SDK export names
  were checked, not types.
* `vite build`, the generated CSS (and therefore `p:extension:doctor`'s CSS-prefix check), and the final `dist/`.
* Any runtime behaviour: module boot, settings read/write, uploads, ON/OFF, routes, permissions, UI rendering.
* The `when.runtime` + `visible` mechanism for hiding a disabled module's screens (written from the SDK types).
* `Reflection` access to the private `definitions` list of `ExtensionSettingsDefinition` (used by `ModuleCollector`);
  it works on the supplied Panel source but is not a public API.
* Heroicons component names (`@heroicons/react/24/outline`): chosen from knowledge of the package, not resolved offline.

## Suggested order on a staging panel

`npm run typecheck` → `npm run build` → `php artisan p:extension:doctor .` → install → open Admin → Vizion →
toggle one module and save one setting → upload a Branding logo and favicon → reload.
