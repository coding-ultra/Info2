# Changes versus `Vizion_beta2_premium_compact_update.zip`

## Fixed (root causes)

| Reported problem | Cause found in the old package | Fix |
|---|---|---|
| Settings API 404 | Module screens called `/api/admin/extensions/<module>/settings`; only `vizion` exists as an extension id | One native settings definition for `vizion`; UI calls `/api/admin/extensions/vizion/settings` |
| Logo / favicon upload 404 | Bundle posted to `/modules/branding/upload`; no such route | Native `POST/DELETE …/settings/{input}/file` (multipart `file`), as the original Branding did |
| Save 422 | Bundle sent `{values}`; backend required `{settings}` | Payload is `{settings:{input:value}}`; errors are shown per field |
| Empty settings pages | Bundle read `data.fields`; backend returned `{settings}` | Fields come from the Panel's schema (`data.schema`), i.e. each module's real definitions |
| Toggles did nothing | Stored state was never read; children registered unconditionally | `ModuleState` read at boot; OFF modules register nothing and their routes 404 |
| Modules never loaded | `$app->register($childClass)` makes `ExtensionProvider` throw (no manifest declares it); the exception was swallowed | Children created with `new Provider($app, $manifest)` and the Panel's begin/register/commit sequence; failures are reported in the UI |
| Uploaded images not shown | Nothing stored them; preview URL was a guessed path | Preview uses the Panel's returned file URL (`/extension-files/vizion/…`) |
| Build not matching source | `dist/client.js` hand-edited; Vite config disabled PostCSS/Tailwind, React 18, Vite 5 | Build config taken from the Panel's own scaffold (`defineExtensionConfig`, React 19, Vite 8) |

## Files

* **Rewritten:** `extension.json`, `package.json`, `tsconfig.json`, `vite.config.mjs`, `routes/admin.php`,
  `resources/modules.json`, `src/VizionServiceProvider.php`, `src/Http/Controllers/ModuleController.php`,
  `src/client/index.tsx`, `src/client/screens/ConfigScreen.tsx`, `src/client/styles.css`.
* **Added:** `src/Support/*` (8 classes), `src/Http/Middleware/EnsureModuleEnabled.php`, `src/client/{scope.ts,modules.generated.ts,vizion.css}`,
  `src/client/vizion/*`, `src/client/screens/DisabledScreen.tsx`, `src/client/assets/logo.ts`, `postcss.config.mjs`, `.gitignore`,
  `resources/icon.png`, `routes/mount/**` (88 generated wrappers), `database/migrations/**` (27), `modules/**` (24 modules), `tools/build-modules.py`, `docs/*`.
* **Removed:** `MasterController.php` (dead, wrong namespace), `ModuleSettingsHost.tsx`, `assets.d.ts`, the hand-built `dist/`, old install notes.
* **Kept as-is:** the Premium UI classes and layout (`vizion.css` is your previous stylesheet plus additions).

## Module changes (all 24)

Applied by `tools/build-modules.py`, identically to every module: provider base class; prefixed setting keys;
settings-registry reads redirected to the module; `ext.<id>.<key>` → `ext.vizion.<id>-<key>`; `extensions/<id>` →
`extensions/vizion/<id>`; Tailwind prefix → `vz`; per-module stylesheet import removed; migrations moved flat into
`database/migrations`. The blind `draft` → `vizion` rename from your previous package is **reverted**: modules are
the original sources (Drift modules keep their `drift-*` ids and `Drift*\` namespaces).

Special cases: **Branding** keeps its head tags, logo and favicon logic but not its stand-alone settings page (Vizion's panel edits the same fields).
**Drift Plugins** has no TypeScript source, so its compiled chunks are used as pre-compiled source (stylesheet loader removed, classes re-prefixed).
**Server Expiry**'s hand-registered application route is skipped while OFF. **Votifier**'s bundled library is mapped in the manifest autoload.

## UI

Header logo is now a circular transparent badge (no black square), a 6.5 s float of 3 px and a soft glow; both stop under `prefers-reduced-motion`.
Module icons are Heroicons (`@heroicons/react/24/outline`).
