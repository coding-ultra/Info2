# Backend routes

## Added by Vizion (`routes/admin.php`, behind the Panel's `admin-api` middleware = authenticated root admin)

| Method | URL | Purpose |
|---|---|---|
| GET | `/api/admin/extensions/vizion/modules/status` | per-module ON/OFF, loaded flag and load error |
| POST | `/api/admin/extensions/vizion/modules/{module}/reset` | restore a module's settings to defaults (session auth required; keeps the ON/OFF switch and uploaded files) |

## Used from the Panel (native, not part of this package)

| Method | URL | Purpose |
|---|---|---|
| GET | `/api/admin/extensions/vizion/settings` | schema + current values of every module's settings |
| PATCH | `/api/admin/extensions/vizion/settings` | save `{ "settings": { "<input>": value } }` (also the ON/OFF switches) |
| POST | `/api/admin/extensions/vizion/settings/{input}/file` | upload (multipart field `file`) |
| DELETE | `/api/admin/extensions/vizion/settings/{input}/file` | remove an uploaded file |
| GET | `/extension-files/vizion/<file>` | serves uploaded files (logo, favicon, ...) |

## How module routes are mounted

Each module's own route files are mounted through generated wrappers in `routes/mount/<module>/`, which add the module segment and the ON/OFF gate (`EnsureModuleEnabled`, 404 while OFF):

| Module route file | Panel mounts it at | Vizion URL |
|---|---|---|
| `admin.php` | `/api/admin/extensions/vizion` | `/api/admin/extensions/vizion/<module>/…` |
| `client.php` | `/api/client/extensions/vizion` | `/api/client/extensions/vizion/<module>/…` |
| `server.php` | `/api/client/servers/{server}/extensions/vizion` | `…/extensions/vizion/<module>/…` |
| `application.php` | `/api/application/extensions/vizion` | `/api/application/extensions/vizion/<module>/…` |
| `web.php`, `authenticated.php` | `/extensions/vizion` | `/extensions/vizion/<module>/…` |
| `root.php` (drift-register) | `/register` (declared in `routes.root`) | unchanged, gated only |

**Changed URLs.** Every URL that used to contain `extensions/<module>` now contains `extensions/vizion/<module>`; clients were rewritten to match (49 call sites cross-checked). **Changed permissions:** `ext.<module>.<key>` is now `ext.vizion.<module>-<key>`.

## Routes per module

| Module | Route files and wrappers |
|---|---|
| `branding` | none (frontend/provider only) |
| `demo` | `web.php` |
| `drift-mod` | `admin.php`, `server.php` |
| `drift-plugins` | `admin.php`, `server.php` |
| `drift-properties` | `admin.php` |
| `drift-register` | `admin.php`, `authenticated.php`, `client.php`, `root.php`, `web.php` |
| `egg-changer` | `admin.php`, `server.php` |
| `mc-console` | `server.php` |
| `mc-players` | `client.php`, `server.php` |
| `mc-version` | `server.php` |
| `mc-world` | `server.php` |
| `mcp` | `client.php` |
| `monitoring` | `admin.php`, `client.php`, `server.php` |
| `node-resources` | `admin.php`, `server.php` |
| `palworld-tools` | `server.php` |
| `server-creator` | `admin.php`, `client.php`, `server.php` |
| `server-expiry` | `admin.php`, `application.php`, `client.php`, `server.php` |
| `server-groups` | `admin.php`, `client.php` |
| `server-splitter` | `admin.php`, `server.php` |
| `sso` | `account.php`, `client.php`, `web.php` |
| `subdomains` | `admin.php`, `server.php` |
| `terraria-tools` | `server.php` |
| `valheim-tools` | `server.php` |
| `votifier-tester` | `server.php` |
