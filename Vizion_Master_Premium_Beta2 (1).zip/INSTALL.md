# Install

Requirements: Pterodactyl Panel 2.0.0-beta.2, PHP 8.3, a Node version supported by Vite 8, the Panel's `packages/sdk` folder.

1. **Put the folder at `<panel>/extensions/vizion`.** `package.json` links the SDK as `file:../../packages/sdk`,
   which is `<panel>/packages/sdk` from there. Use another path if your SDK lives elsewhere.
2. **Build** (not included in the zip, as agreed):
   ```
   cd <panel>/extensions/vizion
   npm install
   npm run typecheck
   npm run build
   ```
   Fix anything `typecheck` reports before continuing, then check the result:
   ```
   php artisan p:extension:doctor .
   ```
   `doctor` validates `extension.json` and rejects a build whose CSS uses a Tailwind prefix other than `vz`.
3. **Install.** Either pack and upload in Admin → Extensions:
   ```
   php artisan p:extension:pack . --force      # writes a .pteroext archive
   ```
   or install it from the command line:
   ```
   php artisan p:extension:install <file>.pteroext --enable
   ```
4. Open **Admin → Vizion**. Every module is ON except MCP. Open a module to edit its settings, upload files
   (Branding: logo, favicon), switch it ON/OFF, or open its screens. After a switch, reload the page so menus update.

Do this on a staging panel first. Existing standalone copies of these extensions should be disabled before
enabling Vizion (the Panel refuses to enable two extensions that claim the same root path, Tailwind prefix or PSR-4 namespace, and their database tables would clash). Vizion starts with
empty settings; values saved in the standalone extensions are not copied.

## Uninstalling / turning things off

Switching a module OFF keeps its settings and data.
