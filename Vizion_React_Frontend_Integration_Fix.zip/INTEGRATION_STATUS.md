# Vizion source integration status

This is an uncompiled, best-effort source package assembled from the uploaded `Vizion_Fixed_Built.zip`.

## Changes in this package

- The master Config screen now has a searchable module grid with purpose-matched inline SVG icons.
- The detail view lazy-loads original React screen components where the preserved module source contains an admin/config screen.
- `extension.json` now declares PSR-4 autoload roots for the preserved module namespaces.
- `VizionServiceProvider` attempts to register each original Laravel provider through the Laravel application, isolates failures, logs them, and discovers child migration directories.
- `resources/modules.json` now identifies which original admin screen is available, rather than using the old `backend-integration-requires-validation` status string.

## Critical compatibility limits (must be tested on the target Panel + SDK)

This is not certified as a complete or production-safe integration. The actual Pterodactyl SDK source was not available during this build. In particular:

1. `ExtensionProvider` may require extension-manifest context when instantiated. Calling `$app->register()` on a child provider may fail or may not give it the child's original extension root/ID. Failures are logged as `[Vizion]` entries.
2. Several modules' API clients and backend routes use their original extension IDs and prefixes. Registering the provider does not automatically rewrite those URLs to the `vizion` namespace.
3. Some original screens are server/account screens, not admin configuration screens. Modules without a real admin screen display an explicit explanation; no fake settings form is generated.
4. The screens are loaded as React components in Vizion's screen. Components using SDK hooks, screen context, extension config, or module-specific route context may require an SDK-native screen registration adapter. Validate each screen independently.
5. Settings registered by child providers may remain keyed to their original module IDs instead of a single `vizion` settings namespace. Do not assume settings are merged.
6. Modules with web/root/authenticated routes, scheduled jobs, commands, event listeners, migrations, permissions, and external dependencies need individual validation. The best-effort provider loop is not a substitute for a deliberate migration of those resources.

## Build on the target panel

Use the panel's extension SDK checkout as the local dependency expected by this package. Then install dependencies and run:

```bash
npm install
npm run typecheck
npm run build
```

Run the Panel's extension doctor/pack commands supported by the exact installed SDK version. Check Laravel logs for `[Vizion]` warnings/errors, inspect registered routes, run migrations in a staging database, and test every module's read/write flows before production.

## Rollback

Keep the original panel database backup and the prior extension ZIP. Do not remove the standalone child extensions until the Vizion build has passed route, permission, settings, migration, and UI regression tests. This archive preserves module source; it does not prove those modules can safely be disabled individually.
