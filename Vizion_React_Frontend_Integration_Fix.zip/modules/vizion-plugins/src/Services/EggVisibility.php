<?php

namespace VizionPlugins\Services;

use VizionPlugins\Settings\PluginSettings;
use Pterodactyl\Models\Egg;
use Pterodactyl\Models\Server;

/**
 * Decides whether Plugins is available on a server, from the server's egg.
 *
 * Order of rules:
 *   1. An administrator override for that egg ("show" or "hide") always wins.
 *   2. Otherwise, when "require_plugin_egg" is on (the default), only eggs that can load plugins are shown:
 *      the egg name matches a plugin server or a mod+plugin hybrid listed below.
 *   3. Otherwise every egg is shown.
 *
 * Plain Vanilla and modloader-only eggs (Forge, Fabric, Quilt...) cannot load plugins, so they are not in the lists.
 */
final class EggVisibility
{
    /** Servers that load Bukkit/Spigot/Paper-style plugins, plus the proxies this extension also searches for. */
    public const PLUGIN_SERVERS = [
        'paper', 'purpur', 'pufferfish', 'leaves', 'spigot', 'bukkit', 'craftbukkit', 'folia', 'airplane',
        'gale', 'luminol', 'canvasmc', 'glowstone', 'velocity', 'bungeecord', 'waterfall',
    ];

    /** Mod servers that also load plugins. */
    public const HYBRIDS = [
        'arclight', 'mohist', 'magma', 'youer', 'catserver', 'banner', 'crucible', 'spongeforge', 'spongevanilla',
    ];

    public const GROUP_SERVERS = 'Plugin servers';

    public const GROUP_HYBRIDS = 'Mod + plugin hybrids';

    public function __construct(private readonly PluginSettings $settings) {}

    /** @return list<string> the egg's tags, lower-cased */
    public static function tagsOf(?Egg $egg): array
    {
        $tags = $egg?->tags ?? [];
        if (is_string($tags)) {
            $decoded = json_decode($tags, true);
            $tags = is_array($decoded) ? $decoded : [];
        }

        return array_values(array_map(
            static fn ($tag) => mb_strtolower(trim((string) $tag)),
            array_filter((array) $tags, 'is_scalar'),
        ));
    }

    /** Which family an egg name belongs to ("Paper 1.21" -> plugin servers), or null. */
    public static function groupOfName(string $name): ?string
    {
        $words = ' '.trim(preg_replace('/[^a-z0-9]+/', ' ', mb_strtolower($name)) ?? '').' ';
        $has = static function (array $list) use ($words): bool {
            foreach ($list as $word) {
                if (str_contains($words, ' '.$word.' ')) {
                    return true;
                }
            }

            return false;
        };

        // Hybrids first: "SpongeForge" or "Mohist" must not be treated as a plain modloader.
        if ($has(self::HYBRIDS)) {
            return self::GROUP_HYBRIDS;
        }

        return $has(self::PLUGIN_SERVERS) ? self::GROUP_SERVERS : null;
    }

    /**
     * @param list<string> $tags
     * @return array{enabled: bool, reason: string}  reason: override | category | all
     */
    public function decide(int $eggId, array $tags, string $name = ''): array
    {
        $config = $this->settings->all();
        $override = $config['egg_overrides'][(string) $eggId] ?? null;

        if ($override === 'show' || $override === 'hide') {
            return ['enabled' => $override === 'show', 'reason' => 'override'];
        }

        if ($config['require_plugin_egg']) {
            return ['enabled' => self::groupOfName($name) !== null, 'reason' => 'category'];
        }

        return ['enabled' => true, 'reason' => 'all'];
    }

    /** @return array{enabled: bool, reason: string} */
    public function forServer(Server $server): array
    {
        return $this->decide((int) $server->egg_id, self::tagsOf($server->egg), (string) ($server->egg?->name ?? ''));
    }

    public function abortUnlessAllowed(Server $server): void
    {
        abort_unless($this->forServer($server)['enabled'], 403, 'Plugins is not available for this server\'s egg.');
    }
}
