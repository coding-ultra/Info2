<?php

namespace VizionPlugins\Services;

use RuntimeException;

class ModrinthUnavailableException extends RuntimeException {}
