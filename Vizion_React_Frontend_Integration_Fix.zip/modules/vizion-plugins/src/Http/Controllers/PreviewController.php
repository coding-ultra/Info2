<?php

namespace VizionPlugins\Http\Controllers;

use VizionPlugins\Services\ModrinthClient;
use VizionPlugins\Services\ModrinthUnavailableException;
use VizionPlugins\Settings\PluginSettings;
use Illuminate\Http\JsonResponse;
use Illuminate\Routing\Controller;
use Knuckles\Scribe\Attributes\Endpoint;

/** Root administrators only (routes/admin.php). */
class PreviewController extends Controller
{
    #[Endpoint('Preview plugins', 'Four random popular Modrinth plugins, for the live preview on the admin page.')]
    public function show(PluginSettings $settings): JsonResponse
    {
        $all = $settings->all();

        try {
            $result = (new ModrinthClient(trim(preg_replace('/[\r\n]+/', ' ', (string) $all['contact']) ?? ''), (int) $all['cache_minutes']))
                ->search(null, null, null, null, 'downloads', 1);
        } catch (ModrinthUnavailableException $e) {
            return new JsonResponse(['errors' => [['code' => 'ModrinthUnavailable', 'status' => '502', 'detail' => $e->getMessage()]]], 502);
        } catch (\Throwable $e) {
            report($e);

            return new JsonResponse(['errors' => [['code' => 'VizionPluginsError', 'status' => '500', 'detail' => 'Plugins failed: '.class_basename($e).': '.$e->getMessage()]]], 500);
        }

        $hits = $result['hits'];
        shuffle($hits);

        return new JsonResponse(['data' => array_slice($hits, 0, 4)]);
    }
}
