<?php

use VizionPlugins\Http\Controllers\ConfigController;
use Illuminate\Support\Facades\Route;

// Final URLs: /api/admin/extensions/vizion-plugins/config
// ("/settings" is reserved by the Panel, so this uses "/config".)
Route::get('/config', [ConfigController::class, 'show'])->name('config.show');
Route::get('/preview', [\VizionPlugins\Http\Controllers\PreviewController::class, 'show'])->name('preview');
Route::put('/config', [ConfigController::class, 'update'])->name('config.update');
// Every egg with its family, for the per-egg show/hide switches.
Route::get('/eggs', [ConfigController::class, 'eggs'])->name('config.eggs');
