<?php

use VizionPlugins\Http\Controllers\BrowseController;
use Illuminate\Support\Facades\Route;

// Final URLs: /api/client/servers/{server}/extensions/vizion-plugins/...
// Whether Plugins is shown for this server's egg.
Route::get('/availability', [BrowseController::class, 'availability'])->name('availability');
Route::get('/meta', [BrowseController::class, 'meta'])->name('meta');
Route::get('/search', [BrowseController::class, 'search'])->name('search');
Route::get('/projects/{project}', [BrowseController::class, 'details'])->where('project', '[A-Za-z0-9_.-]+')->name('details');
Route::get('/projects/{project}/versions', [BrowseController::class, 'versions'])->name('versions');
Route::get('/layout', [\VizionPlugins\Http\Controllers\LayoutController::class, 'show'])->name('layout');
