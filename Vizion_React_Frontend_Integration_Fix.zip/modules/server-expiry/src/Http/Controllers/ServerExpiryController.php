<?php

declare(strict_types=1);

namespace ServerExpiry\Http\Controllers;

use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Log;
use Pterodactyl\Contracts\Servers\TogglesServerSuspension;
use Pterodactyl\Http\Controllers\Controller;
use Pterodactyl\Models\Server;
use ServerExpiry\Models\ServerExpiry;
use Throwable;

class ServerExpiryController extends Controller
{
    /**
     * Resolve a server instance from an integer ID, UUID string, external_id, or bound Model.
     */
    protected function resolveServer(mixed $server = null): Server
    {
        $server = $server
            ?? request()->route('server')
            ?? request()->route('external_id')
            ?? request()->input('server_id')
            ?? request()->input('server');

        if ($server instanceof Server) {
            return $server;
        }

        $val = (string) $server;
        if (ctype_digit($val)) {
            $found = Server::query()->whereKey($val)->first();
            if ($found !== null) {
                return $found;
            }
        }

        $found = Server::query()->whereUuidOrShort($val)->first();
        if ($found !== null) {
            return $found;
        }

        $found = Server::query()->where('external_id', $val)->first();
        if ($found !== null) {
            return $found;
        }

        abort(Response::HTTP_NOT_FOUND, 'The requested server could not be found.');
    }

    /**
     * If the server is currently suspended and a new valid future expiry date is set,
     * automatically unsuspend the server.
     */
    protected function unsuspendIfSuspended(Server $server, ?string $expiresAt): void
    {
        if (empty($expiresAt)) {
            return;
        }

        try {
            $parsed = Carbon::parse($expiresAt);
            if ($parsed->isFuture() && $server->isSuspended()) {
                /** @var TogglesServerSuspension $suspension */
                $suspension = app(TogglesServerSuspension::class);
                $suspension->toggle($server, TogglesServerSuspension::ACTION_UNSUSPEND);
                $server->refresh();

                if (class_exists(\Pterodactyl\Facades\Activity::class)) {
                    \Pterodactyl\Facades\Activity::event('admin:server.unsuspend')
                        ->subject($server)
                        ->property('name', $server->name)
                        ->log();
                }
            }
        } catch (Throwable $e) {
            Log::error("[ServerExpiry] Failed to auto-unsuspend server {$server->id}: " . $e->getMessage(), [
                'exception' => $e,
            ]);
        }
    }

    /**
     * Extract expiration date parameter from flexible field aliases.
     */
    protected function extractExpiresAt(Request $request): ?string
    {
        return $request->input('expires_at')
            ?? $request->input('server_expire_at')
            ?? $request->input('expiration_date')
            ?? $request->input('expiry_date')
            ?? $request->input('extensions.server-expiry.expires_at')
            ?? $request->input('server_expiry.expires_at');
    }

    /**
     * Extract expiry action parameter from flexible field aliases.
     */
    protected function extractAction(Request $request, ?string $fallback = 'suspend'): string
    {
        $action = $request->input('action')
            ?? $request->input('expiry_action')
            ?? $request->input('extensions.server-expiry.action')
            ?? $request->input('server_expiry.action')
            ?? $fallback;

        return in_array($action, ['suspend', 'delete'], true) ? $action : 'suspend';
    }

    /**
     * Check if expiration date field was present in the request payload (including null).
     */
    protected function hasExpiresAtInput(Request $request): bool
    {
        return $request->has('expires_at')
            || $request->has('server_expire_at')
            || $request->has('expiration_date')
            || $request->has('expiry_date')
            || $request->has('extensions.server-expiry.expires_at')
            || $request->has('server_expiry.expires_at');
    }

    /**
     * List all server expiry records enriched with server details.
     */
    public function index(): JsonResponse
    {
        $expiries = ServerExpiry::query()
            ->join('servers', 'ext_server_expiry.server_id', '=', 'servers.id')
            ->select([
                'ext_server_expiry.id',
                'ext_server_expiry.server_id',
                'ext_server_expiry.expires_at',
                'ext_server_expiry.action',
                'ext_server_expiry.created_at',
                'ext_server_expiry.updated_at',
                'servers.name as server_name',
                'servers.uuid as server_uuid',
                'servers.uuidShort as server_identifier',
                'servers.external_id as server_external_id',
                'servers.status as server_status',
            ])
            ->get()
            ->map(function ($row) {
                return [
                    'id'                 => $row->id,
                    'server_id'          => $row->server_id,
                    'server_name'        => $row->server_name,
                    'server_uuid'        => $row->server_uuid,
                    'server_identifier'  => $row->server_identifier,
                    'server_external_id' => $row->server_external_id,
                    'server_status'      => $row->server_status,
                    'expires_at'         => $row->expires_at ? Carbon::parse($row->expires_at)->toAtomString() : null,
                    'action'             => $row->action,
                    'created_at'         => $row->created_at ? Carbon::parse($row->created_at)->toAtomString() : null,
                    'updated_at'         => $row->updated_at ? Carbon::parse($row->updated_at)->toAtomString() : null,
                ];
            });

        return new JsonResponse(['data' => $expiries]);
    }

    /**
     * Return the expiry configuration for a specific server.
     */
    public function show(mixed $server = null): JsonResponse
    {
        $serverModel = $this->resolveServer($server);

        $expiry = ServerExpiry::query()
            ->where('server_id', $serverModel->id)
            ->first();

        return new JsonResponse([
            'server_id'          => $serverModel->id,
            'server_uuid'        => $serverModel->uuid,
            'server_name'        => $serverModel->name,
            'server_identifier'  => $serverModel->uuidShort,
            'server_external_id' => $serverModel->external_id,
            'expires_at'         => $expiry?->expires_at?->toAtomString(),
            'action'             => $expiry?->action ?? 'suspend',
            'is_suspended'       => $serverModel->isSuspended(),
            'server_status'      => $serverModel->status,
        ]);
    }

    /**
     * Create or update expiry configuration by specifying server identifier in the body.
     */
    public function store(Request $request): JsonResponse
    {
        $serverIdentifier = $request->input('server_id')
            ?? $request->input('server')
            ?? $request->input('server_uuid')
            ?? $request->input('external_id');

        if ($serverIdentifier === null) {
            return new JsonResponse([
                'errors' => [
                    [
                        'code'   => 'ValidationException',
                        'detail' => 'A server identifier (server_id, server, server_uuid, or external_id) is required.',
                    ],
                ],
            ], Response::HTTP_UNPROCESSABLE_ENTITY);
        }

        $server = $this->resolveServer($serverIdentifier);
        $expiresAt = $this->extractExpiresAt($request);
        $existing = ServerExpiry::query()->where('server_id', $server->id)->first();
        $action = $this->extractAction($request, $existing?->action ?? 'suspend');

        if (!empty($expiresAt)) {
            $parsed = Carbon::parse($expiresAt);
            $expiry = ServerExpiry::query()->updateOrCreate(
                ['server_id' => $server->id],
                [
                    'expires_at' => $parsed,
                    'action'     => $action,
                ]
            );
            $this->unsuspendIfSuspended($server, $expiresAt);
        } else {
            if ($this->hasExpiresAtInput($request)) {
                ServerExpiry::query()->where('server_id', $server->id)->delete();
                $expiry = null;
            } else {
                $expiry = $existing;
            }
        }

        return new JsonResponse([
            'server_id'          => $server->id,
            'server_uuid'        => $server->uuid,
            'server_name'        => $server->name,
            'server_identifier'  => $server->uuidShort,
            'server_external_id' => $server->external_id,
            'expires_at'         => $expiry?->expires_at?->toAtomString(),
            'action'             => $expiry?->action ?? $action,
            'is_suspended'       => $server->isSuspended(),
            'server_status'      => $server->status,
        ], Response::HTTP_CREATED);
    }

    /**
     * Create or update the expiry configuration for a server.
     */
    public function update(Request $request, mixed $server = null): JsonResponse
    {
        $serverModel = $this->resolveServer($server);
        $expiresAt = $this->extractExpiresAt($request);
        $existing = ServerExpiry::query()->where('server_id', $serverModel->id)->first();
        $action = $this->extractAction($request, $existing?->action ?? 'suspend');

        if (!empty($expiresAt)) {
            $parsed = Carbon::parse($expiresAt);
            $expiry = ServerExpiry::query()->updateOrCreate(
                ['server_id' => $serverModel->id],
                [
                    'expires_at' => $parsed,
                    'action'     => $action,
                ]
            );
            $this->unsuspendIfSuspended($serverModel, $expiresAt);
        } else {
            if ($this->hasExpiresAtInput($request)) {
                ServerExpiry::query()->where('server_id', $serverModel->id)->delete();
                $expiry = null;
            } else {
                $expiry = $existing;
            }
        }

        return new JsonResponse([
            'server_id'          => $serverModel->id,
            'server_uuid'        => $serverModel->uuid,
            'server_name'        => $serverModel->name,
            'server_identifier'  => $serverModel->uuidShort,
            'server_external_id' => $serverModel->external_id,
            'expires_at'         => $expiry?->expires_at?->toAtomString(),
            'action'             => $expiry?->action ?? $action,
            'is_suspended'       => $serverModel->isSuspended(),
            'server_status'      => $serverModel->status,
        ]);
    }

    /**
     * Remove the expiry configuration for a server (disables expiry).
     */
    public function destroy(mixed $server = null): JsonResponse
    {
        $serverModel = $this->resolveServer($server);

        ServerExpiry::query()->where('server_id', $serverModel->id)->delete();

        return new JsonResponse([
            'success'            => true,
            'server_id'          => $serverModel->id,
            'server_uuid'        => $serverModel->uuid,
            'server_name'        => $serverModel->name,
            'server_identifier'  => $serverModel->uuidShort,
            'server_external_id' => $serverModel->external_id,
        ]);
    }

    /**
     * Show expiry configuration by external server ID.
     */
    public function showByExternalId(string $external_id): JsonResponse
    {
        return $this->show($external_id);
    }

    /**
     * Update expiry configuration by external server ID.
     */
    public function updateByExternalId(Request $request, string $external_id): JsonResponse
    {
        return $this->update($request, $external_id);
    }

    /**
     * Remove expiry configuration by external server ID.
     */
    public function destroyByExternalId(string $external_id): JsonResponse
    {
        return $this->destroy($external_id);
    }
}
