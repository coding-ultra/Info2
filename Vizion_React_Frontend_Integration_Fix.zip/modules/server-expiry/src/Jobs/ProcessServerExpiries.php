<?php

declare(strict_types=1);

namespace ServerExpiry\Jobs;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Log;
use Pterodactyl\Contracts\Servers\DeletesServers;
use Pterodactyl\Contracts\Servers\TogglesServerSuspension;
use Pterodactyl\Models\Server;
use ServerExpiry\Models\ServerExpiry;
use Throwable;

class ProcessServerExpiries implements ShouldQueue
{
    use Dispatchable;
    use InteractsWithQueue;
    use Queueable;
    use SerializesModels;

    public function __construct()
    {
        $this->queue = 'standard';
    }

    /**
     * Walk through all expiry records whose `expires_at` is in the past and
     * either suspend or permanently delete each server according to its action.
     */
    public function handle(TogglesServerSuspension $suspension, DeletesServers $deletion): void
    {
        $expired = ServerExpiry::query()
            ->whereNotNull('expires_at')
            ->where('expires_at', '<=', Carbon::now())
            ->get();

        foreach ($expired as $expiry) {
            /** @var ServerExpiry $expiry */
            $server = Server::query()->find($expiry->server_id);

            // Server was deleted by other means — clean up the orphaned record.
            if ($server === null) {
                $expiry->delete();
                continue;
            }

            try {
                if ($expiry->action === 'delete') {
                    // Permanently delete the server. The cascadeOnDelete FK will
                    // automatically remove the ext_server_expiry row as well.
                    $deletion->withForce(false)->delete($server);
                } else {
                    // Suspend the server if not already suspended.
                    // Preserve the expiry record so expiration date and action remain
                    // visible on the server info page and manage tab until updated.
                    if (! $server->isSuspended()) {
                        $suspension->toggle($server, TogglesServerSuspension::ACTION_SUSPEND);
                    }
                }
            } catch (Throwable $e) {
                Log::error("[ServerExpiry] Failed processing expiry for server {$server->id}: " . $e->getMessage(), [
                    'exception' => $e,
                ]);
            }
        }
    }
}
