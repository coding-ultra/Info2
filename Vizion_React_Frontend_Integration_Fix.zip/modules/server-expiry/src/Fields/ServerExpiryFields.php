<?php

declare(strict_types=1);

namespace ServerExpiry\Fields;

use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Pterodactyl\Contracts\Servers\TogglesServerSuspension;
use Pterodactyl\Extensions\Attributes\ApplicationApi;
use Pterodactyl\Extensions\Fields;
use Pterodactyl\Models\Server;
use ServerExpiry\Models\ServerExpiry;
use Throwable;

#[ApplicationApi]
final class ServerExpiryFields extends Fields
{
    /**
     * Rules to be applied when validating extension fields for a server.
     * Note: Parameter MUST be nullable (?Server $server = null) because it is null during server creation.
     *
     * @return array<string, mixed>
     */
    public function rules(?Server $server = null): array
    {
        return [
            'expires_at' => ['nullable', 'date'],
            'action'     => ['sometimes', 'nullable', 'string', 'in:suspend,delete'],
        ];
    }

    /**
     * Return the current extension field values for a server.
     *
     * @return array<string, mixed>
     */
    public function values(Server $server): array
    {
        $expiry = ServerExpiry::query()->where('server_id', $server->id)->first();

        return [
            'expires_at' => $expiry?->expires_at?->toAtomString(),
            'action'     => $expiry?->action ?? 'suspend',
        ];
    }

    /**
     * Store the validated extension field values.
     *
     * @param array<string, mixed> $values
     */
    public function save(Server $server, array $values): void
    {
        $hasExpiresAt = array_key_exists('expires_at', $values);
        $expiresAt = $values['expires_at'] ?? null;
        $action = $values['action'] ?? null;

        if (empty($expiresAt)) {
            if ($hasExpiresAt) {
                // Explicit null or empty string means clear the expiry
                ServerExpiry::query()->where('server_id', $server->id)->delete();
            }
            return;
        }

        $existing = ServerExpiry::query()->where('server_id', $server->id)->first();
        $action = $action ?? $existing?->action ?? 'suspend';
        if (!in_array($action, ['suspend', 'delete'], true)) {
            $action = 'suspend';
        }

        ServerExpiry::query()->updateOrCreate(
            ['server_id' => $server->id],
            [
                'expires_at' => Carbon::parse($expiresAt),
                'action'     => $action,
            ]
        );

        // Auto-unsuspend suspended server if a valid future date was set
        DB::afterCommit(function () use ($server, $expiresAt): void {
            $this->unsuspendIfSuspended($server, (string) $expiresAt);
        });
    }

    /**
     * Auto unsuspend the server if it is suspended and the new expiration is in the future.
     */
    protected function unsuspendIfSuspended(Server $server, ?string $expiresAt): void
    {
        if (empty($expiresAt)) {
            return;
        }

        try {
            $parsed = Carbon::parse($expiresAt);
            if ($parsed->isFuture() && $server->isSuspended()) {
                /** @var TogglesServerSuspension $suspension */
                $suspension = app(TogglesServerSuspension::class);
                $suspension->toggle($server, TogglesServerSuspension::ACTION_UNSUSPEND);
                $server->refresh();

                if (class_exists(\Pterodactyl\Facades\Activity::class)) {
                    \Pterodactyl\Facades\Activity::event('admin:server.unsuspend')
                        ->subject($server)
                        ->property('name', $server->name)
                        ->log();
                }
            }
        } catch (Throwable $e) {
            Log::error("[ServerExpiry] Failed to auto-unsuspend server {$server->id}: " . $e->getMessage(), [
                'exception' => $e,
            ]);
        }
    }
}
