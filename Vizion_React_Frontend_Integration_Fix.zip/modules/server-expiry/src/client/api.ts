import { http } from '@pterodactyl/sdk';

export interface ServerExpiryData {
    server_id: number;
    expires_at: string | null;
    action: 'suspend' | 'delete';
    is_suspended?: boolean;
    server_status?: string;
}

export interface ServerExpiryRecord {
    id: number;
    server_id: number;
    expires_at: string | null;
    action: 'suspend' | 'delete';
    created_at: string | null;
    updated_at: string | null;
}

const adminUrl = (serverId: number | string): string =>
    `/api/admin/extensions/server-expiry/servers/${serverId}`;

export const expiryQueryKey = (serverId: number | string) =>
    ['server-expiry', serverId] as const;

export async function getServerExpiry(serverId: number | string): Promise<ServerExpiryData> {
    const { data } = await http.get<ServerExpiryData>(adminUrl(serverId));
    return data;
}

export async function updateServerExpiry(
    serverId: number | string,
    payload: { expires_at: string | null; action: 'suspend' | 'delete' }
): Promise<ServerExpiryData> {
    const { data } = await http.put<ServerExpiryData>(adminUrl(serverId), payload);
    return data;
}

export async function deleteServerExpiry(
    serverId: number | string
): Promise<{ success: boolean; server_id: number }> {
    const { data } = await http.delete<{ success: boolean; server_id: number }>(adminUrl(serverId));
    return data;
}

export async function listServerExpiries(): Promise<{ data: ServerExpiryRecord[] }> {
    const { data } = await http.get<{ data: ServerExpiryRecord[] }>('/api/admin/extensions/server-expiry/servers');
    return data;
}
