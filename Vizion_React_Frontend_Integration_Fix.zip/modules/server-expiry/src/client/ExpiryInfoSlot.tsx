import { useState, useEffect } from 'react';
import { createPortal } from 'react-dom';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import {
    toast,
    httpErrorToHuman,
    useCurrentResource,
    type SlotComponentProps,
    type RouteSlotData,
} from '@pterodactyl/sdk';
import { getServerExpiry, updateServerExpiry, expiryQueryKey } from './api';
import { PENDING_EXPIRY_STORAGE_KEY } from './ExpiryCreateSlot';

export default function ExpiryInfoSlot({ data: slotData }: SlotComponentProps<RouteSlotData>) {
    const resource = useCurrentResource();
    const pathnameMatch = typeof window !== 'undefined' ? window.location.pathname.match(/\/panel\/servers\/(\d+)/) : null;
    const serverId =
        resource?.kind === 'admin.server'
            ? resource.resource.attributes.id
            : slotData?.params?.id
            ? Number(slotData.params.id)
            : pathnameMatch
            ? Number(pathnameMatch[1])
            : null;

    const queryClient = useQueryClient();
    const qk = serverId ? expiryQueryKey(serverId) : null;

    const { data, isLoading } = useQuery({
        queryKey: qk ?? ['server-expiry', 'none'],
        queryFn: () => (serverId ? getServerExpiry(serverId) : Promise.reject()),
        enabled: Boolean(serverId),
        retry: false,
    });

    const [portalTarget, setPortalTarget] = useState<HTMLElement | null>(null);

    // Auto-save any pending expiry from server creation as soon as server detail page mounts
    useEffect(() => {
        if (!serverId) return;

        try {
            const pendingRaw = sessionStorage.getItem(PENDING_EXPIRY_STORAGE_KEY);
            if (pendingRaw) {
                const pending = JSON.parse(pendingRaw);
                // Check if recorded within the last 10 minutes
                if (pending?.expiresAt && Date.now() - (pending.createdAt ?? 0) < 600000) {
                    sessionStorage.removeItem(PENDING_EXPIRY_STORAGE_KEY);
                    updateServerExpiry(serverId, {
                        expires_at: new Date(pending.expiresAt).toISOString(),
                        action: pending.action ?? 'suspend',
                    })
                        .then((saved) => {
                            if (qk) queryClient.setQueryData(qk, saved);
                            queryClient.invalidateQueries({ queryKey: expiryQueryKey(serverId) });
                            toast.success('Server expiry configured from server creation.');
                        })
                        .catch((err) => {
                            toast.error(`Failed to save server expiry: ${httpErrorToHuman(err)}`);
                        });
                }
            }
        } catch {
            // Ignore storage errors
        }
    }, [serverId, queryClient, qk]);

    useEffect(() => {
        let createdTarget: HTMLElement | null = null;

        const findAndMountTarget = () => {
            const headers = Array.from(document.querySelectorAll('h2'));
            const infoHeader = headers.find(
                (h) => h.textContent?.trim() === 'Information'
            );
            if (!infoHeader) return false;

            const infoCard =
                infoHeader.closest<HTMLElement>('.bg-card') ??
                infoHeader.closest<HTMLElement>('.rounded-sm');

            if (!infoCard) return false;

            const contentContainer =
                infoCard.querySelector<HTMLElement>(':scope > div.p-3') ??
                (infoCard.children[1] as HTMLElement | undefined);

            if (!contentContainer) return false;

            let target = document.getElementById('se-info-card-row-target');
            if (!target) {
                target = document.createElement('div');
                target.id = 'se-info-card-row-target';
                contentContainer.appendChild(target);
                createdTarget = target;
            }
            setPortalTarget(target);
            return true;
        };

        if (!findAndMountTarget()) {
            const observer = new MutationObserver(() => {
                if (findAndMountTarget()) {
                    observer.disconnect();
                }
            });
            observer.observe(document.body, { childList: true, subtree: true });

            return () => {
                observer.disconnect();
                if (createdTarget?.parentElement) {
                    createdTarget.remove();
                }
            };
        }

        return () => {
            if (createdTarget?.parentElement) {
                createdTarget.remove();
            }
        };
    }, []);

    if (!serverId) {
        return null;
    }

    const isPast = Boolean(data?.expires_at && new Date(data.expires_at).getTime() <= Date.now());

    const rowContent = (
        <div className="flex justify-between items-center py-2 border-t border-border">
            <span className="text-sm text-muted-foreground">Server Expiration</span>
            <span className="text-sm text-foreground text-right">
                {isLoading ? (
                    <span className="text-xs text-muted-foreground">Loading…</span>
                ) : data?.expires_at ? (
                    <span className="inline-flex items-center gap-2">
                        <code className="text-xs font-mono bg-muted/50 px-1.5 py-0.5 rounded border border-border">
                            {new Date(data.expires_at).toLocaleString()}
                        </code>
                        <span
                            className={`text-xs font-medium px-2 py-0.5 rounded border ${
                                data.action === 'delete'
                                    ? 'bg-red-500/10 text-red-400 border-red-500/20'
                                    : data.is_suspended || isPast
                                    ? 'bg-amber-500/10 text-amber-400 border-amber-500/20'
                                    : 'bg-blue-500/10 text-blue-400 border-blue-500/20'
                            }`}
                        >
                            {data.action === 'delete'
                                ? isPast
                                    ? 'Delete (Expired)'
                                    : 'Delete'
                                : data.is_suspended || isPast
                                ? 'Suspend (Suspended)'
                                : 'Suspend'}
                        </span>
                    </span>
                ) : (
                    <span className="text-muted-foreground">None</span>
                )}
            </span>
        </div>
    );

    if (portalTarget) {
        return createPortal(rowContent, portalTarget);
    }

    return null;
}
