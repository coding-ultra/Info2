import { useState, useEffect, useRef } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import {
    Button,
    Select,
    TitledGreyBox,
    Spinner,
    Label,
    toast,
    httpErrorToHuman,
    useCurrentResource,
    type SlotComponentProps,
    type RouteSlotData,
} from '@pterodactyl/sdk';
import { Clock, AlertTriangle, Calendar } from 'lucide-react';
import { getServerExpiry, updateServerExpiry, deleteServerExpiry, expiryQueryKey } from './api';
import { PENDING_EXPIRY_STORAGE_KEY } from './ExpiryCreateSlot';

export function toDatetimeLocalString(d: Date): string {
    const pad = (n: number) => String(n).padStart(2, '0');
    const y = d.getFullYear();
    const m = pad(d.getMonth() + 1);
    const day = pad(d.getDate());
    const h = pad(d.getHours());
    const min = pad(d.getMinutes());
    return `${y}-${m}-${day}T${h}:${min}`;
}

export default function ExpiryManageSlot({ data: slotData }: SlotComponentProps<RouteSlotData>) {
    const resource = useCurrentResource();
    const pathnameMatch = typeof window !== 'undefined' ? window.location.pathname.match(/\/panel\/servers\/(\d+)/) : null;
    const serverId =
        resource?.kind === 'admin.server'
            ? resource.resource.attributes.id
            : slotData?.params?.id
            ? Number(slotData.params.id)
            : pathnameMatch
            ? Number(pathnameMatch[1])
            : null;

    if (!serverId) {
        return null;
    }

    const queryClient = useQueryClient();
    const qk = expiryQueryKey(serverId);

    const { data, isLoading } = useQuery({
        queryKey: qk,
        queryFn: () => getServerExpiry(serverId),
        staleTime: 30000,
    });

    const [expiresAt, setExpiresAt] = useState('');
    const [action, setAction] = useState<'suspend' | 'delete'>('suspend');
    const inputRef = useRef<HTMLInputElement>(null);
    const initializedServerId = useRef<number | null>(null);

    // Populate form only once per server ID to never block or overwrite user edits during refetches
    useEffect(() => {
        if (!data || initializedServerId.current === serverId) {
            return;
        }

        initializedServerId.current = serverId;
        if (data.expires_at) {
            setExpiresAt(toDatetimeLocalString(new Date(data.expires_at)));
            setAction(data.action);
        } else {
            // Check if there was a pending expiry from server creation
            try {
                const pendingRaw = sessionStorage.getItem(PENDING_EXPIRY_STORAGE_KEY);
                if (pendingRaw) {
                    const pending = JSON.parse(pendingRaw);
                    if (pending?.expiresAt && Date.now() - (pending.createdAt ?? 0) < 600000) {
                        setExpiresAt(pending.expiresAt);
                        setAction(pending.action ?? 'suspend');
                        sessionStorage.removeItem(PENDING_EXPIRY_STORAGE_KEY);
                        // Auto save pending
                        updateServerExpiry(serverId, {
                            expires_at: new Date(pending.expiresAt).toISOString(),
                            action: pending.action ?? 'suspend',
                        })
                            .then((saved) => {
                                queryClient.setQueryData(qk, saved);
                                queryClient.invalidateQueries({ queryKey: ['server-expiry'] });
                                toast.success('Server expiry configured from server creation.');
                            })
                            .catch(() => {});
                        return;
                    }
                }
            } catch {
                // Ignore storage errors
            }
            setExpiresAt('');
            setAction(data.action ?? 'suspend');
        }
    }, [data, serverId, queryClient, qk]);

    const openDatePicker = () => {
        try {
            inputRef.current?.showPicker?.();
        } catch {
            inputRef.current?.focus();
        }
    };

    const saveMutation = useMutation({
        mutationFn: (payload: { expires_at: string; action: 'suspend' | 'delete' }) =>
            updateServerExpiry(serverId, payload),
        onSuccess: (saved) => {
            const wasSuspended = data?.is_suspended;
            queryClient.setQueryData(qk, saved);
            queryClient.invalidateQueries({ queryKey: ['server-expiry'] });
            queryClient.invalidateQueries({ queryKey: ['admin:servers'] });
            queryClient.invalidateQueries({ queryKey: ['admin.server'] });
            queryClient.invalidateQueries({ queryKey: ['server'] });
            if (saved.expires_at) {
                setExpiresAt(toDatetimeLocalString(new Date(saved.expires_at)));
            } else {
                setExpiresAt('');
            }
            if (wasSuspended && saved.is_suspended === false) {
                toast.success('Server expiry settings saved and server unsuspended.');
            } else {
                toast.success('Server expiry settings saved.');
            }
        },
        onError: (error) => toast.error(httpErrorToHuman(error)),
    });

    const removeMutation = useMutation({
        mutationFn: () => deleteServerExpiry(serverId),
        onSuccess: () => {
            queryClient.setQueryData(qk, {
                server_id: serverId,
                expires_at: null,
                action: 'suspend',
                is_suspended: data?.is_suspended,
            });
            queryClient.invalidateQueries({ queryKey: ['server-expiry'] });
            setExpiresAt('');
            toast.success('Server expiry disabled.');
        },
        onError: (error) => toast.error(httpErrorToHuman(error)),
    });

    const handleSave = () => {
        if (!expiresAt) {
            toast.error('Please choose an expiration date.');
            return;
        }

        const parsed = new Date(expiresAt);
        if (isNaN(parsed.getTime())) {
            toast.error('Invalid expiration date format.');
            return;
        }

        saveMutation.mutate({
            expires_at: parsed.toISOString(),
            action,
        });
    };

    const isExpired = Boolean(data?.expires_at && new Date(data.expires_at).getTime() <= Date.now());

    return (
        <div className="mb-6">
            <TitledGreyBox title="Server Expiry" icon={Clock}>
                <div className="space-y-5">
                    <div className="space-y-1.5">
                        <p className="text-sm text-muted-foreground">
                            Configure automatic server expiration. When the specified expiration date and time is reached,
                            the panel will execute the selected action (suspend or delete).
                        </p>
                        {data?.is_suspended && (
                            <p className="text-sm text-amber-400/90">
                                This server is currently <strong className="font-semibold text-amber-300">Suspended</strong>. Setting a new expiration date will save the updated schedule and automatically unsuspend the server.
                            </p>
                        )}
                    </div>

                    {isLoading ? (
                        <div className="py-6 flex justify-center">
                            <Spinner />
                        </div>
                    ) : (
                        <>
                            {isExpired && !data?.is_suspended && (
                                <div className="p-3.5 rounded bg-red-500/10 border border-red-500/30 flex items-center gap-3 text-sm text-red-300">
                                    <AlertTriangle className="w-5 h-5 text-red-400 shrink-0" />
                                    <span>This server passed its expiry date and is pending action.</span>
                                </div>
                            )}

                            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-start">
                                {/* Left column: Date & Time */}
                                <div className="space-y-2">
                                    <Label htmlFor="se-manage-expires-at">Server Expire At</Label>
                                    <div
                                        style={{ position: 'relative' }}
                                        className="relative flex items-center w-full rounded-sm border border-input bg-input transition-colors duration-150 hover:border-input focus-within:shadow-md focus-within:border-primary focus-within:ring-2 focus-within:ring-ring/50"
                                    >
                                        <input
                                            ref={inputRef}
                                            id="se-manage-expires-at"
                                            type="datetime-local"
                                            value={expiresAt}
                                            onChange={(e) => setExpiresAt(e.target.value)}
                                            onClick={openDatePicker}
                                            style={{ colorScheme: 'dark' }}
                                            className="se-datetime-input w-full min-w-0 appearance-none border-0 bg-transparent p-3 pr-10 text-sm text-foreground outline-hidden focus:ring-0 focus:outline-hidden cursor-pointer"
                                        />
                                        <div
                                            style={{
                                                position: 'absolute',
                                                right: 0,
                                                top: 0,
                                                height: '100%',
                                                width: '2.5rem',
                                                display: 'flex',
                                                alignItems: 'center',
                                                justifyContent: 'center',
                                                pointerEvents: 'none',
                                            }}
                                            className="text-muted-foreground"
                                        >
                                            <Calendar className="w-4 h-4" />
                                        </div>
                                    </div>

                                    <p className="text-xs text-muted-foreground pt-0.5">
                                        The date and time when the server will automatically expire.
                                    </p>
                                </div>

                                {/* Right column: Action */}
                                <div className="space-y-2">
                                    <Label htmlFor="se-manage-action">Action on Expiry</Label>
                                    <Select
                                        id="se-manage-action"
                                        value={action}
                                        onChange={(v) => setAction(v as 'suspend' | 'delete')}
                                        options={[
                                            { value: 'suspend', label: 'Suspend server' },
                                            { value: 'delete', label: 'Remove permanently' },
                                        ]}
                                    />
                                    <p className="text-xs text-muted-foreground pt-0.5">
                                        Whether to suspend the server or permanently delete it when expired.
                                    </p>
                                </div>
                            </div>

                            <div className="flex items-center justify-between pt-4 border-t border-border/40">
                                <div>
                                    {data?.expires_at && (
                                        <Button
                                            isSecondary
                                            color="red"
                                            size="small"
                                            isLoading={removeMutation.isPending}
                                            onClick={() => removeMutation.mutate()}
                                        >
                                            Disable Expiry
                                        </Button>
                                    )}
                                </div>
                                <Button
                                    isLoading={saveMutation.isPending}
                                    onClick={handleSave}
                                >
                                    Save Expiry Settings
                                </Button>
                            </div>
                        </>
                    )}
                </div>
            </TitledGreyBox>
        </div>
    );
}
