import './styles.css';
import { definePterodactylExtension } from '@pterodactyl/sdk';
import ExpiryCreateSlot from './ExpiryCreateSlot';
import ExpiryManageSlot from './ExpiryManageSlot';
import ExpiryInfoSlot from './ExpiryInfoSlot';

export default definePterodactylExtension({
    setup({ slots }) {
        // Register the create server slot (rendered just under Core Details)
        slots.register('panel.servers.create.after', ExpiryCreateSlot);

        // Register the manage tab slot in server edit page
        slots.register('panel.servers.detail.manage.before', ExpiryManageSlot);

        // Register the Information tab slot (rendered in Information card)
        slots.register('panel.servers.detail.about.after', ExpiryInfoSlot);
    },
});
