import { afterEach, expect, test } from 'vitest';
import { cleanup, render, screen } from '@testing-library/react';
import { createExtensionTestHost, createTestServer } from '@pterodactyl/sdk/testing';
import ExpiryCreateSlot from './ExpiryCreateSlot';
import ExpiryInfoSlot from './ExpiryInfoSlot';
import ExpiryManageSlot from './ExpiryManageSlot';

const host = createExtensionTestHost({ extensionId: 'server-expiry', server: createTestServer() });
afterEach(() => {
    cleanup();
    host.dispose();
});

test('renders Server Expiry create slot with inputs', async () => {
    render(<ExpiryCreateSlot data={{ pathname: '/panel/servers/new', search: {}, params: {} }} />, {
        wrapper: host.Wrapper,
    });

    expect(await screen.findByText('Server Expiry')).toBeTruthy();
    expect(screen.getByLabelText('Server Expire At')).toBeTruthy();
    expect(screen.getByLabelText('Action on Expiry')).toBeTruthy();
});

test('renders Server Expiry manage slot with box and description', async () => {
    render(<ExpiryManageSlot data={{ pathname: '/panel/servers/1/manage', search: {}, params: { id: '1' } }} />, {
        wrapper: host.Wrapper,
    });

    expect(await screen.findByText('Server Expiry')).toBeTruthy();
    expect(screen.getByText(/Configure automatic server expiration/)).toBeTruthy();
});

test('renders Server Expiry info slot into Information card', async () => {
    // Setup dummy Information card in document.body
    const card = document.createElement('div');
    card.className = 'bg-card';
    const header = document.createElement('h2');
    header.textContent = 'Information';
    card.appendChild(header);
    const content = document.createElement('div');
    content.className = 'p-3';
    card.appendChild(content);
    document.body.appendChild(card);

    render(<ExpiryInfoSlot data={{ pathname: '/panel/servers/1', search: {}, params: { id: '1' } }} />, {
        wrapper: host.Wrapper,
    });

    expect(await screen.findByText('Server Expiration')).toBeTruthy();

    card.remove();
});
