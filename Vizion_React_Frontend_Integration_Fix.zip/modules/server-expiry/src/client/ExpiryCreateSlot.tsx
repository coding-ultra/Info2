import { useState, useEffect, useRef } from 'react';
import { createPortal } from 'react-dom';
import { useQueryClient } from '@tanstack/react-query';
import {
    Input,
    Select,
    TitledGreyBox,
    Label,
    toast,
    httpErrorToHuman,
    type SlotComponentProps,
    type RouteSlotData,
} from '@pterodactyl/sdk';
import { Clock, Calendar } from 'lucide-react';
import { updateServerExpiry } from './api';

export const PENDING_EXPIRY_STORAGE_KEY = 'pterodactyl_server_expiry_pending';

export default function ExpiryCreateSlot({ data: _slotData }: SlotComponentProps<RouteSlotData>) {
    const queryClient = useQueryClient();
    const [expiresAt, setExpiresAt] = useState('');
    const [action, setAction] = useState<'suspend' | 'delete'>('suspend');
    const [portalTarget, setPortalTarget] = useState<HTMLElement | null>(null);

    // Dynamically locate the "Core Details" box and insert our portal container immediately below it
    useEffect(() => {
        let createdTarget: HTMLElement | null = null;

        const findAndMountTarget = () => {
            const headers = Array.from(document.querySelectorAll('h2'));
            const coreDetailsHeader = headers.find(
                (h) => h.textContent?.trim() === 'Core Details'
            );
            if (!coreDetailsHeader) return false;

            const coreDetailsBox =
                coreDetailsHeader.closest<HTMLElement>('.bg-card') ??
                coreDetailsHeader.closest<HTMLElement>('.rounded-sm');

            if (!coreDetailsBox || !coreDetailsBox.parentElement) return false;

            let target = document.getElementById('se-create-portal-target');
            if (!target) {
                target = document.createElement('div');
                target.id = 'se-create-portal-target';
                coreDetailsBox.insertAdjacentElement('afterend', target);
                createdTarget = target;
            }
            setPortalTarget(target);
            return true;
        };

        if (!findAndMountTarget()) {
            const observer = new MutationObserver(() => {
                if (findAndMountTarget()) {
                    observer.disconnect();
                }
            });
            observer.observe(document.body, { childList: true, subtree: true });

            return () => {
                observer.disconnect();
                if (createdTarget?.parentElement) {
                    createdTarget.remove();
                }
            };
        }

        return () => {
            if (createdTarget?.parentElement) {
                createdTarget.remove();
            }
        };
    }, []);

    // Keep state ref and sessionStorage in sync
    const stateRef = useRef({ expiresAt, action });
    useEffect(() => {
        stateRef.current = { expiresAt, action };
        if (expiresAt) {
            try {
                sessionStorage.setItem(
                    PENDING_EXPIRY_STORAGE_KEY,
                    JSON.stringify({
                        expiresAt,
                        action,
                        createdAt: Date.now(),
                    })
                );
            } catch {
                // Ignore storage errors
            }
        } else {
            try {
                sessionStorage.removeItem(PENDING_EXPIRY_STORAGE_KEY);
            } catch {
                // Ignore storage errors
            }
        }
    }, [expiresAt, action]);

    // Also listen to form submit event to capture the latest values right when user clicks Create Server
    useEffect(() => {
        const handleFormSubmit = () => {
            if (stateRef.current.expiresAt) {
                try {
                    sessionStorage.setItem(
                        PENDING_EXPIRY_STORAGE_KEY,
                        JSON.stringify({
                            expiresAt: stateRef.current.expiresAt,
                            action: stateRef.current.action,
                            createdAt: Date.now(),
                        })
                    );
                } catch {
                    // Ignore
                }
            }
        };

        const form = document.querySelector('form');
        form?.addEventListener('submit', handleFormSubmit);
        return () => {
            form?.removeEventListener('submit', handleFormSubmit);
        };
    }, [portalTarget]);

    // Subscribe to query client mutation cache to detect server creation
    useEffect(() => {
        const unsubscribe = queryClient.getMutationCache().subscribe(async (event) => {
            if (event?.type === 'updated' && event.action?.type === 'success') {
                const mKey = event.mutation?.options?.mutationKey;
                const isCreateServer =
                    (Array.isArray(mKey) &&
                        mKey.some((k) =>
                            typeof k === 'string'
                                ? k.includes('adminCreateServer')
                                : (k as any)?._id === 'adminCreateServer'
                        )) ||
                    JSON.stringify(mKey || '').includes('adminCreateServer');

                if (isCreateServer) {
                    const responseData =
                        (event.action as any)?.data ?? event.mutation?.state?.data;
                    const createdServerId = responseData?.attributes?.id;
                    const current = stateRef.current;

                    if (createdServerId && current.expiresAt) {
                        try {
                            await updateServerExpiry(createdServerId, {
                                expires_at: new Date(current.expiresAt).toISOString(),
                                action: current.action,
                            });
                            toast.success('Server expiry configured successfully.');
                            try {
                                sessionStorage.removeItem(PENDING_EXPIRY_STORAGE_KEY);
                            } catch {
                                // Ignore
                            }
                        } catch (err) {
                            toast.error(`Failed to set server expiry: ${httpErrorToHuman(err)}`);
                        }
                    }
                }
            }
        });

        return () => {
            unsubscribe();
        };
    }, [queryClient]);

    const inputRef = useRef<HTMLInputElement>(null);

    const openDatePicker = () => {
        try {
            inputRef.current?.showPicker?.();
        } catch {
            inputRef.current?.focus();
        }
    };

    const content = (
        <TitledGreyBox title="Server Expiry" icon={Clock}>
            <div className="space-y-4">
                <p className="text-sm text-muted-foreground">
                    Optionally set an expiration date for this server. When the expiration date is reached,
                    the panel will automatically execute the selected action (suspend or delete).
                </p>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-start">
                    {/* Left column: Date & Time */}
                    <div className="space-y-2">
                        <Label htmlFor="se-create-expires-at">Server Expire At</Label>
                        <div
                            style={{ position: 'relative' }}
                            className="relative flex items-center w-full rounded-sm border border-input bg-input transition-colors duration-150 hover:border-input focus-within:shadow-md focus-within:border-primary focus-within:ring-2 focus-within:ring-ring/50"
                        >
                            <input
                                ref={inputRef}
                                id="se-create-expires-at"
                                type="datetime-local"
                                value={expiresAt}
                                onChange={(e) => setExpiresAt(e.target.value)}
                                onClick={openDatePicker}
                                style={{ colorScheme: 'dark' }}
                                className="se-datetime-input w-full min-w-0 appearance-none border-0 bg-transparent p-3 pr-10 text-sm text-foreground outline-hidden focus:ring-0 focus:outline-hidden cursor-pointer"
                            />
                            <div
                                style={{
                                    position: 'absolute',
                                    right: 0,
                                    top: 0,
                                    height: '100%',
                                    width: '2.5rem',
                                    display: 'flex',
                                    alignItems: 'center',
                                    justifyContent: 'center',
                                    pointerEvents: 'none',
                                }}
                                className="text-muted-foreground"
                            >
                                <Calendar className="w-4 h-4" />
                            </div>
                        </div>
                        <p className="text-xs text-muted-foreground pt-0.5">
                            Leave blank if the server should never expire.
                        </p>
                    </div>

                    {/* Right column: Action */}
                    <div className="space-y-2">
                        <Label htmlFor="se-create-action">Action on Expiry</Label>
                        <Select
                            id="se-create-action"
                            value={action}
                            onChange={(v) => setAction(v as 'suspend' | 'delete')}
                            options={[
                                { value: 'suspend', label: 'Suspend server' },
                                { value: 'delete', label: 'Remove permanently' },
                            ]}
                        />
                        <p className="text-xs text-muted-foreground pt-0.5">
                            Choose whether to suspend the server or delete it permanently upon expiry.
                        </p>
                    </div>
                </div>
            </div>
        </TitledGreyBox>
    );

    if (portalTarget) {
        return createPortal(content, portalTarget);
    }

    // Fallback if portal target is not mounted yet or not found
    return <div className="mt-6">{content}</div>;
}
