<?php

declare(strict_types=1);

namespace ServerExpiry\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Carbon;

/**
 * @property int         $id
 * @property int         $server_id
 * @property Carbon|null $expires_at
 * @property string      $action       'suspend' or 'delete'
 * @property Carbon|null $created_at
 * @property Carbon|null $updated_at
 */
class ServerExpiry extends Model
{
    protected $table = 'ext_server_expiry';

    protected $fillable = ['server_id', 'expires_at', 'action'];

    protected function casts(): array
    {
        return [
            'expires_at' => 'datetime',
        ];
    }
}
