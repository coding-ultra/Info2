<?php

declare(strict_types=1);

namespace ServerExpiry\Commands;

use Illuminate\Console\Command;
use ServerExpiry\Jobs\ProcessServerExpiries;

class ProcessServerExpiryCommand extends Command
{
    /**
     * The name and signature of the console command.
     * Must begin with the extension id 'server-expiry:'.
     */
    protected $signature = 'server-expiry:process';

    /**
     * The console command description.
     */
    protected $description = 'Process expired servers and execute their configured expiry action (suspend or delete).';

    /**
     * Execute the console command.
     */
    public function handle(): int
    {
        $this->info('Processing expired servers...');

        dispatch_sync(new ProcessServerExpiries());

        $this->info('Expired servers processed successfully.');

        return self::SUCCESS;
    }
}
