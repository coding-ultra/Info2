<?php

declare(strict_types=1);

namespace ServerExpiry;

use Illuminate\Console\Scheduling\Schedule;
use Illuminate\Support\Facades\Route;
use Pterodactyl\Contracts\Servers\CreatesServers;
use Pterodactyl\Contracts\Servers\UpdatesServerDetails;
use Pterodactyl\Extensions\ExtensionProvider;
use Pterodactyl\Http\Middleware\RequireTwoFactorAuthentication;
use Pterodactyl\Models\Server;
use ServerExpiry\Actions\CreatesServersDecorator;
use ServerExpiry\Actions\UpdatesServerDetailsDecorator;
use ServerExpiry\Commands\ProcessServerExpiryCommand;
use ServerExpiry\Fields\ServerExpiryFields;
use ServerExpiry\Http\Controllers\ServerExpiryController;
use ServerExpiry\Jobs\ProcessServerExpiries;

class ServerExpiryProvider extends ExtensionProvider
{
    public function register(): void
    {
        // No container bindings needed.
    }

    public function boot(): void
    {
        // Register official extension fields on Server model for Admin and Application APIs
        $this->registerFields(Server::class, ServerExpiryFields::class);

        // Mount route files from routes/ (client.php, admin.php, application.php)
        $this->registerApiRoutes();

        // Run the extension's database migrations when enabled.
        $this->loadExtensionMigrations();

        // Register artisan commands prefixed with server-expiry:
        $this->registerCommands([
            ProcessServerExpiryCommand::class,
        ]);

        // Automatically process expiring servers on schedule.
        $this->registerSchedule(function (Schedule $schedule): void {
            $schedule->job(new ProcessServerExpiries())->everyMinute();
        });

        // Wrap the CreatesServers action to handle expiry parameters passed during creation
        $this->wrapAction(CreatesServers::class, function (CreatesServers $inner): CreatesServers {
            return new CreatesServersDecorator($inner);
        });

        // Wrap the UpdatesServerDetails action to handle expiry parameters passed during server detail updates
        $this->wrapAction(UpdatesServerDetails::class, function (UpdatesServerDetails $inner): UpdatesServerDetails {
            return new UpdatesServerDetailsDecorator($inner);
        });

        // Direct Application API routes for custom panels accessing /api/application/servers/{server}/expiry
        // Note: DELETE is handled at /api/application/extensions/server-expiry/servers/{server} or via PATCH with expires_at: null
        // to avoid colliding with Pterodactyl core's /{server:id}/{force?} delete route.
        Route::middleware([
            'api',
            RequireTwoFactorAuthentication::class,
            'application-api',
            'throttle:api.application',
        ])
            ->prefix('/api/application/servers')
            ->group(function (): void {
                Route::get('/external/{external_id}/expiry', [ServerExpiryController::class, 'showByExternalId']);
                Route::match(['put', 'patch', 'post'], '/external/{external_id}/expiry', [ServerExpiryController::class, 'updateByExternalId']);

                Route::get('/{server}/expiry', [ServerExpiryController::class, 'show']);
                Route::match(['put', 'patch', 'post'], '/{server}/expiry', [ServerExpiryController::class, 'update']);
            });
    }
}
