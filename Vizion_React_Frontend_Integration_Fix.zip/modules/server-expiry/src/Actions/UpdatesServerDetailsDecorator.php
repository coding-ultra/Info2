<?php

declare(strict_types=1);

namespace ServerExpiry\Actions;

use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Log;
use Pterodactyl\Contracts\Servers\TogglesServerSuspension;
use Pterodactyl\Contracts\Servers\UpdatesServerDetails;
use Pterodactyl\Models\Server;
use Pterodactyl\Services\Extensions\ValidatedExtensionValues;
use ServerExpiry\Models\ServerExpiry;
use Throwable;

final readonly class UpdatesServerDetailsDecorator implements UpdatesServerDetails
{
    public function __construct(private UpdatesServerDetails $inner)
    {
    }

    public function update(Server $server, array $input): Server
    {
        // Extract raw array extensions if passed directly by caller rather than FormRequest
        $rawExtExpiry = null;
        if (isset($input['extensions']) && is_array($input['extensions'])) {
            $rawExtExpiry = $input['extensions']['server-expiry'] ?? null;
            // Unset or replace with none() so inner action does not throw InvalidArgumentException
            unset($input['extensions']);
        }

        $updated = $this->inner->update($server, $input);

        // Check if top-level expiry parameters were passed directly in payload or request
        $expiresAt = $rawExtExpiry['expires_at']
            ?? $input['expires_at']
            ?? $input['server_expire_at']
            ?? $input['expiration_date']
            ?? $input['expiry_date']
            ?? request()->input('expires_at')
            ?? request()->input('server_expire_at')
            ?? request()->input('expiration_date')
            ?? request()->input('expiry_date')
            ?? request()->input('server_expiry.expires_at');

        $action = $rawExtExpiry['action']
            ?? $input['action']
            ?? $input['expiry_action']
            ?? request()->input('action')
            ?? request()->input('expiry_action')
            ?? request()->input('server_expiry.action');

        $hasExpiryInput = $rawExtExpiry !== null
            || array_key_exists('expires_at', $input)
            || array_key_exists('server_expire_at', $input)
            || array_key_exists('expiration_date', $input)
            || array_key_exists('expiry_date', $input)
            || request()->has('expires_at')
            || request()->has('server_expire_at')
            || request()->has('expiration_date')
            || request()->has('expiry_date')
            || request()->has('server_expiry.expires_at');

        if ($hasExpiryInput || $action !== null) {
            $existing = ServerExpiry::query()->where('server_id', $updated->id)->first();
            $actionToSet = $action ?? $existing?->action ?? 'suspend';
            if (!in_array($actionToSet, ['suspend', 'delete'], true)) {
                $actionToSet = 'suspend';
            }

            if (!empty($expiresAt)) {
                try {
                    $parsed = Carbon::parse($expiresAt);
                    ServerExpiry::query()->updateOrCreate(
                        ['server_id' => $updated->id],
                        [
                            'expires_at' => $parsed,
                            'action'     => $actionToSet,
                        ]
                    );
                    $this->unsuspendIfSuspended($updated, (string) $expiresAt);
                } catch (Throwable $e) {
                    Log::error("[ServerExpiry] Failed setting expiry on server update: " . $e->getMessage());
                }
            } elseif ($hasExpiryInput && empty($expiresAt)) {
                // Explicitly provided null or empty string: remove expiry
                ServerExpiry::query()->where('server_id', $updated->id)->delete();
            }
        }

        return $updated;
    }

    private function unsuspendIfSuspended(Server $server, ?string $expiresAt): void
    {
        if (empty($expiresAt)) {
            return;
        }

        try {
            $parsed = Carbon::parse($expiresAt);
            if ($parsed->isFuture() && $server->isSuspended()) {
                /** @var TogglesServerSuspension $suspension */
                $suspension = app(TogglesServerSuspension::class);
                $suspension->toggle($server, TogglesServerSuspension::ACTION_UNSUSPEND);
                $server->refresh();

                if (class_exists(\Pterodactyl\Facades\Activity::class)) {
                    \Pterodactyl\Facades\Activity::event('admin:server.unsuspend')
                        ->subject($server)
                        ->property('name', $server->name)
                        ->log();
                }
            }
        } catch (Throwable $e) {
            Log::error("[ServerExpiry] Failed to auto-unsuspend server {$server->id}: " . $e->getMessage(), [
                'exception' => $e,
            ]);
        }
    }
}
