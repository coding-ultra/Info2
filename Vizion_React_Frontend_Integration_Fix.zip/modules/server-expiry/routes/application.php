<?php

declare(strict_types=1);

use Illuminate\Support\Facades\Route;
use ServerExpiry\Http\Controllers\ServerExpiryController;

/*
|--------------------------------------------------------------------------
| Server Expiry — Application API Routes
|--------------------------------------------------------------------------
| Mounted at: /api/application/extensions/server-expiry/
| Access:     Root administrators and Application API keys.
|
| GET    /api/application/extensions/server-expiry/servers
| POST   /api/application/extensions/server-expiry/servers
| GET    /api/application/extensions/server-expiry/servers/external/{external_id}
| PATCH  /api/application/extensions/server-expiry/servers/external/{external_id}
| PUT    /api/application/extensions/server-expiry/servers/external/{external_id}
| POST   /api/application/extensions/server-expiry/servers/external/{external_id}
| DELETE /api/application/extensions/server-expiry/servers/external/{external_id}
| GET    /api/application/extensions/server-expiry/servers/{server}
| PATCH  /api/application/extensions/server-expiry/servers/{server}
| PUT    /api/application/extensions/server-expiry/servers/{server}
| POST   /api/application/extensions/server-expiry/servers/{server}
| DELETE /api/application/extensions/server-expiry/servers/{server}
*/

Route::get('/servers', [ServerExpiryController::class, 'index']);
Route::post('/servers', [ServerExpiryController::class, 'store']);

Route::get('/servers/external/{external_id}', [ServerExpiryController::class, 'showByExternalId']);
Route::match(['put', 'patch', 'post'], '/servers/external/{external_id}', [ServerExpiryController::class, 'updateByExternalId']);
Route::delete('/servers/external/{external_id}', [ServerExpiryController::class, 'destroyByExternalId']);

Route::get('/servers/{server}', [ServerExpiryController::class, 'show']);
Route::match(['put', 'patch', 'post'], '/servers/{server}', [ServerExpiryController::class, 'update']);
Route::delete('/servers/{server}', [ServerExpiryController::class, 'destroy']);
