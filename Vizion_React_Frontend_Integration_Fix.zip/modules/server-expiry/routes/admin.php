<?php

declare(strict_types=1);

use Illuminate\Support\Facades\Route;
use ServerExpiry\Http\Controllers\ServerExpiryController;

/*
|--------------------------------------------------------------------------
| Server Expiry — Admin API Routes
|--------------------------------------------------------------------------
| Mounted at: /api/admin/extensions/server-expiry/
| Access:     Admin authenticated sessions & root administrators.
|
| GET    /api/admin/extensions/server-expiry/servers
| POST   /api/admin/extensions/server-expiry/servers
| GET    /api/admin/extensions/server-expiry/servers/external/{external_id}
| PATCH  /api/admin/extensions/server-expiry/servers/external/{external_id}
| PUT    /api/admin/extensions/server-expiry/servers/external/{external_id}
| POST   /api/admin/extensions/server-expiry/servers/external/{external_id}
| DELETE /api/admin/extensions/server-expiry/servers/external/{external_id}
| GET    /api/admin/extensions/server-expiry/servers/{server}
| PATCH  /api/admin/extensions/server-expiry/servers/{server}
| PUT    /api/admin/extensions/server-expiry/servers/{server}
| POST   /api/admin/extensions/server-expiry/servers/{server}
| DELETE /api/admin/extensions/server-expiry/servers/{server}
*/

Route::get('/servers', [ServerExpiryController::class, 'index']);
Route::post('/servers', [ServerExpiryController::class, 'store']);

Route::get('/servers/external/{external_id}', [ServerExpiryController::class, 'showByExternalId']);
Route::match(['put', 'patch', 'post'], '/servers/external/{external_id}', [ServerExpiryController::class, 'updateByExternalId']);
Route::delete('/servers/external/{external_id}', [ServerExpiryController::class, 'destroyByExternalId']);

Route::get('/servers/{server}', [ServerExpiryController::class, 'show']);
Route::match(['put', 'patch', 'post'], '/servers/{server}', [ServerExpiryController::class, 'update']);
Route::delete('/servers/{server}', [ServerExpiryController::class, 'destroy']);
