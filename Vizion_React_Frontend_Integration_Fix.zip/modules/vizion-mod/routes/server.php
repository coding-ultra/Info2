<?php

use VizionMod\Http\Controllers\BrowseController;
use VizionMod\Http\Controllers\InstalledController;
use Illuminate\Support\Facades\Route;

// Final URLs: /api/client/servers/{server}/extensions/vizion-mod/...
// Whether Mod is shown for this server's egg (Minecraft category rule + admin overrides).
Route::get('/availability', [BrowseController::class, 'availability'])->name('availability');
Route::get('/meta', [BrowseController::class, 'meta'])->name('meta');
Route::get('/search', [BrowseController::class, 'search'])->name('search');
Route::get('/projects/{project}', [BrowseController::class, 'details'])->where('project', '[A-Za-z0-9_.-]+')->name('details');
Route::get('/projects/{project}/versions', [BrowseController::class, 'versions'])->where('project', '[A-Za-z0-9_.-]+')->name('versions');
Route::get('/versions/{version}', [BrowseController::class, 'version'])->where('version', '[A-Za-z0-9_.-]+')->name('version');

// Which jars were installed through Mod (kept per server, so reinstall works from any browser).
Route::get('/installed', [InstalledController::class, 'index'])->name('installed.index');
Route::post('/installed', [InstalledController::class, 'store'])->name('installed.store');
Route::post('/installed/forget', [InstalledController::class, 'forget'])->name('installed.forget');
