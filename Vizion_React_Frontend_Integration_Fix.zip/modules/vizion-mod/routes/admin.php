<?php

use VizionMod\Http\Controllers\AdminSettingsController;
use Illuminate\Support\Facades\Route;

// Final URLs: /api/admin/extensions/vizion-mod/... (root administrators only)
Route::get('/display', [AdminSettingsController::class, 'show'])->name('display.show');
Route::put('/display', [AdminSettingsController::class, 'update'])->name('display.update');
// A handful of real Modrinth mods for the live preview on the settings page.
Route::get('/preview', [AdminSettingsController::class, 'preview'])->name('display.preview');
// Every egg with its tags, for the per-egg show/hide switches.
Route::get('/eggs', [AdminSettingsController::class, 'eggs'])->name('display.eggs');
