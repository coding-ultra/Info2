<?php

namespace VizionMod\Services;

use RuntimeException;

class ModrinthUnavailableException extends RuntimeException {}
