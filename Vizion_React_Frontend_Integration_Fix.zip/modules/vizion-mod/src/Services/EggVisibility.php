<?php

namespace VizionMod\Services;

use VizionMod\Settings\DisplaySettings;
use Pterodactyl\Models\Egg;
use Pterodactyl\Models\Server;

/**
 * Decides whether Mod is available on a server, from the server's egg.
 *
 * Order of rules:
 *   1. An administrator override for that egg ("show" or "hide") always wins.
 *   2. Otherwise, when "require_minecraft" is on (the default), only Minecraft eggs are shown: tagged "minecraft",
 *      or named after a vanilla / performance server (Paper, Purpur...) or a modded one (Forge, Fabric...).
 *   3. Otherwise every egg is shown.
 */
final class EggVisibility
{
    public const CATEGORY_TAG = 'minecraft';

    /** Egg names that count as Minecraft even when the egg has no "minecraft" tag. Matched as whole words. */
    public const VANILLA_AND_PERFORMANCE = [
        'vanilla', 'paper', 'purpur', 'pufferfish', 'leaves', 'spigot', 'bukkit', 'craftbukkit', 'folia',
        'airplane', 'gale', 'luminol', 'canvasmc', 'glowstone', 'cuberite',
    ];

    public const MODDED_JAVA = [
        'forge', 'neoforge', 'fabric', 'quilt', 'liteloader', 'babric', 'cleanroom', 'arclight', 'mohist',
        'magma', 'youer', 'catserver', 'spongeforge', 'spongevanilla', 'banner', 'crucible',
    ];

    public const GROUP_VANILLA = 'Vanilla & performance';

    public const GROUP_MODDED = 'Modded (Java)';

    public function __construct(private readonly DisplaySettings $settings) {}

    /** Which server family an egg name belongs to ("Paper 1.21" -> vanilla & performance), or null. */
    public static function groupOfName(string $name): ?string
    {
        $words = ' '.trim(preg_replace('/[^a-z0-9]+/', ' ', mb_strtolower($name)) ?? '').' ';
        $has = static function (array $list) use ($words): bool {
            foreach ($list as $word) {
                if (str_contains($words, ' '.$word.' ')) {
                    return true;
                }
            }

            return false;
        };

        if ($has(self::MODDED_JAVA)) {
            return self::GROUP_MODDED;
        }
        if ($has(self::VANILLA_AND_PERFORMANCE)) {
            return self::GROUP_VANILLA;
        }

        return str_contains($words, 'minecraft') ? 'Minecraft' : null;
    }

    /** A Minecraft egg: tagged "minecraft", or named after one of the server types above. */
    public static function matches(array $tags, string $name): bool
    {
        return self::isMinecraft($tags) || self::groupOfName($name) !== null;
    }

    /** @return list<string> the egg's tags, lower-cased (Pterodactyl 2.0 groups eggs into categories with tags) */
    public static function tagsOf(?Egg $egg): array
    {
        $tags = $egg?->tags ?? [];
        if (is_string($tags)) {
            $decoded = json_decode($tags, true);
            $tags = is_array($decoded) ? $decoded : [];
        }

        return array_values(array_map(
            static fn ($tag) => mb_strtolower(trim((string) $tag)),
            array_filter((array) $tags, 'is_scalar'),
        ));
    }

    /** True when any tag is (or contains) "minecraft", e.g. "minecraft" or "minecraft-java". */
    public static function isMinecraft(array $tags): bool
    {
        foreach ($tags as $tag) {
            if (str_contains((string) $tag, self::CATEGORY_TAG)) {
                return true;
            }
        }

        return false;
    }

    /**
     * @param list<string> $tags
     * @return array{enabled: bool, reason: string}  reason: override | category | all
     */
    public function decide(int $eggId, array $tags, string $name = ''): array
    {
        $config = $this->settings->all();
        $override = $config['egg_overrides'][(string) $eggId] ?? null;

        if ($override === 'show' || $override === 'hide') {
            return ['enabled' => $override === 'show', 'reason' => 'override'];
        }

        if ($config['require_minecraft']) {
            return ['enabled' => self::matches($tags, $name), 'reason' => 'category'];
        }

        return ['enabled' => true, 'reason' => 'all'];
    }

    /** @return array{enabled: bool, reason: string} */
    public function forServer(Server $server): array
    {
        return $this->decide((int) $server->egg_id, self::tagsOf($server->egg), (string) ($server->egg?->name ?? ''));
    }

    public function abortUnlessAllowed(Server $server): void
    {
        abort_unless($this->forServer($server)['enabled'], 403, 'Mod is not available for this server\'s egg.');
    }
}
