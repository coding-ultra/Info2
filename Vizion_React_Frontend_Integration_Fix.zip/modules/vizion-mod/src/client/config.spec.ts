import { expect, test } from 'vitest';
import { getInstallDirectory, getLayout, parseSettings, setConfig } from './config';

test('falls back to defaults when the public config is empty', () => {
    setConfig({});
    expect(getInstallDirectory()).toBe('/mods');
    expect(getLayout()).toMatchObject({ layout: 'card', columns: 3, show_background: true, overlay_opacity: 75, blur_enabled: false });
});

test('reads administrator settings and clamps them', () => {
    setConfig({ install_directory: '/mods/', layout: 'row', columns: 4, show_background: false, overlay_opacity: 0, blur_amount: 99 });
    expect(getInstallDirectory()).toBe('/mods');
    expect(getLayout()).toMatchObject({ layout: 'row', columns: 4, show_background: false, show_overlay: false, blur_enabled: true, blur_amount: 40 });
});

test('rejects an unsafe install directory and bad column counts', () => {
    setConfig({ install_directory: '../etc', columns: 9 });
    expect(getInstallDirectory()).toBe('/mods');
    expect(getLayout().columns).toBe(4);
});

test('parses a server\'s effective settings with the same rules', () => {
    const settings = parseSettings({ install_directory: '/plugins/', layout: 'row', columns: 3, show_background: false, overlay_opacity: 40, blur_amount: 8 });
    expect(settings.directory).toBe('/plugins');
    expect(settings.layout).toMatchObject({ layout: 'row', columns: 3, show_background: false, overlay_opacity: 40, blur_enabled: true, blur_amount: 8 });
});

test('refuses a directory that climbs out of the server root', () => {
    expect(parseSettings({ install_directory: '/mods/../..' }).directory).toBe('/mods');
});
