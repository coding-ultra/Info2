export interface LayoutSettings {
    layout: 'card' | 'row';
    columns: number;
    show_background: boolean;
    show_overlay: boolean;
    overlay_opacity: number;
    blur_enabled: boolean;
    blur_amount: number;
}

export const DEFAULT_LAYOUT: LayoutSettings = {
    layout: 'card',
    columns: 3,
    show_background: true,
    show_overlay: true,
    overlay_opacity: 75,
    blur_enabled: false,
    blur_amount: 0,
};

/** Grid classes for the result list. All of them exist in the extension stylesheet. */
export function gridClass(settings: LayoutSettings): string {
    if (settings.layout === 'row') return 'dm:grid dm:grid-cols-1 dm:gap-3';
    if (settings.columns === 3) return 'dm:grid dm:grid-cols-1 dm:gap-3 dm:sm:grid-cols-2 dm:lg:grid-cols-3';
    if (settings.columns === 4) return 'dm:grid dm:grid-cols-1 dm:gap-3 dm:sm:grid-cols-2 dm:lg:grid-cols-4';
    return 'dm:grid dm:grid-cols-1 dm:gap-3 dm:sm:grid-cols-2';
}

/**
 * Style for the image behind a card or row. The blur comes only from the settings and is the same for
 * every mod, whatever kind of image it has: blur off means no blur anywhere. When blurred, the image is
 * scaled up a little so the soft edges never show a lighter border.
 */
export function backgroundImageStyle(settings: LayoutSettings): { filter?: string; transform?: string } {
    const blur = settings.blur_enabled ? settings.blur_amount : 0;
    return blur > 0 ? { filter: `blur(${blur}px)`, transform: `scale(${1 + blur / 50})` } : {};
}
