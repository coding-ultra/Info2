import { Button } from '@pterodactyl/sdk';
import type { Mod } from '../api';
import { formatCount } from '../detect';
import { backgroundImageStyle, type LayoutSettings } from '../layout';

interface Props {
    mod: Mod;
    canInstall: boolean;
    onInstall: (mod: Mod) => void;
    /** When set, a "Read more" button opens the details popup. */
    onReadMore?: (mod: Mod) => void;
    settings: LayoutSettings;
}

const iconBase = {
    display: 'inline-flex',
    alignItems: 'center',
    justifyContent: 'center',
    width: '1.5rem',
    height: '1.5rem',
    borderRadius: '0.375rem',
    cursor: 'pointer',
    padding: 0,
} as const;

const svgProps = { width: 14, height: 14, viewBox: '0 0 24 24', fill: 'none', stroke: 'currentColor', strokeWidth: 2, strokeLinecap: 'round', strokeLinejoin: 'round', 'aria-hidden': true } as const;

const oneLine = { whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' } as const;
const lines = (n: number) =>
    ({ display: '-webkit-box', WebkitLineClamp: n, WebkitBoxOrient: 'vertical', overflow: 'hidden', textOverflow: 'ellipsis' }) as const;

export default function ModCard({ mod, canInstall, onInstall, onReadMore, settings }: Props) {
    const row = settings.layout === 'row';
    // Four cards per row leave little width: stack the content and cut long text with "...".
    const compact = !row && settings.columns === 4;
    const image = settings.show_background ? (mod.banner_url ?? mod.icon_url) : null;

    // The same blur for every mod, whatever its image: blur off means no blur at all.
    const imageStyle = backgroundImageStyle(settings);
    const alpha = settings.overlay_opacity / 100;
    const overlay = `linear-gradient(to right, rgba(0,0,0,${alpha}), rgba(0,0,0,${(alpha * 0.7).toFixed(2)}))`;

    // Light text whenever there is an image behind it; a shadow keeps it legible without an overlay.
    const shadow = image && !settings.show_overlay ? '0 1px 3px rgba(0,0,0,0.85)' : undefined;
    const title = image ? { color: '#fff', textShadow: shadow } : undefined;
    const muted = image ? { color: 'rgba(255,255,255,0.8)', textShadow: shadow } : undefined;

    const iconSize = row ? 'dm:h-10 dm:w-10' : 'dm:h-14 dm:w-14';
    const icon = mod.icon_url ? (
        <img src={mod.icon_url} alt={''} loading={'lazy'} className={`dm:relative dm:shrink-0 dm:rounded-md ${iconSize}`} />
    ) : (
        <div className={`dm:relative dm:shrink-0 dm:rounded-md dm:border dm:border-border ${iconSize}`} />
    );

    const titleLink = (
        <a
            href={`https://modrinth.com/mod/${mod.slug}`}
            target={'_blank'}
            rel={'noreferrer noopener'}
            className={'dm:font-semibold dm:text-foreground dm:hover:underline'}
            style={compact ? { ...title, ...oneLine, display: 'block' } : title}
        >
            {mod.title}
        </a>
    );
    const author = (
        <span className={'dm:text-xs dm:text-muted-foreground'} style={compact ? { ...muted, ...oneLine, display: 'block' } : muted}>
            by {mod.author}
        </span>
    );
    const description = (
        <p className={'dm:mt-1 dm:text-sm dm:text-muted-foreground'} style={{ ...muted, ...(row ? oneLine : lines(2)) }}>
            {mod.description}
        </p>
    );
    const stats = (
        <p className={`dm:text-xs dm:text-muted-foreground ${row ? 'dm:mt-1' : 'dm:mt-2'}`} style={{ ...muted, ...oneLine }}>
            {formatCount(mod.downloads)} downloads · {formatCount(mod.follows)} follows
            {mod.categories.length > 0 && ` · ${mod.categories.join(', ')}`}
            {mod.server_side !== 'unknown' && ` · server: ${mod.server_side}`}
        </p>
    );
    // Small round icons: all mod details, and the Modrinth page.
    const iconStyle = image
        ? { ...iconBase, color: '#fff', background: 'rgba(0,0,0,0.45)', border: '1px solid rgba(255,255,255,0.35)' }
        : { ...iconBase, color: 'var(--foreground)', background: 'transparent', border: '1px solid var(--border)' };
    const iconButtons = (
        <span className={'dm:relative dm:flex dm:items-center dm:gap-1'} style={{ flexShrink: 0 }}>
            {onReadMore && (
                <button type={'button'} title={'Show all details'} aria-label={`Show details of ${mod.title}`} style={iconStyle} onClick={() => onReadMore(mod)}>
                    <svg {...svgProps}>
                        <circle cx={'12'} cy={'12'} r={'10'} />
                        <path d={'M12 16v-4M12 8h.01'} />
                    </svg>
                </button>
            )}
            <a
                href={`https://modrinth.com/mod/${mod.slug}`}
                target={'_blank'}
                rel={'noreferrer noopener'}
                title={'Open on Modrinth'}
                aria-label={`Open ${mod.title} on Modrinth`}
                style={{ ...iconStyle, textDecoration: 'none' }}
            >
                <svg {...svgProps}>
                    <path d={'M15 3h6v6M10 14 21 3M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6'} />
                </svg>
            </a>
        </span>
    );

    // "Read more" is a small text link, and only where the card is too narrow for the full text:
    // cards with 3 or 4 per row and rows. Cards with 2 per row have the icon instead.
    const readMore = onReadMore && (row || settings.columns >= 3) && (
        <button
            type={'button'}
            onClick={() => onReadMore(mod)}
            className={'dm:relative dm:text-xs'}
            style={{ background: 'none', border: 0, padding: 0, cursor: 'pointer', textDecoration: 'underline', color: image ? 'rgba(255,255,255,0.85)' : 'var(--muted-foreground)' }}
        >
            Read more
        </button>
    );

    const buttons = (
        <div className={'dm:relative dm:flex dm:items-center dm:gap-2'}>
            {row && iconButtons}
            <Button size={'small'} disabled={!canInstall} onClick={() => onInstall(mod)}>
                Install
            </Button>
        </div>
    );

    const background = image && (
        <>
            <img
                src={image}
                alt={''}
                aria-hidden={true}
                loading={'lazy'}
                className={'dm:absolute dm:inset-0 dm:h-full dm:w-full dm:object-cover'}
                style={imageStyle}
            />
            {settings.show_overlay && <div aria-hidden={true} className={'dm:absolute dm:inset-0'} style={{ background: overlay }} />}
        </>
    );

    if (compact) {
        return (
            <li className={'dm:relative dm:flex dm:flex-col dm:gap-2 dm:overflow-hidden dm:rounded-md dm:border dm:border-border dm:bg-card dm:p-3'}>
                {background}
                <div className={'dm:absolute'} style={{ top: '0.5rem', right: '0.5rem' }}>
                    {iconButtons}
                </div>
                <div className={'dm:relative dm:flex dm:items-center dm:gap-3'} style={{ paddingRight: '3.5rem' }}>
                    {icon}
                    <div className={'dm:min-w-0 dm:flex-1'}>
                        {titleLink}
                        {author}
                    </div>
                </div>
                <div className={'dm:relative dm:min-w-0 dm:flex-1'}>
                    {description}
                    {stats}
                    {readMore && <div className={'dm:mt-2'}>{readMore}</div>}
                </div>
                {buttons}
            </li>
        );
    }

    return (
        <li
            className={`dm:relative dm:flex dm:gap-3 dm:overflow-hidden dm:rounded-md dm:border dm:border-border dm:bg-card ${
                row ? 'dm:items-center dm:p-2' : 'dm:items-start dm:p-3'
            }`}
        >
            {background}
            {!row && (
                <div className={'dm:absolute'} style={{ top: '0.5rem', right: '0.5rem' }}>
                    {iconButtons}
                </div>
            )}
            {icon}
            <div className={'dm:relative dm:min-w-0 dm:flex-1'} style={row ? undefined : { paddingRight: '3.5rem' }}>
                <div className={'dm:flex dm:flex-wrap dm:items-baseline dm:gap-x-2'}>
                    {titleLink}
                    {author}
                </div>
                {description}
                {stats}
                {readMore && <div className={'dm:mt-2'}>{readMore}</div>}
            </div>
            <div style={row ? undefined : { alignSelf: 'flex-end' }}>{buttons}</div>
        </li>
    );
}
