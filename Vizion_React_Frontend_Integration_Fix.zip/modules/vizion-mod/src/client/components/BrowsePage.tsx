import { useEffect, useRef, useState } from 'react';
import { keepPreviousData, useQuery } from '@tanstack/react-query';
import {
    Alert,
    Input,
    Label,
    Pagination,
    Select,
    Spinner,
    Switch,
    TitledGreyBox,
    httpErrorToHuman,
    useCurrentServerRequired,
    useServerPermission,
    useServerStartup,
} from '@pterodactyl/sdk';
import { getMeta, searchMods, type Mod } from '../api';
import type { ModSettings } from '../config';
import { gridClass } from '../layout';
import { detectGameVersion, detectLoader, detectLoaderFromVariables } from '../detect';
import InstallDialog from './InstallDialog';
import ModCard from './ModCard';
import ModDetailsDialog from './ModDetailsDialog';

const ANY = 'any';
const SORTS = [
    { value: 'relevance', label: 'Relevance' },
    { value: 'downloads', label: 'Downloads' },
    { value: 'follows', label: 'Follows' },
    { value: 'newest', label: 'Newest' },
    { value: 'updated', label: 'Recently updated' },
];

export default function BrowsePage({ settings }: { settings: ModSettings }) {
    const server = useCurrentServerRequired();
    const uuid = server.attributes.uuid;
    const canInstall = useServerPermission(['file.create', 'file.update'], false);
    const layout = settings.layout;

    const [text, setText] = useState('');
    const [query, setQuery] = useState('');
    const [loader, setLoader] = useState(detectLoader(server.attributes.egg_tags));
    const [gameVersion, setGameVersion] = useState('');
    const [category, setCategory] = useState('');
    const [sort, setSort] = useState('relevance');
    const [serverOnly, setServerOnly] = useState(true);
    const [page, setPage] = useState(1);
    const [installing, setInstalling] = useState<Mod | null>(null);
    const [reading, setReading] = useState<Mod | null>(null);

    // Debounce typing, and always return to page one when filters change.
    useEffect(() => {
        const timer = setTimeout(() => {
            setQuery(text.trim());
            setPage(1);
        }, 350);
        return () => clearTimeout(timer);
    }, [text]);

    // Preselect the server's Minecraft version and loader once, if the startup variables reveal them.
    const startup = useServerStartup(uuid, (data) => {
        const variables = data.data.map((v) => v.attributes);
        return { version: detectGameVersion(variables), loader: detectLoaderFromVariables(variables) };
    });
    const preselected = useRef(false);
    useEffect(() => {
        const detected = startup.data;
        if (!preselected.current && detected) {
            preselected.current = true;
            setGameVersion(detected.version);
            setLoader((current) => current || detected.loader);
        }
    }, [startup.data]);

    const meta = useQuery({ queryKey: ['vizion-mod', 'meta', uuid], queryFn: () => getMeta(uuid), staleTime: 60 * 60 * 1000, enabled: canInstall });

    const results = useQuery({
        queryKey: ['vizion-mod', 'search', uuid, query, loader, gameVersion, category, sort, serverOnly, page],
        queryFn: () => searchMods(uuid, { query, loader, gameVersion, category, sort, serverOnly, page }),
        placeholderData: keepPreviousData,
        enabled: canInstall,
    });

    const change = <T,>(set: (value: T) => void) => (value: T) => {
        set(value);
        setPage(1);
    };
    const orAny = (value: string | number) => (value === ANY ? '' : String(value));

    return (
        <>
            <div className={'dm:grid dm:gap-4'}>
                {!canInstall && <Alert type={'warning'}>You need the file create and file update permissions to install mods on this server.</Alert>}

                <TitledGreyBox title={'Find mods on Modrinth'}>
                    <div className={'dm:grid dm:gap-3 dm:sm:grid-cols-2 dm:lg:grid-cols-5'}>
                        <div className={'dm:sm:col-span-2 dm:lg:col-span-2'}>
                            <Label>Search</Label>
                            <Input value={text} onChange={(e) => setText(e.target.value)} placeholder={'e.g. Lithium, Fabric API, Create…'} />
                        </div>
                        <div>
                            <Label>Mod loader</Label>
                            <Select
                                value={loader || ANY}
                                onChange={(v) => change(setLoader)(orAny(v))}
                                options={[{ value: ANY, label: 'Any mod loader' }, ...(meta.data?.loaders ?? []).map((l) => ({ value: l.id, label: l.name }))]}
                            />
                        </div>
                        <div>
                            <Label>Minecraft version</Label>
                            <Select
                                value={gameVersion || ANY}
                                onChange={(v) => change(setGameVersion)(orAny(v))}
                                searchPlaceholder={'Search versions…'}
                                options={[{ value: ANY, label: 'Any version' }, ...(meta.data?.game_versions ?? []).map((v) => ({ value: v, label: v }))]}
                            />
                        </div>
                        <div>
                            <Label>Category</Label>
                            <Select
                                value={category || ANY}
                                onChange={(v) => change(setCategory)(orAny(v))}
                                options={[{ value: ANY, label: 'All categories' }, ...(meta.data?.categories ?? []).map((c) => ({ value: c, label: c.replace(/-/g, ' ') }))]}
                            />
                        </div>
                        <div>
                            <Label>Sort by</Label>
                            <Select value={sort} onChange={(v) => change(setSort)(String(v))} options={SORTS} />
                        </div>
                        <div className={'dm:sm:col-span-2 dm:lg:col-span-3'}>
                            <Switch
                                label={'Server-side mods only'}
                                description={'Hide client-only mods (minimaps, shaders, HUDs) that do nothing on a server.'}
                                checked={serverOnly}
                                onChange={change(setServerOnly)}
                            />
                        </div>
                    </div>
                </TitledGreyBox>

                {results.isError && <Alert type={'danger'}>{httpErrorToHuman(results.error)}</Alert>}
                {results.isLoading && canInstall && <Spinner centered />}

                {results.data && results.data.hits.length === 0 && <Alert type={'info'}>No mods match these filters.</Alert>}

                {results.data && results.data.hits.length > 0 && (
                    <Pagination<Mod>
                        data={{
                            data: results.data.hits,
                            meta: {
                                pagination: {
                                    total: results.data.total,
                                    count: results.data.hits.length,
                                    per_page: results.data.per_page,
                                    current_page: results.data.page,
                                    total_pages: results.data.total_pages,
                                },
                            },
                        }}
                        onPageSelect={setPage}
                    >
                        {({ items }) => (
                            <ul className={gridClass(layout)}>
                                {items.map((mod) => (
                                    <ModCard key={mod.project_id} mod={mod} canInstall={canInstall} onInstall={setInstalling} onReadMore={setReading} settings={layout} />
                                ))}
                            </ul>
                        )}
                    </Pagination>
                )}
            </div>

            <ModDetailsDialog
                mod={reading}
                serverUuid={uuid}
                canInstall={canInstall}
                onClose={() => setReading(null)}
                onInstall={(mod) => {
                    setReading(null);
                    setInstalling(mod);
                }}
            />
            <InstallDialog mod={installing} serverUuid={uuid} loader={loader} gameVersion={gameVersion} directory={settings.directory} onClose={() => setInstalling(null)} />
        </>
    );
}
