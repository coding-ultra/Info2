import { Button } from '@pterodactyl/sdk';
import { VIZION_ICON } from '../brand';
import DiscordButton from './DiscordButton';

export type View = 'browse' | 'manager';

const VIEWS: { id: View; label: string }[] = [
    { id: 'browse', label: 'Browse mods' },
    { id: 'manager', label: 'Mod manager' },
];

interface Props {
    subtitle: string;
    view: View;
    /**
     * Switches the page shown inside this screen. This is plain React state, so it never depends on
     * the Panel's router: the buttons work the same wherever the screen is opened from.
     */
    onNavigate: (view: View) => void;
}

export default function Header({ subtitle, view, onNavigate }: Props) {
    return (
        <div className={'dm:flex dm:flex-wrap dm:items-center dm:justify-between dm:gap-3'}>
            <div className={'dm:flex dm:items-center dm:gap-3'}>
                <img src={VIZION_ICON} alt={''} width={40} height={40} className={'dm:rounded-md'} />
                <div>
                    <h2 className={'dm:font-semibold dm:text-foreground'}>Mod</h2>
                    <p className={'dm:text-xs dm:text-muted-foreground'}>{subtitle}</p>
                </div>
            </div>
            <div className={'dm:flex dm:flex-wrap dm:items-center dm:gap-2'}>
                {VIEWS.map((item) => (
                    <Button key={item.id} isSecondary={item.id !== view} onClick={() => onNavigate(item.id)}>
                        {item.label}
                    </Button>
                ))}
                <DiscordButton />
            </div>
        </div>
    );
}
