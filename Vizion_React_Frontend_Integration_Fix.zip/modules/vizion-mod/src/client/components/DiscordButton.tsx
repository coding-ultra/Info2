import { DISCORD_LOGO, DISCORD_URL } from '../brand';

/** "Join our Discord" call to action, a real link in Discord blurple (same as Register). */
export default function DiscordButton() {
    return (
        <a
            href={DISCORD_URL}
            target={'_blank'}
            rel={'noopener noreferrer'}
            className={'dm:flex dm:items-center dm:gap-2 dm:rounded-md dm:px-3 dm:py-2 dm:text-sm dm:font-semibold dm:no-underline'}
            style={{ background: '#5865f2', color: '#fff' }}
        >
            <img src={DISCORD_LOGO} alt={''} width={20} height={15} aria-hidden={true} />
            Join our Discord
        </a>
    );
}
