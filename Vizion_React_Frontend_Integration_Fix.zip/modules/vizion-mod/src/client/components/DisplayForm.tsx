import { useState } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { Button, Input, Label, Select, Spinner, Switch, TitledGreyBox, httpErrorToHuman, toast } from '@pterodactyl/sdk';
import { displayKey, getPreviewMods, previewKey, saveDisplaySettings, type DisplaySettings, type Mod } from '../api';
import { gridClass, type LayoutSettings } from '../layout';
import EggVisibilityForm from './EggVisibilityForm';
import ModCard from './ModCard';

/** The built-in defaults. Mirrors DisplaySettings::FALLBACK in the backend. */
const BUILT_IN: DisplaySettings = {
    install_directory: '/mods',
    layout: 'card',
    columns: 3,
    show_background: true,
    overlay_opacity: 75,
    blur_amount: 0,
    contact: '',
    cache_minutes: 10,
    require_minecraft: true,
    egg_overrides: {},
};

const layoutFrom = (vizion: DisplaySettings): LayoutSettings => ({
    layout: vizion.layout,
    columns: vizion.columns,
    show_background: vizion.show_background,
    show_overlay: vizion.overlay_opacity > 0,
    overlay_opacity: vizion.overlay_opacity,
    blur_enabled: vizion.blur_amount > 0,
    blur_amount: vizion.blur_amount,
});

const isValidDirectory = (value: string) => /^\/[A-Za-z0-9._/-]*$/.test(value) && !/(^|\/)\.\.(\/|$)/.test(value);
const cleanDirectory = (value: string) => value.trim().replace(/\/+$/, '') || '/';

const CACHE_CHOICES = [1, 5, 10, 30, 60, 360, 1440];
const cacheLabel = (minutes: number) => (minutes >= 60 && minutes % 60 === 0 ? `${minutes / 60} hour${minutes === 60 ? '' : 's'}` : `${minutes} minute${minutes === 1 ? '' : 's'}`);

// Fallback samples for the preview, used only when real mods cannot be loaded from Modrinth:
// one with a banner image and one with only an icon.
const svg = (body: string) => `data:image/svg+xml;utf8,${encodeURIComponent(body)}`;
const SAMPLE_BANNER = svg(
    '<svg xmlns="http://www.w3.org/2000/svg" width="600" height="200" viewBox="0 0 600 200"><defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#22d3ee"/><stop offset="1" stop-color="#6366f1"/></linearGradient></defs><rect width="600" height="200" fill="url(#g)"/><circle cx="130" cy="70" r="46" fill="#fff" fill-opacity=".35"/><rect x="300" y="110" width="230" height="44" rx="8" fill="#fff" fill-opacity=".3"/><rect x="60" y="150" width="120" height="14" rx="7" fill="#000" fill-opacity=".25"/></svg>'
);
const SAMPLE_ICON = svg(
    '<svg xmlns="http://www.w3.org/2000/svg" width="64" height="64" viewBox="0 0 64 64"><defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#fb923c"/><stop offset="1" stop-color="#e11d48"/></linearGradient></defs><rect width="64" height="64" rx="12" fill="url(#g)"/><path d="M20 34l8 8 16-18" fill="none" stroke="#fff" stroke-width="6" stroke-linecap="round" stroke-linejoin="round"/></svg>'
);
const SAMPLES: Mod[] = [
    { title: 'Mod with a banner', banner_url: SAMPLE_BANNER, project_id: 'sample-banner' },
    { title: 'Mod with only an icon', banner_url: null, project_id: 'sample-icon' },
].map((sample) => ({
    ...sample,
    slug: 'sample',
    description: 'Sample text to check how the list looks with these settings.',
    icon_url: SAMPLE_ICON,
    author: 'Vizion',
    downloads: 1200000,
    follows: 3400,
    categories: ['optimization'],
    server_side: 'required',
    client_side: 'optional',
    date_modified: null,
}));

const noop = () => undefined;

function Slider({ label, hint, value, max, unit, onChange }: { label: string; hint: string; value: number; max: number; unit: string; onChange: (value: number) => void }) {
    return (
        <div>
            <div className={'dm:flex dm:items-center dm:justify-between'}>
                <Label>{label}</Label>
                <span className={'dm:text-xs dm:text-muted-foreground'}>
                    {value}
                    {unit}
                </span>
            </div>
            <input type={'range'} aria-label={label} min={0} max={max} step={1} value={value} onChange={(e) => onChange(Number(e.target.value))} style={{ width: '100%' }} />
            <p className={'dm:text-xs dm:text-muted-foreground'}>{hint}</p>
        </div>
    );
}

/** The settings form of the admin page. Saved values are what every server and user starts from. */
export default function DisplayForm({ data }: { data: DisplaySettings }) {
    const queryClient = useQueryClient();
    const [vizion, setVizion] = useState<DisplaySettings>(data);
    const set = <K extends keyof DisplaySettings>(key: K, value: DisplaySettings[K]) => setVizion((current) => ({ ...current, [key]: value }));

    const directoryValid = isValidDirectory(vizion.install_directory.trim());
    const candidate: DisplaySettings = { ...vizion, install_directory: directoryValid ? cleanDirectory(vizion.install_directory) : data.install_directory, contact: vizion.contact.trim() };
    const dirty = (Object.keys(data) as (keyof DisplaySettings)[]).some((key) => JSON.stringify(candidate[key]) !== JSON.stringify(data[key]));

    const save = useMutation({
        mutationFn: () => saveDisplaySettings(candidate),
        onSuccess: (saved) => {
            queryClient.setQueryData(displayKey, saved);
            toast.success('Settings saved.');
        },
        onError: (error) => toast.error(httpErrorToHuman(error)),
    });

    const preview = layoutFrom(candidate);

    // Live preview: real mods from Modrinth, drawn with the unsaved settings above, so what you see is what servers get.
    const liveMods = useQuery({ queryKey: previewKey, queryFn: getPreviewMods, staleTime: 10 * 60 * 1000, retry: false });
    const isLive = (liveMods.data?.length ?? 0) > 0;
    const previewMods = (isLive ? (liveMods.data as Mod[]) : SAMPLES).slice(0, preview.layout === 'row' ? 4 : 6);
    const imageControlsOff = !vizion.show_background;
    const cacheChoices = CACHE_CHOICES.includes(vizion.cache_minutes) ? CACHE_CHOICES : [...CACHE_CHOICES, vizion.cache_minutes].sort((a, b) => a - b);

    return (
        <div className={'dm:grid dm:gap-4'}>
            <TitledGreyBox title={'Install location'}>
                <Label>Install directory</Label>
                <Input value={vizion.install_directory} onChange={(e) => set('install_directory', e.target.value)} placeholder={'/mods'} />
                <p className={'dm:mt-1 dm:text-xs dm:text-muted-foreground'}>
                    {directoryValid
                        ? 'Folder, relative to the server root, that mods are downloaded into and listed from.'
                        : 'Start with / and use only letters, numbers, dots, dashes, underscores and slashes. ".." is not allowed.'}
                </p>
            </TitledGreyBox>

            <EggVisibilityForm
                requireMinecraft={vizion.require_minecraft}
                overrides={vizion.egg_overrides}
                onRequireMinecraft={(value) => set('require_minecraft', value)}
                onOverrides={(value) => set('egg_overrides', value)}
            />

            <TitledGreyBox title={'Mod list'}>
                <div className={'dm:grid dm:gap-3 dm:sm:grid-cols-2'}>
                    <div>
                        <Label>Layout</Label>
                        <Select
                            value={vizion.layout}
                            onChange={(v) => set('layout', v === 'row' ? 'row' : 'card')}
                            options={[
                                { value: 'card', label: 'Cards' },
                                { value: 'row', label: 'Rows' },
                            ]}
                        />
                    </div>
                    {vizion.layout === 'card' && (
                        <div>
                            <Label>Cards per row</Label>
                            <Select
                                value={String(vizion.columns)}
                                onChange={(v) => set('columns', Number(v))}
                                options={[
                                    { value: '2', label: '2 cards per row' },
                                    { value: '3', label: '3 cards per row' },
                                    { value: '4', label: '4 cards per row' },
                                ]}
                            />
                        </div>
                    )}
                    <div className={'dm:sm:col-span-2'}>
                        <Switch
                            label={'Background image'}
                            description={"Use the mod's gallery image (or its icon) behind each card or row."}
                            checked={vizion.show_background}
                            onChange={(value: boolean) => set('show_background', value)}
                        />
                    </div>
                    <div style={imageControlsOff ? { opacity: 0.5 } : undefined}>
                        <Slider
                            label={'Dark overlay strength'}
                            hint={'Darkens the image so the text stays readable. 0 turns the overlay off.'}
                            value={vizion.overlay_opacity}
                            max={100}
                            unit={'%'}
                            onChange={(value) => set('overlay_opacity', value)}
                        />
                    </div>
                    <div style={imageControlsOff ? { opacity: 0.5 } : undefined}>
                        <Slider
                            label={'Background blur'}
                            hint={'Softens the image on every mod the same way. 0 turns the blur off.'}
                            value={vizion.blur_amount}
                            max={40}
                            unit={'px'}
                            onChange={(value) => set('blur_amount', value)}
                        />
                    </div>
                </div>
            </TitledGreyBox>

            <TitledGreyBox title={'Live preview'}>
                <p className={'dm:mb-3 dm:text-xs dm:text-muted-foreground'}>
                    {isLive
                        ? 'Real mods from Modrinth, drawn with the settings above. Change a setting or move a slider and the list updates straight away. Nothing is saved until you press Save.'
                        : 'Sample mods are shown because real ones could not be loaded. Both samples get the same blur and overlay, so you can check that every mod looks alike.'}
                </p>
                {liveMods.isLoading && <Spinner centered />}
                {liveMods.isError && (
                    <div className={'dm:mb-3 dm:flex dm:flex-wrap dm:items-center dm:gap-2 dm:text-xs dm:text-muted-foreground'}>
                        <span>Could not load live mods ({httpErrorToHuman(liveMods.error)}).</span>
                        <Button.Text onClick={() => void liveMods.refetch()} disabled={liveMods.isFetching}>
                            Try again
                        </Button.Text>
                    </div>
                )}
                {!liveMods.isLoading && (
                    // Inert on purpose: the preview cards must not open pages or start installs.
                    <div style={{ pointerEvents: 'none' }} aria-hidden={true}>
                        <ul className={gridClass(preview)}>
                            {previewMods.map((mod) => (
                                <ModCard key={mod.project_id} mod={mod} canInstall={false} onInstall={noop} onReadMore={noop} settings={preview} />
                            ))}
                        </ul>
                    </div>
                )}
            </TitledGreyBox>

            <TitledGreyBox title={'Modrinth'}>
                <div className={'dm:grid dm:gap-3 dm:sm:grid-cols-2'}>
                    <div>
                        <Label>Modrinth contact</Label>
                        <Input value={vizion.contact} maxLength={120} onChange={(e) => set('contact', e.target.value)} placeholder={'https://example.com or you@example.com'} />
                        <p className={'dm:mt-1 dm:text-xs dm:text-muted-foreground'}>Sent in the User-Agent of every Modrinth request, as Modrinth asks API consumers to identify themselves.</p>
                    </div>
                    <div>
                        <Label>Search cache</Label>
                        <Select value={String(vizion.cache_minutes)} onChange={(v) => set('cache_minutes', Number(v))} options={cacheChoices.map((minutes) => ({ value: String(minutes), label: cacheLabel(minutes) }))} />
                        <p className={'dm:mt-1 dm:text-xs dm:text-muted-foreground'}>How long Modrinth search and version responses are cached on the Panel.</p>
                    </div>
                </div>
            </TitledGreyBox>

            <div className={'dm:flex dm:flex-wrap dm:items-center dm:gap-2'}>
                <Button isLoading={save.isPending} disabled={save.isPending || !directoryValid || !dirty} onClick={() => save.mutate()}>
                    Save settings
                </Button>
                <Button isSecondary={true} disabled={save.isPending} onClick={() => setVizion(BUILT_IN)}>
                    Restore built-in defaults
                </Button>
                <span className={'dm:text-xs dm:text-muted-foreground'}>Restoring only fills in the form. Nothing changes until you save.</span>
            </div>
        </div>
    );
}
