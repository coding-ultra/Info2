import { useEffect, useState, type CSSProperties } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Alert, Button, Dialog, Spinner, httpErrorToHuman } from '@pterodactyl/sdk';
import { getDetails, type Mod } from '../api';
import { formatCount } from '../detect';
import Markdown from '../markdown';

interface Props {
    mod: Mod | null;
    serverUuid: string;
    canInstall: boolean;
    onClose: () => void;
    onInstall: (mod: Mod) => void;
}

type Tab = 'description' | 'gallery' | 'details';

const LINK_LABELS: Record<string, string> = { source: 'Source code', issues: 'Issue tracker', wiki: 'Wiki', discord: 'Discord' };
const date = (value: string | null) => (value ? new Date(value).toLocaleDateString() : '-');

const panel: CSSProperties = { border: '1px solid var(--border)', borderRadius: '0.5rem', padding: '0.75rem' };
const chip: CSSProperties = {
    border: '1px solid var(--border)',
    borderRadius: '999px',
    padding: '0.125rem 0.625rem',
    fontSize: '0.75rem',
    color: 'var(--foreground)',
    background: 'color-mix(in srgb, var(--foreground) 5%, transparent)',
};
const outlined: CSSProperties = {
    display: 'inline-flex',
    alignItems: 'center',
    gap: '0.375rem',
    border: '1px solid var(--border)',
    borderRadius: '0.375rem',
    padding: '0.375rem 0.75rem',
    fontSize: '0.8rem',
    color: 'var(--foreground)',
    background: 'transparent',
    textDecoration: 'none',
    cursor: 'pointer',
};
const iconButton: CSSProperties = { ...outlined, width: '2rem', height: '2rem', justifyContent: 'center', padding: 0, fontSize: '1.25rem', lineHeight: 1 };

function Label({ children }: { children: string }) {
    return <div style={{ fontSize: '0.7rem', letterSpacing: '0.04em', textTransform: 'uppercase', color: 'var(--muted-foreground)', marginBottom: '0.375rem' }}>{children}</div>;
}

function Chips({ label, items }: { label: string; items: string[] }) {
    if (items.length === 0) return null;
    return (
        <div>
            <Label>{label}</Label>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.375rem' }}>
                {items.map((item) => (
                    <span key={item} style={chip}>
                        {item}
                    </span>
                ))}
            </div>
        </div>
    );
}

export default function ModDetailsDialog({ mod, serverUuid, canInstall, onClose, onInstall }: Props) {
    const [tab, setTab] = useState<Tab>('description');
    const [viewer, setViewer] = useState<number | null>(null);

    // Every mod opens on its description.
    useEffect(() => {
        setTab('description');
        setViewer(null);
    }, [mod?.project_id]);

    const details = useQuery({
        queryKey: ['vizion-mods', 'details', serverUuid, mod?.project_id],
        queryFn: () => getDetails(serverUuid, mod!.project_id),
        enabled: mod !== null,
        staleTime: 10 * 60 * 1000,
    });
    const d = details.data;
    const gallery = d?.gallery ?? [];
    const image = viewer !== null ? gallery[viewer] : undefined;

    // Arrow keys move through the images while one is open.
    useEffect(() => {
        if (viewer === null) return;
        const onKey = (event: KeyboardEvent) => {
            if (event.key === 'ArrowRight') setViewer((v) => (v === null ? v : (v + 1) % gallery.length));
            if (event.key === 'ArrowLeft') setViewer((v) => (v === null ? v : (v - 1 + gallery.length) % gallery.length));
        };
        window.addEventListener('keydown', onKey);
        return () => window.removeEventListener('keydown', onKey);
    }, [viewer, gallery.length]);

    const tabs: { id: Tab; label: string }[] = [
        { id: 'description', label: 'Description' },
        ...(gallery.length > 0 ? [{ id: 'gallery' as Tab, label: `Gallery (${gallery.length})` }] : []),
        { id: 'details', label: 'Details' },
    ];

    return (
        // The header with the cross button is drawn here, so the Dialog's own title stays empty.
        <Dialog open={mod !== null} onClose={onClose} title={''}>
            {mod && (
                <div style={{ display: 'grid', gap: '1rem', maxHeight: '80vh', overflowY: 'auto', overflowX: 'hidden', minWidth: 0 }}>
                    {/* Image viewer: replaces the page while an image is open. */}
                    {image ? (
                        <div style={{ display: 'grid', gap: '0.75rem' }}>
                            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: '0.5rem' }}>
                                <button type={'button'} style={outlined} onClick={() => setViewer(null)}>
                                    ← Back
                                </button>
                                <span style={{ fontSize: '0.8rem', color: 'var(--muted-foreground)' }}>
                                    {(viewer ?? 0) + 1} / {gallery.length}
                                </span>
                                <button type={'button'} aria-label={'Close'} style={iconButton} onClick={onClose}>
                                    ×
                                </button>
                            </div>
                            <div style={{ position: 'relative', display: 'flex', alignItems: 'center', justifyContent: 'center', background: 'rgba(0,0,0,0.85)', borderRadius: '0.5rem' }}>
                                <img src={image.url} alt={image.title} style={{ maxWidth: '100%', maxHeight: '60vh', objectFit: 'contain', borderRadius: '0.5rem' }} />
                                {gallery.length > 1 && (
                                    <>
                                        <button
                                            type={'button'}
                                            aria-label={'Previous image'}
                                            onClick={() => setViewer(((viewer ?? 0) - 1 + gallery.length) % gallery.length)}
                                            style={{ ...iconButton, position: 'absolute', left: '0.5rem', color: '#fff', background: 'rgba(0,0,0,0.55)', borderColor: 'rgba(255,255,255,0.35)' }}
                                        >
                                            ‹
                                        </button>
                                        <button
                                            type={'button'}
                                            aria-label={'Next image'}
                                            onClick={() => setViewer(((viewer ?? 0) + 1) % gallery.length)}
                                            style={{ ...iconButton, position: 'absolute', right: '0.5rem', color: '#fff', background: 'rgba(0,0,0,0.55)', borderColor: 'rgba(255,255,255,0.35)' }}
                                        >
                                            ›
                                        </button>
                                    </>
                                )}
                            </div>
                            {(image.title || image.description) && (
                                <div>
                                    {image.title && <div style={{ fontWeight: 600, color: 'var(--foreground)' }}>{image.title}</div>}
                                    {image.description && <div style={{ fontSize: '0.85rem', color: 'var(--muted-foreground)' }}>{image.description}</div>}
                                </div>
                            )}
                            <div style={{ display: 'flex', gap: '0.5rem', overflowX: 'auto', paddingBottom: '0.25rem' }}>
                                {gallery.map((thumb, n) => (
                                    <img
                                        key={thumb.url}
                                        src={thumb.url}
                                        alt={thumb.title}
                                        loading={'lazy'}
                                        onClick={() => setViewer(n)}
                                        style={{
                                            height: '3.5rem',
                                            flex: '0 0 auto',
                                            aspectRatio: '16 / 9',
                                            objectFit: 'cover',
                                            borderRadius: '0.375rem',
                                            cursor: 'pointer',
                                            outline: n === viewer ? '2px solid var(--foreground)' : '1px solid var(--border)',
                                        }}
                                    />
                                ))}
                            </div>
                        </div>
                    ) : (
                        <>
                            {/* Header */}
                            <div style={{ display: 'flex', alignItems: 'flex-start', gap: '0.75rem' }}>
                                {mod.icon_url ? (
                                    <img src={mod.icon_url} alt={''} style={{ width: '4rem', height: '4rem', borderRadius: '0.75rem', flex: '0 0 auto' }} />
                                ) : (
                                    <div style={{ width: '4rem', height: '4rem', borderRadius: '0.75rem', border: '1px solid var(--border)', flex: '0 0 auto' }} />
                                )}
                                <div style={{ minWidth: 0, flex: '1 1 auto' }}>
                                    <h2 style={{ margin: 0, fontSize: '1.15rem', fontWeight: 700, color: 'var(--foreground)', overflowWrap: 'anywhere' }}>{mod.title}</h2>
                                    <p style={{ margin: '0.125rem 0 0', fontSize: '0.8rem', color: 'var(--muted-foreground)' }}>by {mod.author}</p>
                                </div>
                                <button type={'button'} aria-label={'Close'} style={iconButton} onClick={onClose}>
                                    ×
                                </button>
                            </div>

                            <p style={{ margin: 0, fontSize: '0.9rem', color: 'var(--foreground)' }}>{mod.description}</p>

                            {/* Stats + actions */}
                            <div style={{ display: 'flex', flexWrap: 'wrap', alignItems: 'center', gap: '0.5rem 1rem', fontSize: '0.8rem', color: 'var(--muted-foreground)' }}>
                                <span>
                                    <strong style={{ color: 'var(--foreground)' }}>{formatCount(d?.downloads ?? mod.downloads)}</strong> downloads
                                </span>
                                <span>
                                    <strong style={{ color: 'var(--foreground)' }}>{formatCount(d?.followers ?? mod.follows)}</strong> followers
                                </span>
                                {d?.updated && <span>Updated {date(d.updated)}</span>}
                            </div>

                            <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.5rem', alignItems: 'center' }}>
                                <Button disabled={!canInstall} onClick={() => onInstall(mod)}>
                                    Install
                                </Button>
                                <a href={`https://modrinth.com/mod/${d?.slug ?? mod.slug}`} target={'_blank'} rel={'noreferrer noopener'} style={outlined}>
                                    View on Modrinth ↗
                                </a>
                            </div>

                            {/* Tabs */}
                            <div role={'tablist'} style={{ display: 'flex', gap: '0.25rem', borderBottom: '1px solid var(--border)', overflowX: 'auto' }}>
                                {tabs.map((t) => (
                                    <button
                                        key={t.id}
                                        type={'button'}
                                        role={'tab'}
                                        aria-selected={tab === t.id}
                                        onClick={() => setTab(t.id)}
                                        style={{
                                            background: 'none',
                                            border: 0,
                                            borderBottom: tab === t.id ? '2px solid var(--foreground)' : '2px solid transparent',
                                            padding: '0.5rem 0.75rem',
                                            fontSize: '0.85rem',
                                            fontWeight: tab === t.id ? 600 : 400,
                                            color: tab === t.id ? 'var(--foreground)' : 'var(--muted-foreground)',
                                            cursor: 'pointer',
                                            whiteSpace: 'nowrap',
                                        }}
                                    >
                                        {t.label}
                                    </button>
                                ))}
                            </div>

                            {details.isLoading && <Spinner centered />}
                            {details.isError && <Alert type={'danger'}>{httpErrorToHuman(details.error)}</Alert>}

                            {d && tab === 'description' && (d.body.trim() ? <Markdown source={d.body} /> : <p style={{ color: 'var(--muted-foreground)', fontSize: '0.875rem' }}>This mod has no long description.</p>)}

                            {d && tab === 'gallery' && (
                                <div style={{ display: 'grid', gap: '0.75rem', gridTemplateColumns: 'repeat(auto-fill, minmax(min(100%, 12rem), 1fr))' }}>
                                    {gallery.map((img, n) => (
                                        <button
                                            key={img.url}
                                            type={'button'}
                                            onClick={() => setViewer(n)}
                                            title={'Open image'}
                                            style={{ ...panel, padding: 0, overflow: 'hidden', textAlign: 'left', cursor: 'zoom-in', background: 'transparent' }}
                                        >
                                            <img src={img.url} alt={img.title} loading={'lazy'} style={{ display: 'block', width: '100%', aspectRatio: '16 / 9', objectFit: 'cover' }} />
                                            {img.title && <div style={{ padding: '0.375rem 0.5rem', fontSize: '0.75rem', color: 'var(--foreground)' }}>{img.title}</div>}
                                        </button>
                                    ))}
                                </div>
                            )}

                            {d && tab === 'details' && (
                                <div style={{ display: 'grid', gap: '1rem' }}>
                                    <div style={{ display: 'grid', gap: '0.5rem', gridTemplateColumns: 'repeat(auto-fit, minmax(8rem, 1fr))' }}>
                                        {[
                                            ['Downloads', formatCount(d.downloads)],
                                            ['Followers', formatCount(d.followers)],
                                            ['Updated', date(d.updated)],
                                            ['Published', date(d.published)],
                                            ['License', d.license || '-'],
                                        ].map(([label, value]) => (
                                            <div key={label} style={panel}>
                                                <div style={{ fontSize: '0.7rem', color: 'var(--muted-foreground)' }}>{label}</div>
                                                <div style={{ fontSize: '0.9rem', fontWeight: 600, color: 'var(--foreground)', overflowWrap: 'anywhere' }}>{value}</div>
                                            </div>
                                        ))}
                                    </div>
                                    <Chips label={'Environment'} items={[`Server: ${d.server_side}`, `Client: ${d.client_side}`]} />
                                    <Chips label={'Categories'} items={d.categories} />
                                    <Chips label={'Loaders'} items={d.loaders} />
                                    <Chips label={'Minecraft versions'} items={d.game_versions} />
                                    {Object.keys(d.links).length > 0 && (
                                        <div>
                                            <Label>Links</Label>
                                            <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.5rem' }}>
                                                {Object.entries(d.links).map(([key, url]) => (
                                                    <a key={key} href={url} target={'_blank'} rel={'noreferrer noopener'} style={outlined}>
                                                        {LINK_LABELS[key] ?? key} ↗
                                                    </a>
                                                ))}
                                            </div>
                                        </div>
                                    )}
                                </div>
                            )}
                        </>
                    )}
                </div>
            )}
        </Dialog>
    );
}
