import { useQuery } from '@tanstack/react-query';
import { Alert, PageContentBlock, Spinner, httpErrorToHuman } from '@pterodactyl/sdk';
import { displayKey, getDisplaySettings } from '../api';
import { VIZION_ICON } from '../brand';
import DisplayForm from '../components/DisplayForm';

/** Mods settings page for root administrators, at /panel/vizion-mods. */
export default function AdminScreen() {
    const query = useQuery({ queryKey: displayKey, queryFn: getDisplaySettings });

    return (
        <PageContentBlock title={'Mods'}>
            <div className={'dm:grid dm:gap-4'}>
                <div className={'dm:flex dm:items-center dm:gap-3'}>
                    <img src={VIZION_ICON} alt={''} width={40} height={40} className={'dm:rounded-md'} />
                    <div>
                        <h2 className={'dm:font-semibold dm:text-foreground'}>Mods</h2>
                        <p className={'dm:text-xs dm:text-muted-foreground'}>Settings every server uses for the mod browser. Changes show up for users the next time they load the Panel.</p>
                    </div>
                </div>

                {query.isLoading && <Spinner centered />}
                {query.isError && <Alert type={'danger'}>{httpErrorToHuman(query.error)}</Alert>}
                {query.data && <DisplayForm key={JSON.stringify(query.data)} data={query.data} />}
            </div>
        </PageContentBlock>
    );
}
