import { expect, test } from 'vitest';
import { eggEnabled, isMinecraftTags } from './eggs';

const minecraft = { id: 1, minecraft: true };
const rust = { id: 2, minecraft: false };

test('recognises the Minecraft category from egg tags', () => {
    expect(isMinecraftTags(['Minecraft', 'fabric'])).toBe(true);
    expect(isMinecraftTags(['minecraft-java'])).toBe(true);
    expect(isMinecraftTags(['rust'])).toBe(false);
    expect(isMinecraftTags(null)).toBe(false);
});

test('only Minecraft eggs are shown by default', () => {
    expect(eggEnabled(minecraft, true, {})).toBe(true);
    expect(eggEnabled(rust, true, {})).toBe(false);
});

test('with the category rule off every egg is shown', () => {
    expect(eggEnabled(rust, false, {})).toBe(true);
});

test('an explicit choice beats the category rule', () => {
    expect(eggEnabled(rust, true, { '2': 'show' })).toBe(true);
    expect(eggEnabled(minecraft, true, { '1': 'hide' })).toBe(false);
    expect(eggEnabled(minecraft, false, { '1': 'hide' })).toBe(false);
});
