import { expect, test } from 'vitest';
import { detectGameVersion, detectLoader, detectLoaderFromVariables, formatBytes } from './detect';

const variable = (env_variable: string, server_value: string | null, default_value = '') => ({ env_variable, server_value, default_value });

test('detects the mod loader from egg tags', () => {
    expect(detectLoader(['minecraft', 'Fabric'])).toBe('fabric');
    expect(detectLoader(['minecraft', 'quilt'])).toBe('quilt');
    expect(detectLoader(['minecraft'])).toBe('');
    expect(detectLoader(null)).toBe('');
});

test('neoforge is not mistaken for forge', () => {
    expect(detectLoader(['neoforge'])).toBe('neoforge');
    expect(detectLoader(['minecraft-neoforge-server'])).toBe('neoforge');
    expect(detectLoader(['forge'])).toBe('forge');
});

test('falls back to startup variable names', () => {
    expect(detectLoaderFromVariables([variable('FABRIC_VERSION', 'latest')])).toBe('fabric');
    expect(detectLoaderFromVariables([variable('NEOFORGE_VERSION', '21.4.1')])).toBe('neoforge');
    expect(detectLoaderFromVariables([variable('FORGE_VERSION', 'recommended')])).toBe('forge');
    expect(detectLoaderFromVariables([variable('SERVER_JARFILE', 'server.jar')])).toBe('');
    expect(detectLoaderFromVariables(undefined)).toBe('');
});

test('reads a concrete Minecraft version and ignores "latest"', () => {
    expect(detectGameVersion([variable('MINECRAFT_VERSION', '1.21.4')])).toBe('1.21.4');
    expect(detectGameVersion([variable('MC_VERSION', null, '1.20.1')])).toBe('1.20.1');
    expect(detectGameVersion([variable('MINECRAFT_VERSION', 'latest', 'latest')])).toBe('');
    expect(detectGameVersion(undefined)).toBe('');
});

test('formats file sizes', () => {
    expect(formatBytes(512)).toBe('512 B');
    expect(formatBytes(2048)).toBe('2 KB');
    expect(formatBytes(5 * 1024 * 1024)).toBe('5.0 MB');
});
