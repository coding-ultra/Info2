import { http } from '@pterodactyl/sdk';

export type Side = 'required' | 'optional' | 'unsupported' | 'unknown';

export interface Mod {
    project_id: string;
    slug: string;
    title: string;
    description: string;
    icon_url: string | null;
    banner_url: string | null;
    author: string;
    downloads: number;
    follows: number;
    categories: string[];
    server_side: Side;
    client_side: Side;
    date_modified: string | null;
}

export interface SearchResult {
    hits: Mod[];
    total: number;
    page: number;
    per_page: number;
    total_pages: number;
}

export interface Dependency {
    project_id: string;
    version_id: string | null;
}

export interface ModVersion {
    id: string;
    project_id: string;
    name: string;
    version_number: string;
    version_type: 'release' | 'beta' | 'alpha';
    game_versions: string[];
    loaders: string[];
    date_published: string | null;
    downloads: number;
    dependencies: Dependency[];
    file: { url: string; filename: string; size: number; sha512: string | null };
}

export interface Meta {
    loaders: { id: string; name: string }[];
    game_versions: string[];
    categories: string[];
}

export interface SearchParams {
    query: string;
    loader: string;
    gameVersion: string;
    category: string;
    sort: string;
    page: number;
    serverOnly: boolean;
}

export interface InstalledRecord {
    url: string;
    title: string;
    project_id: string;
    version_id: string | null;
    version_number: string | null;
}

export interface ModDetails {
    project_id: string;
    slug: string;
    title: string;
    description: string;
    body: string;
    icon_url: string | null;
    gallery: { url: string; title: string; description: string }[];
    categories: string[];
    loaders: string[];
    game_versions: string[];
    server_side: Side;
    client_side: Side;
    downloads: number;
    followers: number;
    license: string;
    published: string | null;
    updated: string | null;
    links: Partial<Record<'source' | 'issues' | 'wiki' | 'discord', string>>;
}

export interface ResolvedDependency {
    project_id: string;
    title: string;
    version: ModVersion | null;
}

/** Backend routes of this extension (routes/server.php). */
const base = (server: string) => `/api/client/servers/${server}/extensions/vizion-mod`;

/** Whether Mod is shown for this server's egg (Minecraft category rule plus the administrator's per-egg choices). */
export async function getAvailability(server: string): Promise<{ enabled: boolean; reason: 'override' | 'category' | 'all' }> {
    return (await http.get<{ data: { enabled: boolean; reason: 'override' | 'category' | 'all' } }>(`${base(server)}/availability`)).data.data;
}

export async function getMeta(server: string): Promise<Meta> {
    return (await http.get<Meta>(`${base(server)}/meta`)).data;
}

export async function searchMods(server: string, p: SearchParams): Promise<SearchResult> {
    const { data } = await http.get<SearchResult>(`${base(server)}/search`, {
        params: {
            query: p.query || undefined,
            loader: p.loader || undefined,
            game_version: p.gameVersion || undefined,
            category: p.category || undefined,
            sort: p.sort,
            page: p.page,
            // Laravel's boolean rule accepts 1/0, not "true"/"false".
            server_only: p.serverOnly ? 1 : 0,
        },
    });
    return data;
}

export async function getVersions(server: string, project: string, loader: string, gameVersion: string): Promise<ModVersion[]> {
    const { data } = await http.get<{ data: ModVersion[] }>(`${base(server)}/projects/${encodeURIComponent(project)}/versions`, {
        params: { loader: loader || undefined, game_version: gameVersion || undefined },
    });
    return data.data;
}

export async function getVersion(server: string, version: string): Promise<ModVersion | null> {
    return (await http.get<{ data: ModVersion | null }>(`${base(server)}/versions/${encodeURIComponent(version)}`)).data.data;
}

export async function getDetails(server: string, project: string): Promise<ModDetails> {
    return (await http.get<ModDetails>(`${base(server)}/projects/${encodeURIComponent(project)}`)).data;
}

/**
 * Looks up what a version needs: for each required dependency, its title and the file to install.
 * A dependency that pins an exact version uses it; otherwise the newest version for this loader and game version.
 */
export async function resolveDependencies(server: string, dependencies: Dependency[], loader: string, gameVersion: string): Promise<ResolvedDependency[]> {
    return Promise.all(
        dependencies.map(async (dependency) => {
            const [details, version] = await Promise.all([
                getDetails(server, dependency.project_id).catch(() => null),
                (dependency.version_id
                    ? getVersion(server, dependency.version_id)
                    : getVersions(server, dependency.project_id, loader, gameVersion).then((versions) => versions[0] ?? null)
                ).catch(() => null),
            ]);

            return { project_id: dependency.project_id, title: details?.title ?? dependency.project_id, version };
        })
    );
}

export async function getInstalled(server: string): Promise<Record<string, InstalledRecord>> {
    const { data } = await http.get<{ data: Record<string, InstalledRecord> }>(`${base(server)}/installed`);
    return data.data ?? {};
}

export async function recordInstalled(server: string, filename: string, record: Omit<InstalledRecord, 'version_id' | 'version_number'> & Partial<InstalledRecord>): Promise<void> {
    await http.post(`${base(server)}/installed`, { filename, ...record });
}

export async function forgetInstalled(server: string, filenames: string[]): Promise<void> {
    await http.post(`${base(server)}/installed/forget`, { filenames });
}

/**
 * Hands a Modrinth CDN URL to the Panel's own remote-file endpoint, so Wings downloads the jar
 * straight into the server. Needs file.create. (The extension SDK has no mutation hook for remote
 * downloads, so this calls the Panel's Client API through the shared `http` client.)
 */
export async function installFile(serverUuid: string, url: string, directory: string, filename: string): Promise<void> {
    await http.post(`/api/client/servers/${serverUuid}/files/pull`, {
        url,
        directory,
        filename,
        use_header: false,
        foreground: true,
    });
}

/** What the Mods admin page edits (the defaults every server starts from). */
export interface DisplaySettings {
    install_directory: string;
    layout: 'card' | 'row';
    columns: number;
    show_background: boolean;
    overlay_opacity: number;
    blur_amount: number;
    contact: string;
    cache_minutes: number;
    require_minecraft: boolean;
    /** Egg id -> explicit choice. Eggs not listed follow the Minecraft-category rule. */
    egg_overrides: Record<string, EggChoice>;
}

export type EggChoice = 'show' | 'hide';

/** An egg as listed on the admin page. */
export interface EggInfo {
    id: number;
    name: string;
    tags: string[];
    /** True for a Minecraft egg: tagged "minecraft", or named after a known server type (Paper, Forge...). */
    minecraft: boolean;
    /** "Vanilla & performance", "Modded (Java)", "Minecraft", or null when the name matches nothing. */
    group: string | null;
}

/** Query key for the admin settings. */
export const displayKey = ['vizion-mod', 'admin', 'display'] as const;

/** Admin routes of this extension (routes/admin.php); root administrators only. */
const adminBase = '/api/admin/extensions/vizion-mod';

/** PHP encodes an empty map as [], so anything that is not a plain object means "no overrides". */
const withOverrides = (settings: DisplaySettings): DisplaySettings => ({
    ...settings,
    egg_overrides: settings.egg_overrides && !Array.isArray(settings.egg_overrides) ? settings.egg_overrides : {},
});

export async function getDisplaySettings(): Promise<DisplaySettings> {
    return withOverrides((await http.get<{ data: DisplaySettings }>(`${adminBase}/display`)).data.data);
}

export async function saveDisplaySettings(values: DisplaySettings): Promise<DisplaySettings> {
    return withOverrides((await http.put<{ data: DisplaySettings }>(`${adminBase}/display`, values)).data.data);
}

/** Query key for the egg list on the admin page. */
export const eggsKey = ['vizion-mod', 'admin', 'eggs'] as const;

export async function getEggs(): Promise<EggInfo[]> {
    return (await http.get<{ data: EggInfo[] }>(`${adminBase}/eggs`)).data.data ?? [];
}

/** Query key for the live preview mods on the admin page. */
export const previewKey = ['vizion-mod', 'admin', 'preview'] as const;

/** A few popular, real Modrinth mods (cached by the Panel) so the settings preview shows what servers will list. */
export async function getPreviewMods(): Promise<Mod[]> {
    return (await http.get<{ data: Mod[] }>(`${adminBase}/preview`)).data.data ?? [];
}
