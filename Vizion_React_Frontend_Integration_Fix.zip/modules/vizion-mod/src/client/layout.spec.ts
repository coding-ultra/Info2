import { expect, test } from 'vitest';
import { DEFAULT_LAYOUT, backgroundImageStyle } from './layout';

test('blur off means no blur and no scaling, for every image alike', () => {
    expect(backgroundImageStyle({ ...DEFAULT_LAYOUT, blur_enabled: false, blur_amount: 0 })).toEqual({});
    // A stale amount with the switch off must not blur anything.
    expect(backgroundImageStyle({ ...DEFAULT_LAYOUT, blur_enabled: false, blur_amount: 12 })).toEqual({});
});

test('blur on applies the configured amount', () => {
    expect(backgroundImageStyle({ ...DEFAULT_LAYOUT, blur_enabled: true, blur_amount: 10 })).toEqual({ filter: 'blur(10px)', transform: 'scale(1.2)' });
});
