<?php

namespace VizionMod;

use VizionMod\Settings\InstalledStore;
use VizionMod\Settings\DisplaySettings;
use Pterodactyl\Extensions\ExtensionProvider;
use Pterodactyl\Services\Extensions\ExtensionSettingDefinition;
use Pterodactyl\Services\Extensions\ExtensionSettingsDefinition;

class VizionModProvider extends ExtensionProvider
{
    public function register(): void
    {
        // No container bindings needed.
    }

    public function boot(): void
    {
        // The controllers read and write per-server records through this wrapper.
        $this->app->instance(InstalledStore::class, new InstalledStore($this->settings()));
        // The Mods admin page (/panel/vizion-mods) reads and writes the settings below through this wrapper.
        $this->app->instance(DisplaySettings::class, new DisplaySettings($this->settings()));

        // routes/server.php -> /api/client/servers/{server}/extensions/vizion-mod
        // routes/admin.php  -> /api/admin/extensions/vizion-mod
        $this->registerApiRoutes();

        // Frontend settings are readable by every signed-in user, so nothing secret goes here.
        // normalizeUsing keeps the stored type correct, because frontendType() is checked before exposure.
        $this->registerSettings(new ExtensionSettingsDefinition($this->settings(), [
            ExtensionSettingDefinition::make('contact', 'contact', '', ['nullable', 'string', 'max:120'])
                ->label('Modrinth contact')
                ->help('Sent in the User-Agent of every Modrinth request (a URL or email), as Modrinth asks API consumers to identify themselves.')
                ->field('text'),

            ExtensionSettingDefinition::make('cache_minutes', 'cache_minutes', 10, ['required', 'integer', 'min:1', 'max:1440'])
                ->label('Search cache (minutes)')
                ->help('How long Modrinth search and version responses are cached on the Panel.')
                ->field('number')
                ->normalizeUsing(fn ($value) => (int) $value),

            ExtensionSettingDefinition::make('install_directory', 'install_directory', '/mods', ['required', 'string', 'max:255', 'regex:#^/[A-Za-z0-9._/-]*$#'])
                ->label('Install directory')
                ->help('Folder, relative to the server root, that mods are downloaded into.')
                ->field('text')
                ->frontend()
                ->frontendType('string'),

            ExtensionSettingDefinition::make('layout', 'layout', 'card', ['required', 'in:card,row'])
                ->label('Mod list layout')
                ->help('Show search results as cards or as compact rows.')
                ->field('select', [['value' => 'card', 'label' => 'Cards'], ['value' => 'row', 'label' => 'Rows']])
                ->frontend()
                ->frontendType('string'),

            ExtensionSettingDefinition::make('columns', 'columns', 3, ['required', 'integer', 'in:2,3,4'])
                ->label('Cards per row')
                ->help('Card layout only: 2, 3 or 4 (default 3). Small screens show fewer.')
                ->field('select', [['value' => 2, 'label' => '2 cards per row'], ['value' => 3, 'label' => '3 cards per row'], ['value' => 4, 'label' => '4 cards per row']])
                ->normalizeUsing(fn ($value) => (int) $value)
                ->frontend()
                ->frontendType('number'),

            ExtensionSettingDefinition::make('show_background', 'show_background', true, ['boolean'])
                ->label('Background image')
                ->help("Use the mod's gallery image (or its icon) behind each card or row.")
                ->field('toggle')
                ->normalizeUsing(fn ($value) => filter_var($value, FILTER_VALIDATE_BOOLEAN))
                ->frontend()
                ->frontendType('boolean'),

            ExtensionSettingDefinition::make('overlay_opacity', 'overlay_opacity', 75, ['required', 'integer', 'min:0', 'max:100'])
                ->label('Dark overlay strength (%)')
                ->help('Darkens the background image so the text stays readable. 0 turns the overlay off.')
                ->field('number')
                ->normalizeUsing(fn ($value) => (int) $value)
                ->frontend()
                ->frontendType('number'),

            ExtensionSettingDefinition::make('blur_amount', 'blur_amount', 0, ['required', 'integer', 'min:0', 'max:40'])
                ->label('Background blur (px)')
                ->help('Softens the background image. 0 turns the blur off.')
                ->field('number')
                ->normalizeUsing(fn ($value) => (int) $value)
                ->frontend()
                ->frontendType('number'),

            ExtensionSettingDefinition::make('require_minecraft', 'require_minecraft', true, ['boolean'])
                ->label('Only Minecraft eggs')
                ->help('Show Mod only on servers whose egg is in the Minecraft category (tagged "minecraft" or named Paper, Forge, Fabric, etc.). Per-egg overrides win over this.')
                ->field('toggle')
                ->normalizeUsing(fn ($value) => filter_var($value, FILTER_VALIDATE_BOOLEAN)),

            ExtensionSettingDefinition::make('egg_overrides', 'egg_overrides', '{}', ['nullable', 'string', 'max:20000'])
                ->label('Egg overrides (JSON)')
                ->help('Per-egg choice as {"EGG_ID": "show" | "hide"}. Easier to edit on the Mods page.')
                ->field('text'),
        ]));
    }
}
