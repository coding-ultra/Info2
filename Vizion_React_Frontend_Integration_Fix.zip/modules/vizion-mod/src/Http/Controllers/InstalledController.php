<?php

namespace VizionMod\Http\Controllers;

use VizionMod\Services\EggVisibility;
use VizionMod\Services\ModrinthClient;
use VizionMod\Settings\InstalledStore;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Knuckles\Scribe\Attributes\Endpoint;
use Pterodactyl\Models\Server;

/** Per-server record of which jars came from Modrinth through Mod. */
class InstalledController
{
    public function __construct(private readonly InstalledStore $store, private readonly EggVisibility $eggs) {}

    #[Endpoint('List installed mods', 'Jars on this server that were installed through Mod, keyed by file name.')]
    public function index(Request $request, Server $server): JsonResponse
    {
        $this->eggs->abortUnlessAllowed($server);

        abort_unless($request->user()->can('file.read', $server), 403, 'You do not have permission to view mods on this server.');

        return new JsonResponse(['data' => (object) $this->store->all($server)]);
    }

    #[Endpoint('Remember an installed mod', 'Stores where a jar was downloaded from so it can be reinstalled.')]
    public function store(Request $request, Server $server): JsonResponse
    {
        $this->eggs->abortUnlessAllowed($server);

        $user = $request->user();
        abort_unless($user->can('file.create', $server) && $user->can('file.update', $server), 403, 'You do not have permission to install mods on this server.');

        $data = $request->validate([
            'filename' => ['required', 'string', 'max:255', 'regex:/^[^\/\\\\\x00-\x1f]+\.jar$/i'],
            'url' => ['required', 'string', 'max:2048', 'url:https'],
            'title' => ['required', 'string', 'max:200'],
            'project_id' => ['required', 'string', 'regex:/^[A-Za-z0-9_.-]{2,64}$/'],
            'version_id' => ['nullable', 'string', 'regex:/^[A-Za-z0-9_.-]{2,64}$/'],
            'version_number' => ['nullable', 'string', 'max:64'],
        ]);

        // Only Modrinth's own CDN may be recorded: reinstall later re-downloads exactly this URL.
        abort_unless(parse_url($data['url'], PHP_URL_HOST) === ModrinthClient::DOWNLOAD_HOST, 422, 'Only files hosted on Modrinth can be recorded.');

        $this->store->remember($server, $data['filename'], [
            'url' => $data['url'],
            'title' => $data['title'],
            'project_id' => $data['project_id'],
            'version_id' => $data['version_id'] ?? null,
            'version_number' => $data['version_number'] ?? null,
        ]);

        return new JsonResponse(['data' => (object) $this->store->all($server)]);
    }

    #[Endpoint('Forget installed mods', 'Removes records for jars that were deleted.')]
    public function forget(Request $request, Server $server): JsonResponse
    {
        $this->eggs->abortUnlessAllowed($server);

        abort_unless($request->user()->can('file.delete', $server), 403, 'You do not have permission to delete files on this server.');

        $data = $request->validate([
            'filenames' => ['required', 'array', 'min:1', 'max:200'],
            'filenames.*' => ['string', 'max:255'],
        ]);

        $this->store->forget($server, array_values($data['filenames']));

        return new JsonResponse(['data' => (object) $this->store->all($server)]);
    }
}
