<?php

namespace VizionMod\Http\Controllers;

use VizionMod\Services\EggVisibility;
use VizionMod\Services\ModrinthClient;
use VizionMod\Services\ModrinthUnavailableException;
use VizionMod\Settings\DisplaySettings;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Knuckles\Scribe\Attributes\Endpoint;
use Pterodactyl\Models\Egg;

/**
 * Backs the Mods admin page (/panel/vizion-mods). Routes in routes/admin.php are root-administrator only.
 * (/api/admin/extensions/{id}/settings is reserved by the Panel, hence "display".)
 */
class AdminSettingsController
{
    /** How many real mods the live preview shows (two full rows of three). */
    public const PREVIEW_COUNT = 6;

    public function __construct(private readonly DisplaySettings $settings) {}

    #[Endpoint('Show Mod settings', 'The settings every server starts from.')]
    public function show(): JsonResponse
    {
        return new JsonResponse(['data' => $this->settings->all()]);
    }

    #[Endpoint('Update Mod settings', 'Saves the settings every server uses.')]
    public function update(Request $request): JsonResponse
    {
        $data = $request->validate([
            'install_directory' => ['required', 'string', 'max:255', 'regex:#^/[A-Za-z0-9._/-]*$#', 'not_regex:#(^|/)\.\.(/|$)#'],
            'layout' => ['required', 'in:card,row'],
            'columns' => ['required', 'integer', 'in:2,3,4'],
            'show_background' => ['required', 'boolean'],
            'overlay_opacity' => ['required', 'integer', 'min:0', 'max:100'],
            'blur_amount' => ['required', 'integer', 'min:0', 'max:40'],
            'contact' => ['nullable', 'string', 'max:120'],
            'cache_minutes' => ['required', 'integer', 'min:1', 'max:1440'],
            'require_minecraft' => ['required', 'boolean'],
            'egg_overrides' => ['nullable', 'array', 'max:2000'],
            'egg_overrides.*' => ['in:show,hide'],
        ]);

        $data['contact'] = (string) ($data['contact'] ?? '');
        $data['egg_overrides'] = $data['egg_overrides'] ?? [];

        return new JsonResponse(['data' => $this->settings->save($data)]);
    }

    #[Endpoint('List eggs', 'Every egg with its tags and whether Mod is shown on it by default, for the per-egg switches.')]
    public function eggs(): JsonResponse
    {
        $eggs = Egg::query()->orderBy('name')->get()->map(function (Egg $egg) {
            $tags = EggVisibility::tagsOf($egg);

            return [
                'id' => (int) $egg->id,
                'name' => (string) $egg->name,
                'tags' => $tags,
                'minecraft' => EggVisibility::matches($tags, (string) $egg->name),
                'group' => EggVisibility::groupOfName((string) $egg->name),
            ];
        });

        return new JsonResponse(['data' => $eggs->values()]);
    }

    #[Endpoint('Preview mods', 'A few popular, real Modrinth mods, so the settings preview shows exactly what servers will list.')]
    public function preview(): JsonResponse
    {
        try {
            $settings = $this->settings->all();
            $client = new ModrinthClient($settings['contact'], $settings['cache_minutes']);

            // Same search a server uses by default (server-side mods, most downloaded first), cached like it.
            $result = $client->search(null, null, null, null, 'downloads', 1, true);

            return new JsonResponse(['data' => array_slice($result['hits'], 0, self::PREVIEW_COUNT)]);
        } catch (ModrinthUnavailableException $e) {
            return new JsonResponse(['errors' => [['code' => 'ModrinthUnavailable', 'status' => '502', 'detail' => $e->getMessage()]]], 502);
        } catch (\Throwable $e) {
            // The page falls back to sample mods, so this only needs to be logged.
            report($e);

            return new JsonResponse(['errors' => [['code' => 'VizionModError', 'status' => '500', 'detail' => 'Mod failed: '.class_basename($e).': '.$e->getMessage()]]], 500);
        }
    }
}
