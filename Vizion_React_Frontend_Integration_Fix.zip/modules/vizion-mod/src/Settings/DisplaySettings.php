<?php

namespace VizionMod\Settings;

use Pterodactyl\Services\Extensions\ExtensionSettings;

/**
 * The administrator settings behind the Mods page (/panel/vizion-mods), stored in the extension's global
 * key-value store under the same keys as the definitions in VizionModProvider, so Admin -> Extensions and this
 * page always show the same values.
 */
final class DisplaySettings
{
    /** The built-in defaults. Mirrors the definitions in VizionModProvider. */
    public const FALLBACK = [
        'install_directory' => '/mods',
        'layout' => 'card',
        'columns' => 3,
        'show_background' => true,
        'overlay_opacity' => 75,
        'blur_amount' => 0,
        'contact' => '',
        'cache_minutes' => 10,
        'require_minecraft' => true,
        'egg_overrides' => [],
    ];

    public function __construct(private readonly ExtensionSettings $store) {}

    /** @return array{install_directory: string, layout: string, columns: int, show_background: bool, overlay_opacity: int, blur_amount: int, contact: string, cache_minutes: int, require_minecraft: bool, egg_overrides: array<string, string>} */
    public function all(): array
    {
        $raw = [];
        foreach (self::FALLBACK as $key => $default) {
            $raw[$key] = $this->store->get($key, $default);
        }

        return self::normalize($raw);
    }

    /**
     * @param array<string, mixed> $values
     * @return array{install_directory: string, layout: string, columns: int, show_background: bool, overlay_opacity: int, blur_amount: int, contact: string, cache_minutes: int, require_minecraft: bool, egg_overrides: array<string, string>}
     */
    public function save(array $values): array
    {
        $clean = self::normalize($values, $this->all());

        // The per-egg overrides are kept as one JSON string, so the stored value always has a plain type.
        $this->store->setMany([...$clean, 'egg_overrides' => json_encode((object) $clean['egg_overrides'])]);

        return $clean;
    }

    /**
     * Coerces raw values to the types and ranges the UI expects; anything unusable falls back to $base.
     *
     * @param array<string, mixed> $raw
     * @param array<string, mixed> $base
     * @return array{install_directory: string, layout: string, columns: int, show_background: bool, overlay_opacity: int, blur_amount: int, contact: string, cache_minutes: int, require_minecraft: bool, egg_overrides: array<string, string>}
     */
    public static function normalize(array $raw, array $base = self::FALLBACK): array
    {
        $int = static fn ($value, int $min, int $max, int $fallback): int => is_numeric($value) ? max($min, min($max, (int) round((float) $value))) : $fallback;

        $directory = $raw['install_directory'] ?? null;
        $valid = is_string($directory)
            && preg_match('#^/[A-Za-z0-9._/-]*$#', $directory) === 1
            && preg_match('#(^|/)\.\.(/|$)#', $directory) !== 1;

        // Header values must stay on one line.
        $contact = is_string($raw['contact'] ?? null) ? mb_substr(trim(preg_replace('/[\r\n]+/', ' ', $raw['contact']) ?? ''), 0, 120) : (string) $base['contact'];

        return [
            'install_directory' => $valid ? (rtrim($directory, '/') ?: '/') : (string) $base['install_directory'],
            'layout' => ($raw['layout'] ?? null) === 'row' ? 'row' : (($raw['layout'] ?? null) === 'card' ? 'card' : (string) $base['layout']),
            'columns' => $int($raw['columns'] ?? null, 2, 4, (int) $base['columns']),
            'show_background' => array_key_exists('show_background', $raw) ? filter_var($raw['show_background'], FILTER_VALIDATE_BOOLEAN) : (bool) $base['show_background'],
            'overlay_opacity' => $int($raw['overlay_opacity'] ?? null, 0, 100, (int) $base['overlay_opacity']),
            'blur_amount' => $int($raw['blur_amount'] ?? null, 0, 40, (int) $base['blur_amount']),
            'contact' => $contact,
            'cache_minutes' => $int($raw['cache_minutes'] ?? null, 1, 1440, (int) $base['cache_minutes']),
            'require_minecraft' => array_key_exists('require_minecraft', $raw) ? filter_var($raw['require_minecraft'], FILTER_VALIDATE_BOOLEAN) : (bool) $base['require_minecraft'],
            'egg_overrides' => array_key_exists('egg_overrides', $raw) ? self::overrides($raw['egg_overrides']) : self::overrides($base['egg_overrides']),
        ];
    }

    /**
     * Keeps only "egg id => show|hide" pairs. Accepts an array or the stored JSON string.
     *
     * @return array<string, string>
     */
    public static function overrides(mixed $value): array
    {
        if (is_string($value)) {
            $value = json_decode($value, true);
        }

        $clean = [];
        foreach (is_array($value) ? $value : [] as $eggId => $choice) {
            if (preg_match('/^\d{1,10}$/', (string) $eggId) === 1 && ($choice === 'show' || $choice === 'hide')) {
                $clean[(string) $eggId] = $choice;
            }
        }

        return $clean;
    }
}
