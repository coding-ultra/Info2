<?php

namespace VizionMod\Settings;

use Pterodactyl\Models\Server;
use Pterodactyl\Services\Extensions\ExtensionSettings;

/**
 * Remembers where each jar on a server was installed from, so it can be reinstalled later.
 * Uses the extension's server-scoped key-value store: no database table, deleted with the server.
 */
final class InstalledStore
{
    public const KEY = 'installed';

    public const MAX_RECORDS = 500;

    public function __construct(private readonly ExtensionSettings $store) {}

    /**
     * @return array<string, array{url: string, title: string, project_id: string, version_id: string|null, version_number: string|null}>
     */
    public function all(Server $server): array
    {
        $value = $this->store->forServer($server)->get(self::KEY, []);

        return is_array($value) ? $value : [];
    }

    /** @param array{url: string, title: string, project_id: string, version_id?: string|null, version_number?: string|null} $record */
    public function remember(Server $server, string $filename, array $record): void
    {
        $all = $this->all($server);
        $all[$filename] = [
            'url' => $record['url'],
            'title' => $record['title'],
            'project_id' => $record['project_id'],
            'version_id' => $record['version_id'] ?? null,
            'version_number' => $record['version_number'] ?? null,
        ];

        // Oldest entries fall off first if a server somehow collects hundreds.
        if (count($all) > self::MAX_RECORDS) {
            $all = array_slice($all, -self::MAX_RECORDS, null, true);
        }

        $this->store->forServer($server)->set(self::KEY, $all);
    }

    /** @param list<string> $filenames */
    public function forget(Server $server, array $filenames): void
    {
        $all = $this->all($server);
        foreach ($filenames as $filename) {
            unset($all[$filename]);
        }

        $this->store->forServer($server)->set(self::KEY, $all);
    }
}
