import { Paintbrush } from 'lucide-react';
import { SettingsPage } from '../kit/settings/SettingsPage';

/** Admin > Branding: use Vizion's shared settings endpoint, showing only Branding fields. */
export default function SettingsScreen() {
    return (
        <SettingsPage
            extension="vizion"
            inputs={[
                'favicon',
                'logo',
                'logo_collapsed',
                'logo_height',
                'logo_mascot',
                'logo_mode',
            ]}
            title="Branding"
            description="Your logo, collapsed logo and favicon, how they show and how big."
            icon={<Paintbrush size={22} aria-hidden />}
        />
    );
}
