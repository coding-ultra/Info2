import React, { createContext, useContext, useState } from 'react';

const FloatingContext = createContext<{
    floating: boolean;
    setFloating: (v: boolean) => void;
}>({
    floating: false,
    setFloating: () => undefined,
});

export const FloatingProvider: React.FC = ({ children }) => {
    const [floating, setFloating] = useState(false);
    // 8ed5c57c3543b45a14758f9eb6a14752135def1f08027d813e4e63277294a8c4

    return <FloatingContext.Provider value={{ floating, setFloating }}>{children}</FloatingContext.Provider>;
};

export const useFloating = () => useContext(FloatingContext);
